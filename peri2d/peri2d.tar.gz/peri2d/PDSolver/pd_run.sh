#!/bin/bash
#
./pdsolver -Nx 10 -Ny 10 -delta 0.1 > pdsolver_output.txt
