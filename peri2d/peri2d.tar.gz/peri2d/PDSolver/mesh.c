/*
* This code isdistrubuted under GPLv3
* 
* Code Author: Miroslav Stoyanov, Nov 2011
* 
* Copyright (C) 2011  Miroslav Stoyanov
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* Since the GNU General Public License is longer than this entire code, 
* a copy of it can be obtained separately at <http://www.gnu.org/licenses/>
*/

#ifndef __MESH_C_
#define __MESH_C_

#include "mesh.h"

int Mesh_checkSaneNbrs( struct PDMesh *mesh ){
	int e, i, j, common;
	struct MeshElement* nbr;
	for( e=0; e<mesh->num_elem; e++ ){
		for( i=0; i<3; i++ ){
			if ( mesh->elem[e].nbrs[i] > -1 ){
				// check if this nbr is sane
				if ( mesh->elem[e].nbrs[i] >= mesh->num_elem ){
					printf("#######################################################################\n");
					printf(" ERROR: fake nbr, index out of range %d of %d, for element %d\n",mesh->elem[e].nbrs[i],mesh->num_elem,e);
					printf("#######################################################################\n");
					return 1;
				};
				nbr = &(mesh->elem[mesh->elem[e].nbrs[i]]);
				common = -1;
				for( j=0; j<3; j++ ){
					if ( nbr->nbrs[j] == e ){ common = j; };
				};
				if ( common == -1 ){
					printf("#######################################################################\n");
					printf(" ERROR: nbrs not symmetric for elements %d and %d\n",e,mesh->elem[e].nbrs[i]);
					printf("#######################################################################\n");
				};
				if ( (fabs( mesh->elem[e].T.x[(i+1)%3] - nbr->T.x[(common+2)%3] ) > 1.E-7) ||
				     (fabs( mesh->elem[e].T.y[(i+1)%3] - nbr->T.y[(common+2)%3] ) > 1.E-7) ||
				     (fabs( mesh->elem[e].T.x[(i+2)%3] - nbr->T.x[(common+1)%3] ) > 1.E-7) ||
				     (fabs( mesh->elem[e].T.y[(i+2)%3] - nbr->T.y[(common+1)%3] ) > 1.E-7) ){
					     printf("#######################################################################\n");
					     printf(" ERROR: nbrs don't align for elements %d and %d\n",e,mesh->elem[e].nbrs[i]);
					     printf("        Triangle 1: %f %f %f %f %f %f\n",mesh->elem[e].T.x[0],mesh->elem[e].T.y[0],mesh->elem[e].T.x[1],mesh->elem[e].T.y[1],mesh->elem[e].T.x[2],mesh->elem[e].T.y[2] );
					     printf("        Triangle 2: %f %f %f %f %f %f\n",nbr->T.x[0],nbr->T.y[0],nbr->T.x[1],nbr->T.y[1],nbr->T.x[2],nbr->T.y[2]);
					     printf("        NBRS: %d %d %d | %d %d %d\n",mesh->elem[e].nbrs[0],mesh->elem[e].nbrs[1],mesh->elem[e].nbrs[2],nbr->nbrs[0],nbr->nbrs[1],nbr->nbrs[2]);
					     printf("#######################################################################\n");
					     return 1;
				};
			};
		};
	};
	return 0;
};

int Mesh_checkSaneGlobal( struct PDMesh *mesh ){
	int e, i, j, common;
	struct MeshElement* nbr;
	for( e=0; e<mesh->num_elem; e++){
		for( i=0; i<3; i++ ){
			if ( mesh->elem[e].iLCglobalu[i] >= mesh->num_total ){
				printf("#######################################################################\n");
				printf(" ERROR: global index out of range %d of %d, for element %d\n",mesh->elem[e].iLCglobalu[i],mesh->num_total,e);
				printf("#######################################################################\n");
				return 1;
			};
			if ( mesh->elem[e].nbrs[i] > -1 ){
				nbr = &(mesh->elem[mesh->elem[e].nbrs[i]]);
				common = -1;
				for( j=0; j<3; j++ ){
					if ( nbr->nbrs[j] == e ){ common = j; };
				};
				if ( (mesh->elem[e].iLCglobalu[(i+1)%3] != nbr->iLCglobalu[(common+2)%3]) ||
				     (mesh->elem[e].iLCglobalu[(i+2)%3] != nbr->iLCglobalu[(common+1)%3]) ){
					printf("#######################################################################\n");
					printf(" ERROR: global index mismatch for elements: %d and %d\n",e,mesh->elem[e].nbrs[i]);
					printf("        Element 1: %d %d %d\n",mesh->elem[e].iLCglobalu[0],mesh->elem[e].iLCglobalu[1],mesh->elem[e].iLCglobalu[2]);
					printf("        Element 2: %d %d %d\n",nbr->iLCglobalu[0],nbr->iLCglobalu[1],nbr->iLCglobalu[2]);
					printf("#######################################################################\n");
					return 1;
				};
			};
		};
	};
	return 0;
};

int Mesh_checkSaneUnknown( struct PDMesh *mesh ){
	int e, i, j, common;
	struct MeshElement* nbr;
	for( e=0; e<mesh->num_elem; e++){
		for( i=0; i<3; i++ ){
			if ( (mesh->elem[e].iLCu[i] >= mesh->num_u)||(mesh->elem[e].iLCv[i] >= mesh->num_v) ){
				printf("#######################################################################\n");
				printf(" ERROR: df index out of range %d of %d and %d of %d, for element %d\n",mesh->elem[e].iLCu[i],mesh->num_u,mesh->elem[e].iLCv[i],mesh->num_v,e);
				printf("#######################################################################\n");
				return 1;
			};
			if ( mesh->elem[e].nbrs[i] > -1 ){
				nbr = &(mesh->elem[mesh->elem[e].nbrs[i]]);
				common = -1;
				for( j=0; j<3; j++ ){
					if ( nbr->nbrs[j] == e ){ common = j; };
				};
				if ( (mesh->elem[e].iLCu[(i+1)%3] != nbr->iLCu[(common+2)%3]) ||
				     (mesh->elem[e].iLCu[(i+2)%3] != nbr->iLCu[(common+1)%3]) ||
				     (mesh->elem[e].iLCv[(i+1)%3] != nbr->iLCv[(common+2)%3]) ||
				     (mesh->elem[e].iLCv[(i+2)%3] != nbr->iLCv[(common+1)%3]) ){
					printf("#######################################################################\n");
					printf(" ERROR: global index mismatch for elements: %d and %d\n",e,mesh->elem[e].nbrs[i]);
					printf("        Element 1: %d %d %d and %d %d %d\n",mesh->elem[e].iLCu[0],mesh->elem[e].iLCu[1],mesh->elem[e].iLCu[2],mesh->elem[e].iLCv[0],mesh->elem[e].iLCv[1],mesh->elem[e].iLCv[2]);
					printf("        Element 2: %d %d %d and %d %d %d\n",nbr->iLCu[0],nbr->iLCu[1],nbr->iLCu[2],nbr->iLCv[0],nbr->iLCv[1],nbr->iLCv[2]);
					printf("#######################################################################\n");
					return 1;
				};
			};
		};
	};
	return 0;
};

int Mesh_checkSane( struct PDMesh *mesh ){
	if ( Mesh_checkSaneNbrs( mesh ) != 0 ){ 
		printf("#######################################################################\n");
		printf(" ERROR in nbrs\n");
		printf("#######################################################################\n");
		return 1; 
	};
	if ( Mesh_checkSaneGlobal( mesh ) != 0 ){ 
		printf("#######################################################################\n");
		printf(" ERROR in global\n");
		printf("#######################################################################\n");
		return 1; 
	};
	if ( Mesh_checkSaneUnknown( mesh ) != 0 ){ 
		printf("#######################################################################\n");
		printf(" ERROR in df\n");
		printf("#######################################################################\n");
		return 1; 
	};
	return 0;
};

void Mesh_setUnknownIndexesLC( int *used_indx_u, int *countu, int *used_indx_v, int *countv, struct MeshElement *elem ){
	int i;
	// set unknown index
	for( i=0; i<3; i++ ){
		if ( used_indx_u[ elem->iLCglobalu[i] ] == -1 ){ // if this is internal and not indexed yet
			used_indx_u[ elem->iLCglobalu[i] ] = *countu;
			elem ->iLCu[i] = used_indx_u[ elem->iLCglobalu[i] ];
			(*countu)++;
		}else if ( used_indx_u[ elem->iLCglobalu[i] ] == -2 ){ // boundary
			elem ->iLCu[i] = -1;
		}else{
			elem ->iLCu[i] = used_indx_u[ elem->iLCglobalu[i] ]; // internal and already indexed
		};
		if ( used_indx_v[ elem->iLCglobalu[i] ] == -1 ){ // if this is internal and not indexed yet
			used_indx_v[ elem->iLCglobalu[i] ] = *countv;
			elem ->iLCv[i] = used_indx_v[ elem->iLCglobalu[i] ];
			(*countv)++;
		}else if ( used_indx_v[ elem->iLCglobalu[i] ] == -2 ){ // boundary
			elem ->iLCv[i] = -1;
		}else{
			elem ->iLCv[i] = used_indx_v[ elem->iLCglobalu[i] ]; // internal and already indexed
		};
	};
};

void Mesh_setBoundaryIndexesLC( int *used_indx_u, int *used_indx_v, struct MeshElement *elem ){
	int i;
	for( i=0; i<3; i++ ){
		used_indx_u[ elem->iLCglobalu[i] ] = -2;
		used_indx_v[ elem->iLCglobalu[i] ] = -2;
	};
};

// add box depth to the boundary conditions
void MeshFormUnit( double delta, double dx, double dy, int boundary_cond, struct PDMesh *mesh ){
        //printf(" Forming Mesh \n");
	int i, j;
	int nx =0, ny =0;
	double x =0.0, y =0.0;
	double x_max, y_max;
	double *ax, *ay; // arrays with the x and y entries
        int depth_t, depth_b, depth_l, depth_r, bdepth;
        
        #ifdef MP_DEBUG
        printf(" Boundary condiotions given: %d \n",boundary_cond);
        #endif
	
	// generating rectangles:
// -------------------------------------------------------------------------------- //
	// generate the list of x entries
	bdepth = (int) ( delta / dx + 1.0 );
        x = ((boundary_cond & MESH_BOUNDARY_LEFT) != 0) ? -bdepth * dx : 0.0;
        x_max = ((boundary_cond & MESH_BOUNDARY_RIGHT) != 0) ? 1.0 + bdepth * dx : 1.0;
	while ( x < x_max ){
		nx++;
		x += dx;
		if ( x > x_max ){
			x = x_max;	
		}else if ( x + dx/2 > x_max ){
			x = x_max;
		};
	};
	ax = malloc( (nx+1)*sizeof(double) );
	nx = 1; 
	x = ((boundary_cond & MESH_BOUNDARY_LEFT) != 0) ? -bdepth * dx : 0.0;
	ax[0] = x;
	while ( x < x_max ){
		x += dx;
		if ( x > x_max ){
			x = x_max;	
		}else if ( x + dx/2 > x_max ){
			x = x_max;
		};
		ax[nx] = x;
		nx++;
	};
        //for( i=0; i<nx; i++ ){ printf(" ax[%d] = %f\n",i,ax[i]); };
// -------------------------------------------------------------------------------- //
	// generate the list of y entries
	bdepth = (int) ( delta / dx + 1.0 );
	y = ((boundary_cond & MESH_BOUNDARY_BOTTOM) != 0) ? -bdepth * dy : 0.0;
        y_max = ((boundary_cond & MESH_BOUNDARY_TOP) != 0) ? 1.0 + bdepth * dy : 1.0;
	while ( y < y_max ){
		y += dy;
		if ( y > y_max ){
			y = y_max;	
		}else if ( y + dy/2 > y_max ){
			y = y_max;
		};
		ny++;
	};
	ay = malloc( (ny+1)*sizeof(double) );
	ny = 1; 
	y = ((boundary_cond & MESH_BOUNDARY_BOTTOM) != 0) ? -bdepth * dy : 0.0;
	ay[0] = y;
	while ( y < y_max ){
		y += dy;
		if ( y > y_max ){
			y = y_max;	
		}else if ( y + dy/2 > y_max ){
			y = y_max;
		};
		ay[ny] = y;
		ny++;
	};
        //for( i=0; i<ny; i++ ){ printf(" ay[%d] = %f\n",i,ay[i]); };
// -------------------------------------------------------------------------------- //
	mesh ->elem = (struct MeshElement*) malloc( 4*(nx-1)*(ny-1)*sizeof( struct MeshElement ) );
	double cx, cy;
	
	// setup the triangles and global indexes
	int e;
	for( i=0; i<ny-1; i++ ){
		for( j =0 ; j < nx-1; j++ ){
			cx = 0.5 * ( ax[j] + ax[j+1] );
			cy = 0.5 * ( ay[i] + ay[i+1] );
			
			// First Element
			e = 4*(i * (nx-1) + j);
			// set the triangle coordinates
			GeometryTriangleSet( cx, cy, ax[j], ay[i], ax[j+1], ay[i], &(mesh ->elem[e].T) );
			// set global indexes CL
			mesh ->elem[ e ].iLCglobalu[0] = i*(2*nx-1)+nx+j;
			mesh ->elem[ e ].iLCglobalu[1] = i*(2*nx-1)+j;
			mesh ->elem[ e ].iLCglobalu[2] = i*(2*nx-1)+j+1;
			// set neighbours
			mesh ->elem[ e ].nbrs[0] = (i==0) ? -1 : 4*( (i-1) * (nx-1) + j) +2;
			mesh ->elem[ e ].nbrs[1] = 4*(i * (nx-1) + j) + 1;
			mesh ->elem[ e ].nbrs[2] = 4*(i * (nx-1) + j) + 3;
			
			// Second Element
			e = 4*(i * (nx-1) + j) + 1;
			// set the triangle coordinates
			GeometryTriangleSet( cx, cy, ax[j+1], ay[i], ax[j+1], ay[i+1], &(mesh ->elem[e].T) );
			// set global indexes CL
			mesh ->elem[ e ].iLCglobalu[0] = i*(2*nx-1)+nx+j;
			mesh ->elem[ e ].iLCglobalu[1] = i*(2*nx-1)+j+1;
			mesh ->elem[ e ].iLCglobalu[2] = (i+1)*(2*nx-1)+j+1;
			// set neighbours
			mesh ->elem[ e ].nbrs[0] = (j==nx-2) ? -1 : 4*( i * (nx-1) + j + 1) +3;
			mesh ->elem[ e ].nbrs[1] = 4*( i * (nx-1) + j) +2;
			mesh ->elem[ e ].nbrs[2] = 4*( i * (nx-1) + j);
			
			// Third Element
			e = 4*(i * (nx-1) + j) + 2;
			// set the triangle coordinates
			GeometryTriangleSet( cx, cy, ax[j+1], ay[i+1], ax[j], ay[i+1], &(mesh ->elem[e].T) );
			// set global indexes CL
			mesh ->elem[ e ].iLCglobalu[0] = i*(2*nx-1)+nx+j;
			mesh ->elem[ e ].iLCglobalu[1] = (i+1)*(2*nx-1)+j+1;
			mesh ->elem[ e ].iLCglobalu[2] = (i+1)*(2*nx-1)+j;
			// set neighbours
			mesh ->elem[ e ].nbrs[0] = (i==ny-2) ? -1 : 4*( (i+1) * (nx-1) + j );
			mesh ->elem[ e ].nbrs[1] = 4*( i * (nx-1) + j) +3;
			mesh ->elem[ e ].nbrs[2] = 4*( i * (nx-1) + j) +1;
			
			// Fourth Element
			e = 4*(i * (nx-1) + j) + 3;
			// set the triangle coordinates
			GeometryTriangleSet( cx, cy, ax[j], ay[i+1], ax[j], ay[i], &(mesh ->elem[e].T) );
			// set global indexes CL
			mesh ->elem[ e ].iLCglobalu[0] = i*(2*nx-1)+nx+j;
			mesh ->elem[ e ].iLCglobalu[1] = (i+1)*(2*nx-1)+j;
			mesh ->elem[ e ].iLCglobalu[2] = i*(2*nx-1)+j;
			// set neighbours
			mesh ->elem[ e ].nbrs[0] = (j==0) ? -1 : 4*( i * (nx-1) + j - 1)+1;
			mesh ->elem[ e ].nbrs[1] = 4*( i * (nx-1) + j);
			mesh ->elem[ e ].nbrs[2] = 4*( i * (nx-1) + j) +2;
		};
	};
	
	// setup the indexes
	int indu =0, indv =0;
	int *used_indx_u = (int*) malloc( ((ny-1)*(2*nx-1) + nx)*sizeof(int) );
	int *used_indx_v = (int*) malloc( ((ny-1)*(2*nx-1) + nx)*sizeof(int) );
	int countu = 0, countv = 0;
	for( i=0; i<((ny-1)*(2*nx-1) + nx); i++ ){
		used_indx_u[i] = -1;  used_indx_v[i] = -1;
	};
	int ttmp = -1;
	
	// setup the indexes for the DG elements and boundary conditions for the CL elements
	for( i=0; i<ny-1; i++ ){
		for( j =0 ; j < nx-1; j++ ){
                        cx = 0.5 * ( ax[j] + ax[j+1] );
			cy = 0.5 * ( ay[i] + ay[i+1] );
                        
			for( e = 4*(i * (nx-1) + j); e < 4*(i * (nx-1) + j) + 4; e++ ){
				mesh->elem[e].mother_element = -1;
                                if ( (cx<0.0) || (cx>1.0) || (cy<0.0) || (cy>1.0) ){
                                        mesh->elem[e].bBoundary = 1; // this is a boundary box
                                        Mesh_setBoundaryIndexesLC( used_indx_u, used_indx_v, &(mesh ->elem[e]) );
				}else{
					mesh->elem[e].bBoundary = 0; // this is not a boundary box
				};
			};
		};
	};
	
	for( i=0; i<ny-1; i++ ){
		for( j =0 ; j < nx-1; j++ ){
			for( e = 4*(i * (nx-1) + j); e < 4*(i * (nx-1) + j) + 4; e++ ){
				// having the indexes for the boundary elements, index the non-boundary ones
				Mesh_setUnknownIndexesLC( used_indx_u, &countu, used_indx_v, &countv, &(mesh ->elem[e]) );
			};
		};
	};
// -------------------------------------------------------------------------------- //
	// set the constants
	mesh ->num_elem = 4*(nx-1)*(ny-1);
	mesh ->num_u = countu;
	mesh ->num_v = countv;
	mesh ->num_total = (2*nx-1)*(ny-1) + nx;
// ------ FREE TEMPORARY MEMORY ----- //
	free( ax );
	free( ay );
};

// ---------- ADAPTIVE CODE ---------- //
int Mesh_CountNbrsToBeRefined( struct PDMesh *mesh, int *to_refine, int e ){
        int i, rnbr = 0;
        for( i=0; i<3; i++ ){ rnbr += ( (mesh->elem[e].nbrs[i]>-1) && (to_refine[ mesh->elem[e].nbrs[i] ] == 1) ) ? 1 : 0; };
        return rnbr;
};
int Mesh_GetNbrsToBeRefinedIndex( struct PDMesh *mesh, int *to_refine, int e ){
        if ( (mesh->elem[e].nbrs[0]>-1)&&(to_refine[mesh->elem[e].nbrs[0]] == 1) ){ return 0; };
        if ( (mesh->elem[e].nbrs[1]>-1)&&(to_refine[mesh->elem[e].nbrs[1]] == 1) ){ return 1; };
        return 2;
};
int Mesh_GetCommonSide( struct PDMesh *mesh, int e, int nbr ){
        // when element e has neighbour nbr, then this returns the index of the opposite vertex (0-2)
        if ( mesh->elem[e].nbrs[0] == nbr ){ return 0; };
        if ( mesh->elem[e].nbrs[1] == nbr ){ return 1; };
        return 2;
};

int Mesh_RecursivelyRefine( struct PDMesh *mesh, int *to_refine, int e ){
        if ( (e==-1)||(to_refine[e] == 1) ){ return 0; }; // nothig to do, this element is already marked
        int i;
        if ( Mesh_CountNbrsToBeRefined( mesh, to_refine, e ) > 1 ){
                to_refine[e] = 1;
                for( i=0; i<3; i++ ){
                        Mesh_RecursivelyRefine( mesh, to_refine, mesh->elem[e].nbrs[i] ); // check neighbour
                };
                return 1; // new element has been added to the refine map
        };
        return 0; // this element doesn't need big refining, bordering one or zero to_refine element
};

void Mesh_CompleteRefinedElementList( struct PDMesh *mesh, int *to_refine ){
        // elements to be refined are flagged in to_refine with 1, others are flagged with 0
        int bNeedsRefining = 1;
        int e, i, rnbrs;
        while( bNeedsRefining == 1 ){
                bNeedsRefining = 0;
                for( e=0; e<mesh->num_elem; e++ ){
                        if ( Mesh_RecursivelyRefine( mesh, to_refine, e ) == 1 ){
                                bNeedsRefining = 1;
                        };
                };
        };
};

void MeshRefine( struct PDMesh *oldmesh, int *to_refine, struct PDMesh *newmesh ){
        // elements to be refined are flagged in to_refine with 1, others are flagged with 0
        Mesh_CompleteRefinedElementList( oldmesh, to_refine );
        
        int e, count;
        int i, j, vertex, common, vertex2;
        int *newindex;
        newindex = (int*) malloc( oldmesh->num_elem * sizeof(int) );
        // count the number of new elements
        count = 0;
        for( e=0; e<oldmesh->num_elem; e++ ){
                newindex[e] = count;
                if ( to_refine[e] == 1 ){
                        count += 4; // full refinement
                }else if ( Mesh_CountNbrsToBeRefined( oldmesh, to_refine, e ) == 1 ){
                        count += 2; // one fully refined neighbour, cut the element in half
                }else{
                        count += 1; // don't refine
                };
        };
        newmesh ->elem = (struct MeshElement*) malloc( count*sizeof( struct MeshElement ) );
        newmesh ->num_elem = count;
        count = 0;

        // set the new triangles
        for( e=0; e<oldmesh->num_elem; e++ ){
                if ( to_refine[e] == 1 ){
                        GeometryTriangleSplit( oldmesh->elem[e].T, &(newmesh->elem[count].T), &(newmesh->elem[count+1].T), &(newmesh->elem[count+2].T), &(newmesh->elem[count+3].T) );
                        for( i=0; i<4; i++ ){
                                for( j=0; j<3; j++ ){
                                        newmesh->elem[count+i].iLCglobalu[j] = -2;
                                        newmesh->elem[count+i].nbrs[j] = -1;
                                };
                                newmesh->elem[count+i].bBoundary = oldmesh->elem[e].bBoundary;
                                newmesh->elem[count+i].mother_element = e;
                        };
                        count += 4; // full refinement
                }else if ( Mesh_CountNbrsToBeRefined( oldmesh, to_refine, e ) == 1 ){
                        vertex = Mesh_GetNbrsToBeRefinedIndex( oldmesh, to_refine, e );
                        GeometryTriangleBisect( oldmesh->elem[e].T, &(newmesh->elem[count].T), &(newmesh->elem[count+1].T), vertex );
                        for( i=0; i<2; i++ ){
                                for( j=0; j<3; j++ ){
                                        newmesh->elem[count+i].iLCglobalu[j] = -2;
                                        newmesh->elem[count+i].nbrs[j] = -1;
                                };
                                newmesh->elem[count+i].bBoundary = oldmesh->elem[e].bBoundary;
                                newmesh->elem[count+i].mother_element = e;
                        };
                        count += 2; // one fully refined neighbour, cut the element in half
                }else{
                        GeometryTriangleCopy( oldmesh->elem[e].T, &(newmesh->elem[count].T) );
                        for( j=0; j<3; j++ ){
                                newmesh->elem[count].iLCglobalu[j] = -2;
                                newmesh->elem[count].nbrs[j] = -1;
                        };
                        newmesh->elem[count].bBoundary = oldmesh->elem[e].bBoundary;
                        newmesh->elem[count].mother_element = e;
                        count += 1; // don't refine
                };
        };
        
        // set the new neighbours
        for( e=0; e<oldmesh->num_elem; e++ ){
                if ( to_refine[e] == 1 ){ // full refinement
                        // do the three sides
                        for( i=0; i<3; i++ ){
                                if ( oldmesh->elem[e].nbrs[i] > -1 ){
                                        common = Mesh_GetCommonSide( oldmesh, oldmesh->elem[e].nbrs[i], e );
                                        if ( to_refine[oldmesh->elem[e].nbrs[i]] == 1 ){ // 4 to 4 touching
                                                newmesh->elem[newindex[e]+(1+i)%3].nbrs[2] = newindex[oldmesh->elem[e].nbrs[i]] + (2+common)%3;
                                                newmesh->elem[newindex[e]+(2+i)%3].nbrs[1] = newindex[oldmesh->elem[e].nbrs[i]] + (1+common)%3;
                                        }else{
                                                newmesh->elem[newindex[e]+(1+i)%3].nbrs[2] = newindex[oldmesh->elem[e].nbrs[i]] + 1;
                                                newmesh->elem[newindex[e]+(2+i)%3].nbrs[1] = newindex[oldmesh->elem[e].nbrs[i]];
                                        };
                                }else{
                                        newmesh->elem[newindex[e]+(1+i)%3].nbrs[2] = -1;
                                        newmesh->elem[newindex[e]+(2+i)%3].nbrs[1] = -1;
                                };
                                newmesh->elem[newindex[e]+i].nbrs[0] = newindex[e]+3;
                                newmesh->elem[newindex[e]+3].nbrs[i] = newindex[e]+i;
                        };
                }else if ( Mesh_CountNbrsToBeRefined( oldmesh, to_refine, e ) == 1 ){ // half refined
                        // we know what type the other three elements are
                        vertex = Mesh_GetNbrsToBeRefinedIndex( oldmesh, to_refine, e );
                        if ( oldmesh->elem[e].nbrs[(vertex+1)%3] > -1 ){
				// consider the case of the neighbour to be split 2
				if ( Mesh_CountNbrsToBeRefined( oldmesh, to_refine, oldmesh->elem[e].nbrs[(vertex+1)%3] ) == 1 ){
					common = Mesh_GetCommonSide( oldmesh, oldmesh->elem[e].nbrs[(vertex+1)%3], e );
					newmesh->elem[newindex[e]+1].nbrs[0] = newindex[oldmesh->elem[e].nbrs[(vertex+1)%3]] + ( ((common+2)%3 == Mesh_GetNbrsToBeRefinedIndex( oldmesh, to_refine, oldmesh->elem[e].nbrs[(vertex+1)%3] )) ? 1 : 0 );
				}else{
					newmesh->elem[newindex[e]+1].nbrs[0] = newindex[oldmesh->elem[e].nbrs[(vertex+1)%3]];
				};
                        };
                        if ( oldmesh->elem[e].nbrs[(vertex+2)%3] > -1 ){
				if ( Mesh_CountNbrsToBeRefined( oldmesh, to_refine, oldmesh->elem[e].nbrs[(vertex+2)%3] ) == 1 ){
					common = Mesh_GetCommonSide( oldmesh, oldmesh->elem[e].nbrs[(vertex+2)%3], e );
					newmesh->elem[newindex[e]].nbrs[0] = newindex[oldmesh->elem[e].nbrs[(vertex+2)%3]] + ( ((common+2)%3 == Mesh_GetNbrsToBeRefinedIndex( oldmesh, to_refine, oldmesh->elem[e].nbrs[(vertex+2)%3] )) ? 1 : 0 );
				}else{
					newmesh->elem[newindex[e]].nbrs[0] = newindex[oldmesh->elem[e].nbrs[(vertex+2)%3]];
				};
                        };
                        // match the internal indexes
                        newmesh->elem[newindex[e]  ].nbrs[2] = newindex[e]+1;
                        newmesh->elem[newindex[e]+1].nbrs[1] = newindex[e];
                        // work with the newly split 4 element
                        common = Mesh_GetCommonSide( oldmesh, oldmesh->elem[e].nbrs[vertex], e );
                        newmesh->elem[newindex[e]  ].nbrs[1] = newindex[oldmesh->elem[e].nbrs[vertex]] + (2+common)%3;
                        newmesh->elem[newindex[e]+1].nbrs[2] = newindex[oldmesh->elem[e].nbrs[vertex]] + (1+common)%3;
                }else{ // this element has not been refined
                        for( i=0; i<3; i++ ){
                                if ( (oldmesh->elem[e].nbrs[i] > -1) ){
                                        if ( Mesh_CountNbrsToBeRefined( oldmesh, to_refine, oldmesh->elem[e].nbrs[i] ) == 1 ){
                                                // check wich of the two new elements we are bordering
                                                vertex = Mesh_GetNbrsToBeRefinedIndex( oldmesh, to_refine, oldmesh->elem[e].nbrs[i] );
                                                common = Mesh_GetCommonSide( oldmesh, oldmesh->elem[e].nbrs[i], e );
                                                if ( (vertex+1)%3 == common ){
                                                        newmesh->elem[newindex[e]].nbrs[i] = newindex[oldmesh->elem[e].nbrs[i]] +1;
                                                }else{
                                                        newmesh->elem[newindex[e]].nbrs[i] = newindex[oldmesh->elem[e].nbrs[i]];
                                                };
                                        }else{
                                                newmesh->elem[newindex[e]].nbrs[i] = newindex[oldmesh->elem[e].nbrs[i]];
                                        };
                                };
                        };
                };
        };

        count = oldmesh->num_total;
        // add the new global entries, all the new indexes are on edges between two old elements
        for( e=0; e<oldmesh->num_elem; e++ ){
                if ( to_refine[e] == 1 ){ // full refinement
                        // add the three new vertexes
                        for( j=0; j<3; j++ ){
                                newmesh->elem[newindex[e]+j].iLCglobalu[0] = oldmesh->elem[e].iLCglobalu[j];
                                i = oldmesh->elem[e].nbrs[j];
                                if ( (newmesh->elem[newindex[e]+3].iLCglobalu[j] == -2)&&( (i==-1)||(to_refine[ i ] == 1) ) ){
                                        // is a new vertex only if the neighbour is a 4 split, the two-split is handled below
                                        newmesh->elem[newindex[e]+3].iLCglobalu[j] = count;
                                        newmesh->elem[newindex[e]+(j+1)%3].iLCglobalu[1] = count;
                                        newmesh->elem[newindex[e]+(j+2)%3].iLCglobalu[2] = count;
                                        if ( i > -1 ){
						common = Mesh_GetCommonSide( oldmesh, i, e );
						i = newindex[i];
						newmesh->elem[ i+(common+1)%3 ].iLCglobalu[1] = count;
						newmesh->elem[ i+(common+2)%3 ].iLCglobalu[2] = count;
						newmesh->elem[ i+3 ].iLCglobalu[common] = count;
					};
                                        count++;
                                };
                        };
                }else if ( Mesh_CountNbrsToBeRefined( oldmesh, to_refine, e ) == 1 ){ // half refined
                        // add the indexes for the existing vertexes
                        vertex = Mesh_GetNbrsToBeRefinedIndex( oldmesh, to_refine, e );
                        for( j=1; j<3; j++ ){
                                newmesh->elem[newindex[e]  ].iLCglobalu[j] = oldmesh->elem[e].iLCglobalu[(vertex+j-1)%3];
                                newmesh->elem[newindex[e]+1].iLCglobalu[j] = oldmesh->elem[e].iLCglobalu[(vertex+j+1)%3];
                        };
                        // add the index for the new vertex
                        i = oldmesh->elem[e].nbrs[vertex];
                        common = Mesh_GetCommonSide( oldmesh, i, e );
                        i = newindex[i];
                        if ( newmesh->elem[ i+3 ].iLCglobalu[common] == -2 ){ // new vertex
                                // add a new index
                                newmesh->elem[newindex[e]  ].iLCglobalu[0] = count;
                                newmesh->elem[newindex[e]+1].iLCglobalu[0] = count;
                                newmesh->elem[ i+(common+1)%3 ].iLCglobalu[1] = count;
                                newmesh->elem[ i+(common+2)%3 ].iLCglobalu[2] = count;
                                newmesh->elem[ i+3 ].iLCglobalu[common] = count;
                                count++;
                        }else{
                                // perhaps this never gets called
                                newmesh->elem[newindex[e]  ].iLCglobalu[0] = newmesh->elem[ i+3 ].iLCglobalu[common];
                                newmesh->elem[newindex[e]+1].iLCglobalu[0] = newmesh->elem[ i+3 ].iLCglobalu[common];
                        };
                }else{ // this element has not been refined
                        for( j=0; j<3; j++ ){
                                newmesh->elem[newindex[e]].iLCglobalu[j] = oldmesh->elem[e].iLCglobalu[j];
                        };
                };
        };
        
        newmesh ->num_total = count;
        
        // set new values for the unknowns
        int *used_indx_u = (int*) malloc( count* sizeof(int) );
        int *used_indx_v = (int*) malloc( count* sizeof(int) );
        
        for( i=0; i<count; i++ ){
                used_indx_u[i] = -1;
                used_indx_v[i] = -1;
        };
        
        // mark the boundary elements
        for( e=0; e<oldmesh->num_elem; e++ ){
                if ( oldmesh->elem[e].bBoundary == 1 ){
                        // if this is a boundary element
                        if ( to_refine[e] == 1 ){ // full refinement
                                Mesh_setBoundaryIndexesLC( used_indx_u, used_indx_v, &(newmesh->elem[ newindex[e] ]) );
                                Mesh_setBoundaryIndexesLC( used_indx_u, used_indx_v, &(newmesh->elem[ newindex[e]+1 ]) );
                                Mesh_setBoundaryIndexesLC( used_indx_u, used_indx_v, &(newmesh->elem[ newindex[e]+2 ]) );
                                Mesh_setBoundaryIndexesLC( used_indx_u, used_indx_v, &(newmesh->elem[ newindex[e]+3 ]) );
                        }else if ( Mesh_CountNbrsToBeRefined( oldmesh, to_refine, e ) == 1 ){ // half refined
                                Mesh_setBoundaryIndexesLC( used_indx_u, used_indx_v, &(newmesh->elem[ newindex[e] ]) );
                                Mesh_setBoundaryIndexesLC( used_indx_u, used_indx_v, &(newmesh->elem[ newindex[e]+1 ]) );
                        }else{
                                Mesh_setBoundaryIndexesLC( used_indx_u, used_indx_v, &(newmesh->elem[ newindex[e] ]) );
                        };
                };
        };
        // mark non-boundary ones
        int countu = 0, countv = 0;
        for( e = 0; e < newmesh->num_elem; e++ ){
                Mesh_setUnknownIndexesLC( used_indx_u, &countu, used_indx_v, &countv, &(newmesh ->elem[e]) );
        };
        
        newmesh ->num_u = countu;
	newmesh ->num_v = countv;

        // free memory
        free( used_indx_v );
        free( used_indx_u );
        free( newindex );
};

void MeshWriteMesh( struct PDMesh *mesh, const char * filename ){
        int e;
	FILE * fout = fopen( filename, "w");
        fprintf(fout,"%d \n",mesh->num_elem);
        for( e=0; e<mesh->num_elem; e++ ){
                fprintf(fout,"%f %f %f %f %f %f %d %d %d %d %d %d %d %d %d %d %d %d %d\n",
                        mesh->elem[e].T.x[0],mesh->elem[e].T.y[0],
                        mesh->elem[e].T.x[1],mesh->elem[e].T.y[1],
                        mesh->elem[e].T.x[2],mesh->elem[e].T.y[2],
                        mesh->elem[e].bBoundary,
                        mesh->elem[e].iLCglobalu[0], mesh->elem[e].iLCglobalu[1], mesh->elem[e].iLCglobalu[2],
                        mesh->elem[e].iLCu[0], mesh->elem[e].iLCu[1], mesh->elem[e].iLCu[2],
                        mesh->elem[e].iLCv[0], mesh->elem[e].iLCv[1], mesh->elem[e].iLCv[2],
                        mesh->elem[e].nbrs[0], mesh->elem[e].nbrs[1], mesh->elem[e].nbrs[2] );
        };
        fclose( fout );
};

void MeshRead( struct PDMesh *mesh, const char *filename ){
        int e, i, r;
	FILE * fout = fopen( filename, "r");
        r = fscanf( fout, "%d",&(mesh->num_elem) );
        mesh ->elem = (struct MeshElement*) malloc( mesh->num_elem * sizeof( struct MeshElement ) );
        for( e=0; e<mesh->num_elem; e++ ){
                r = fscanf(fout,"%lf %lf %lf %lf %lf %lf %d %d %d %d %d %d %d %d %d %d %d %d %d\n",
                        &(mesh->elem[e].T.x[0]), &(mesh->elem[e].T.y[0]),
                        &(mesh->elem[e].T.x[1]), &(mesh->elem[e].T.y[1]),
                        &(mesh->elem[e].T.x[2]), &(mesh->elem[e].T.y[2]),
                        &(mesh->elem[e].bBoundary),
                        &(mesh->elem[e].iLCglobalu[0]), &(mesh->elem[e].iLCglobalu[1]), &(mesh->elem[e].iLCglobalu[2]),
                        &(mesh->elem[e].iLCu[0]), &(mesh->elem[e].iLCu[1]), &(mesh->elem[e].iLCu[2]),
                        &(mesh->elem[e].iLCv[0]), &(mesh->elem[e].iLCv[1]), &(mesh->elem[e].iLCv[2]),
                        &(mesh->elem[e].nbrs[0]), &(mesh->elem[e].nbrs[1]), &(mesh->elem[e].nbrs[2]) );
        };
        mesh->num_u = -1;
        mesh->num_v = -1;
        mesh->num_total = -1;
        for( e=0; e<mesh->num_elem; e++ ){
                for( i=0; i<3; i++ ){
                        if ( mesh->elem[e].iLCglobalu[i] > mesh->num_total ){ mesh->num_total = mesh->elem[e].iLCglobalu[i]; };
                        if ( mesh->elem[e].iLCu[i] > mesh->num_u ){ mesh->num_u = mesh->elem[e].iLCu[i]; };
                        if ( mesh->elem[e].iLCv[i] > mesh->num_v ){ mesh->num_v = mesh->elem[e].iLCv[i]; };
                };
        };
        // ofset the zero indexing
        mesh->num_u++;
        mesh->num_v++;
        mesh->num_total++;
        fclose( fout );
};

void MeshFree( struct PDMesh *mesh ){
	free( mesh ->elem );
	mesh->num_elem = 0;
	mesh->num_u = 0;
	mesh->num_v = 0;
	mesh->num_total = 0;
};

#endif
