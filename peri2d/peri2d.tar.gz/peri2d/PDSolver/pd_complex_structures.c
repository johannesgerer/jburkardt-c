/*
* This code isdistrubuted under GPLv3
* 
* Code Author: Miroslav Stoyanov, Nov 2011
* 
* Copyright (C) 2011  Miroslav Stoyanov
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* Since the GNU General Public License is longer than this entire code, 
* a copy of it can be obtained separately at <http://www.gnu.org/licenses/>
*/

#ifndef __PD_COMPLEX_STRUCTURES_C
#define __PD_COMPLEX_STRUCTURES_C

#include "pd_complex_structures.h"

#define OuterQuadFunction GeometryQuadratureAdd7PointsTriangle

double PD_QUADRATURE_TOLERANCE = 1.E-8;

double phi_0( double xi, double et ){ return (1.0 - xi - et); };
double phi_1( double xi, double et ){ return xi; };
double phi_2( double xi, double et ){ return et; };
double phi_3( double xi, double et ){ return 0.0; };
double phi_4( double xi, double et ){ return 1.0; };

double PDMesh_CanonicalIntegrateTwo( double (*f)( double, double ), double (*g)( double, double ) ){
	double w1 = 0.10995174365532;
	double w2 = 0.223381589678011;

	double p11 = 0.816847572980459;
	double p12 = 0.091576213509771;

	double p21 = 0.10810301816807;
	double p22 = 0.445948490915965;

	return 0.5* w1*( f(p11,p12) * g(p11,p12) + f(p12,p11) * g(p12,p11) + f(p12,p12) * g(p12,p12) ) +
		0.5* w2*( f(p21,p22) * g(p21,p22) + f(p22,p21) * g(p22,p21) + f(p22,p22) * g(p22,p22) );
};



int PDMesh_findFunction( int indx, int *DegreesOfFreedom ){
	if ( indx == DegreesOfFreedom[0] ){
		return 0;
	}else if ( indx == DegreesOfFreedom[1] ){
		return 1;
	}else if ( indx == DegreesOfFreedom[2] ){
		return 2;
	}else{
		return 3;
	};
};

void PDMEsh_integrateOverElement( double rootu, double rootv, double rootx, double rooty, double phiu, double phiv, 
					struct GeometryQuadrature Quad, 
					double *targetu, double *targetv,
					double (*kernel_u)(double,double,double,double,double,double,double,double),
					double (*kernel_v)(double,double,double,double,double,double,double,double),
					double (*phiup)(double,double), double (*phivp)(double,double),
					double *integu, double *integv ){
	int i;
	double up, vp;
	for( i=0; i<Quad.num_points; i++ ){
		up = ( 1.0 - Quad.xi[i] - Quad.et[i] ) * targetu[0] + Quad.xi[i] * targetu[1] + Quad.et[i] * targetu[2];
		vp = ( 1.0 - Quad.xi[i] - Quad.et[i] ) * targetv[0] + Quad.xi[i] * targetv[1] + Quad.et[i] * targetv[2];
		*integu += Quad.w[i] * kernel_u( up, vp, rootu, rootv, Quad.x[i], Quad.y[i], rootx, rooty ) * ( phiup( Quad.xi[i], Quad.et[i] ) - phiu );
		*integv += Quad.w[i] * kernel_v( up, vp, rootu, rootv, Quad.x[i], Quad.y[i], rootx, rooty ) * ( phivp( Quad.xi[i], Quad.et[i] ) - phiv );
	};
};

void PDMeshFormConnectivity( struct PDMesh *mesh, int current, struct GeometryDisk *C, double tolerance, int *conn ){
	if ( (GeometryTrianglePointInside(mesh->elem[current].T,C->x,C->y)==1) || (GeometryTriangleIntersectDiskAreaExact( mesh ->elem[current].T, C ) > tolerance) ){
		conn[current] = 1;
		int i;
		for( i=0; i<3; i++ ){
			if ( (mesh ->elem[current].nbrs[i] > -1) && (conn[mesh ->elem[current].nbrs[i]] == 0) ){
				PDMeshFormConnectivity( mesh, mesh ->elem[current].nbrs[i], C, tolerance, conn );
			};
		};
	};
};

void PDMeshLoadUVfromLCdf( struct PDMesh *mesh, double t, double *uv, double (*ux_bnd)(double,double,double), double (*uy_bnd)(double,double,double) ){
        //printf(" The entry: %f \n",uv[mesh->num_u] );
	int e, i;
#ifdef 	PD_USE_OPEN_MP
	int me, nthreads, start, end, length;
	#pragma omp parallel private(me, nthreads, start, end, length, e, i )
	{
		_PD_OMP_READ_SPLIT(me, nthreads, mesh->num_elem, start, end, length )
		for( e=start; e <= end; e++ ){
			for( i=0; i<3; i++ ){
				mesh ->elem[e].u[i] = ( mesh->elem[e].iLCu[i] > -1 ) ? uv[ mesh->elem[e].iLCu[i] ] : ux_bnd(t,mesh->elem[e].T.x[i],mesh->elem[e].T.y[i]);
				mesh ->elem[e].v[i] = ( mesh->elem[e].iLCv[i] > -1 ) ? uv[ mesh->num_u + mesh->elem[e].iLCv[i] ] : uy_bnd(t,mesh->elem[e].T.x[i],mesh->elem[e].T.y[i]);
			};
		};	
	};
#else
	for( e=0; e < mesh->num_elem; e++ ){
		for( i=0; i<3; i++ ){
			mesh ->elem[e].u[i] = ( mesh->elem[e].iLCu[i] > -1 ) ? uv[ mesh->elem[e].iLCu[i] ] : ux_bnd(t,mesh->elem[e].T.x[i],mesh->elem[e].T.y[i]);
			mesh ->elem[e].v[i] = ( mesh->elem[e].iLCv[i] > -1 ) ? uv[ mesh->num_u + mesh->elem[e].iLCv[i] ] : uy_bnd(t,mesh->elem[e].T.x[i],mesh->elem[e].T.y[i]);
		};
	};
#endif
};

void PDMeshSubstractExact( struct PDMesh *mesh, double t, double (*utrue)(double,double,double), double (*vtrue)(double,double,double) ){
        int e, i;
        for( e=0; e < mesh->num_elem; e++ ){
		for( i=0; i<3; i++ ){
			mesh ->elem[e].u[i] -= utrue( t, mesh->elem[e].T.x[i], mesh->elem[e].T.y[i] );
			mesh ->elem[e].v[i] -= vtrue( t, mesh->elem[e].T.x[i], mesh->elem[e].T.y[i] );
		};
	};
};


void PDMesIntegrateCLexternal( struct PDMesh *mesh, double t, double (*b_external_x)(double,double,double), double (*b_external_y)(double,double,double), double *B ){
	int e, i, j, bToInt;
	double integu[3], integv[3], bu, bv;
	double (**phi)(double, double);
	phi = ( double (**)(double,double) ) malloc( 4 * sizeof(  double (*)(double,double) ) );
	phi[0] = &phi_0;  phi[1] = &phi_1;  phi[2] = &phi_2;  phi[3] = &phi_3;
	struct MeshElement *elem;
	for( i=0; i<mesh->num_u + mesh->num_v; i++){
		B[i] = 0.0;
	};
	for( e=0; e<mesh->num_elem; e++ ){
		elem = &(mesh->elem[e]);
		bToInt = 0;
		for( i=0; i<3; i++ ){
			if ( (elem->iLCu[i]>-1)||(elem->iLCv[i]>-1) ){
				bToInt = 1;
				break;
			};
		};
		if ( bToInt == 1 ){
			for( i=0; i<3; i++ ){
				integu[i] = 0.0; integv[i] = 0.0;
			};
			for( i=0; i<elem->OuterQuad.num_points; i++ ){
				bu = b_external_x( t, elem->OuterQuad.x[i], elem->OuterQuad.y[i] );
				bv = b_external_y( t, elem->OuterQuad.x[i], elem->OuterQuad.y[i] );
				for( j=0; j<3; j++ ){
					integu[j] += elem->OuterQuad.w[i] * phi[j]( elem->OuterQuad.xi[i], elem->OuterQuad.et[i] ) * bu;
					integv[j] += elem->OuterQuad.w[i] * phi[j]( elem->OuterQuad.xi[i], elem->OuterQuad.et[i] ) * bv;
				};
			};
			// store the results in the vector
			for( i=0; i<3; i++ ){
				if ( elem->iLCu[i] > -1 ){
					B[elem->iLCu[i]] += integu[i];
				};
				if ( elem->iLCv[i] > -1 ){
					B[mesh->num_u+elem->iLCv[i]] += integv[i];
				};
			};
		};
	};
        elem = NULL;
        free( phi );
};

void PDMeshProjectFunctionOnMesh( struct PDMesh *mesh, double t, double (*fu)(double,double,double), double (*fv)(double,double,double), double *F ){
        int e, i;
        for( e=0; e<mesh->num_elem; e++ ){
                for( i=0; i<3; i++ ){
                        if ( mesh->elem[e].iLCu[i] > -1 ){
                                F[mesh->elem[e].iLCu[i]] = fu( t, mesh->elem[e].T.x[i], mesh->elem[e].T.y[i] );
                        };
                        if ( mesh->elem[e].iLCv[i] > -1 ){
                                F[mesh->num_u+mesh->elem[e].iLCv[i]] = fv( t, mesh->elem[e].T.x[i], mesh->elem[e].T.y[i] );
                        };
                };
        };
};

void PDMeshFormOperator( struct PDMesh *mesh, double (*kernel_x)(double,double,double,double,double,double,double,double), double (*kernel_y)(double,double,double,double,double,double,double,double), double delta, struct SMPACKPmat *A ){
	int e, i, j, k, l, count;
#ifdef 	PD_USE_OPEN_MP
	int **conn = (int**) malloc( _PD_OMP_MAX_NUM_THREADS * sizeof(int*) );
	for( i=0; i<_PD_OMP_MAX_NUM_THREADS; i++){
		conn[i] = (int*) malloc( mesh->num_elem * sizeof( int ) );
	};
#else
	int *conn = (int*) malloc( mesh->num_elem * sizeof( int ) );
#endif

	struct GeometryDynamicQuadrature *DC = NULL;
	
	double (**phi)(double, double);
	phi = ( double   (**)(double,double) ) malloc( 4 * sizeof(  double (*)(double,double)  )  );
	phi[0] = &phi_0;  phi[1] = &phi_1;  phi[2] = &phi_2;  phi[3] = &phi_3;
	
	// temp values corresponding to each element
#ifdef 	PD_USE_OPEN_MP
        struct GeometryDisk *C = (struct GeometryDisk*) malloc( _PD_OMP_MAX_NUM_THREADS * sizeof(struct GeometryDisk) ); 
	struct GeometryQuadrature *OuterQuad = (struct GeometryQuadrature *) malloc( _PD_OMP_MAX_NUM_THREADS * sizeof(struct GeometryQuadrature) );
	struct GeometryQuadrature *InnerQuad = (struct GeometryQuadrature *) malloc( _PD_OMP_MAX_NUM_THREADS * sizeof(struct GeometryQuadrature) );
#else
        struct GeometryDisk C;
	struct GeometryQuadrature OuterQuad;
	struct GeometryQuadrature InnerQuad;
#endif
	int targete;
	double u[3], v[3];
	double integu, integv;
	double rootu, rootv, rootx, rooty, phiu, phiv;
	
	struct SMPACKSpattern p; // the pattern
	
	smpack_spattern_init( &p, mesh->num_u+mesh->num_v );
	
#ifdef 	PD_USE_OPEN_MP
	int me, nthreads, startu, endu, lengthu, startv, endv, lengthv, bMine;
	#pragma omp parallel private(me,nthreads,startu,endu,lengthu,startv,endv,lengthv,e,i,j,k,l,bMine )
	{
		_PD_OMP_READ_SPLIT(me, nthreads, mesh->num_u, startu, endu, lengthu )
		_PD_OMP_JUST_SPLIT(me, nthreads, mesh->num_v, startv, endv, lengthv )
		
		// form the matrix pattern
		for( e=0; e < mesh->num_elem; e++ ){
			bMine = 0;
			for( i=0; i<3; i++ ){
				if ( ((mesh->elem[e].iLCu[i] >= startu)&&(mesh->elem[e].iLCu[i] <= endu))||((mesh->elem[e].iLCv[i] >= startv)&&(mesh->elem[e].iLCv[i] <= endv)) ){
					bMine = 1;
					//printf(" me = %d  mine is: %d\n",me,e);
					break;
				};
			};
			
			if ( bMine == 1 ){
				// form the outer quadrature
				OuterQuadFunction( mesh->elem[e].T, &(mesh->elem[e].OuterQuad) );
				GeometryTriangleSetXiEt( mesh->elem[e].T, &(mesh->elem[e].OuterQuad) );
				// find the connectivity
				for( i=0; i<mesh->elem[e].OuterQuad.num_points; i++ ){
					// reset the connectivity
					for( j=0; j < mesh->num_elem; j++ ){ conn[me][j] = 0; };
					// build the connectivity
					C[me].x = mesh->elem[e].OuterQuad.x[i];
					C[me].y = mesh->elem[e].OuterQuad.y[i];
					C[me].r = delta;
					PDMeshFormConnectivity( mesh, e, &(C[me]), PD_QUADRATURE_TOLERANCE*(delta * delta * 3.141592653589793), conn[me] );
                                        count = 0;
					for( j=0; j < mesh->num_elem; j++ ){ count += conn[me][j]; };
					// add the relations
					for( j=0; j < mesh->num_elem; j++ ){
						if ( conn[me][j] == 1 ){
							for( k=0; k<3; k++ ){
								if ( (mesh->elem[e].iLCu[k] >= startu)&&(mesh->elem[e].iLCu[k] <= endu) ){
									for( l=0; l<3; l++ ){
										if ( mesh->elem[j].iLCu[l] > -1 ){
											smpack_spattern_add( &p, mesh->elem[e].iLCu[k], mesh->elem[j].iLCu[l] );
										};
									};
								};
								if ( (mesh->elem[e].iLCv[k] >= startv)&&(mesh->elem[e].iLCv[k] <= endv) ){
									for( l=0; l<3; l++ ){
										if ( mesh->elem[j].iLCv[l] > -1 ){
											smpack_spattern_add( &p, mesh->num_u + mesh->elem[e].iLCv[k], mesh->num_u + mesh->elem[j].iLCv[l] );
										};
									};
								};
							};
						};
					};
				};
			};
		};
	}
#else
	// form the matrix pattern
	for( e=0; e < mesh->num_elem; e++ ){
		// form the outer quadrature
		OuterQuadFunction( mesh->elem[e].T, &(mesh->elem[e].OuterQuad) );
		GeometryTriangleSetXiEt( mesh->elem[e].T, &(mesh->elem[e].OuterQuad) );
		// find the connectivity
		for( i=0; i<mesh->elem[e].OuterQuad.num_points; i++ ){
			// reset the connectivity
			for( j=0; j < mesh->num_elem; j++ ){ conn[j] = 0; };
			// build the connectivity
			C.x = mesh->elem[e].OuterQuad.x[i];
			C.y = mesh->elem[e].OuterQuad.y[i];
			C.r = delta;
			PDMeshFormConnectivity( mesh, e, &C, PD_QUADRATURE_TOLERANCE*(delta * delta * 3.141592653589793), conn );
                        count = 0;
			for( j=0; j < mesh->num_elem; j++ ){ count += conn[j]; };
			// add the relations
			for( j=0; j < mesh->num_elem; j++ ){
				if ( conn[j] == 1 ){
					for( k=0; k<3; k++ ){
						if ( mesh->elem[e].iLCu[k] > -1 ){
							for( l=0; l<3; l++ ){
								if ( mesh->elem[j].iLCu[l] > -1 ){
									smpack_spattern_add( &p, mesh->elem[e].iLCu[k], mesh->elem[j].iLCu[l] );
								};
							};
						};
						if ( mesh->elem[e].iLCv[k] > -1 ){
							for( l=0; l<3; l++ ){
								if ( mesh->elem[j].iLCv[l] > -1 ){
									smpack_spattern_add( &p, mesh->num_u + mesh->elem[e].iLCv[k], mesh->num_u + mesh->elem[j].iLCv[l] );
								};
							};
						};
					};
				};
			};
		};
	};
#endif

	// form the matrix with the right pattern
	smpack_pmat_create( A, &p );
	smpack_spattern_del( &p );
	
	for( l=0; l<3; l++ ){ u[l] = 0.0; v[l] = 0.0; }; // initialize the u and v values
	
	//omp_set_num_threads(4);
	
#ifdef 	PD_USE_OPEN_MP
	#pragma omp parallel private(me,nthreads,startu,endu,lengthu,startv,endv,lengthv,e,i,j,k,l,bMine,count,targete,u,v,integu,integv,rootu,rootv,rootx,rooty,DC )
	{
		_PD_OMP_READ_SPLIT(me, nthreads, mesh->num_u, startu, endu, lengthu )
		_PD_OMP_JUST_SPLIT(me, nthreads, mesh->num_v, startv, endv, lengthv )
		DC = NULL;
		
		// load the matrix entries
		for( e=0; e < mesh->num_elem; e++ ){
			bMine = 0;
			//if ( e % 10 == 0 ){ printf(" I am %d reached %d\n",me,e); };
			for( i=0; i<3; i++ ){
				if ( ((mesh->elem[e].iLCu[i] >= startu)&&(mesh->elem[e].iLCu[i] <= endu))||((mesh->elem[e].iLCv[i] >= startv)&&(mesh->elem[e].iLCv[i] <= endv)) ){
					bMine = 1;
					break;
				};
			};
			if ( bMine == 1 ){
				// form the outer quadrature
				OuterQuadFunction( mesh->elem[e].T, &(OuterQuad[me]) );
				GeometryTriangleSetXiEt( mesh->elem[e].T, &(OuterQuad[me]) );
				// find the connectivity
				for( i=0; i<OuterQuad[me].num_points; i++ ){
					// reset the connectivity
					for( j=0; j < mesh->num_elem; j++ ){ conn[me][j] = 0; };
					// build the connectivity
					C[me].x = OuterQuad[me].x[i];
					C[me].y = OuterQuad[me].y[i];
					C[me].r = delta;
					//PDMeshFormConnectivity( mesh, e, &(C[me]), PD_QUADRATURE_TOLERANCE, conn[me] );
					PDMeshFormConnectivity( mesh, e, &(C[me]), PD_QUADRATURE_TOLERANCE*(delta * delta * 3.141592653589793), conn[me] );
					// count the elements connected to this element
					count = 0;
					for( j=0; j < mesh->num_elem; j++ ){ count += conn[me][j]; };

					// integrate over the connected elements
					for( targete=0; targete < mesh->num_elem; targete++ ){ 
						if ( conn[me][targete] == 1 ){
							// elements are connected, add the integral associated with this element and this outer quad point                                                        
                                                        C[me].x = OuterQuad[me].x[i]; C[me].y = OuterQuad[me].y[i]; C[me].r = delta;

							GeometryDynamicQuadratureTriangleDiskIntersection( mesh->elem[targete].T, &(C[me]), &DC );
							GeometryDynamicQuadrature2GeometryQuadrature( DC, &(InnerQuad[me]) );
							GeometryTriangleSetXiEt( mesh ->elem[ targete ].T, &(InnerQuad[me]) );
							GeometryDynamicQuadratureFree( &DC );
							// need to do the integration
							if ( e == targete ){
								for( k=0; k<3; k++ ){ // for each one of the test functions
									for( l=0; l<3; l++ ){ // for the unknow functions in the solution
										if ( mesh ->elem[targete].iLCu[l] > -1 ){
											u[l] = 1.0;
											integu = 0.0;
											integv = 0.0;
											// root element parameters
											rootu = phi[l]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ); // variation root element u
											rootv = 0.0;
											PDMEsh_integrateOverElement( rootu, rootv, OuterQuad[me].x[i], OuterQuad[me].y[i], phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ), phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ),
												InnerQuad[me],
												u, v,
												kernel_x, kernel_y,
												phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
												&integu, &integv );
											u[l] = 0.0;
											// add the integral values for the kernels (u/v) for the variable l
											if ( (mesh->elem[e].iLCu[k] >= startu)&&(mesh->elem[e].iLCu[k] <= endu) ){
												smpack_pmat_addval( A, mesh->elem[e].iLCu[k], mesh ->elem[targete].iLCu[l], -OuterQuad[me].w[i]*integu );
												// we should consider the anisotropic case and add values for the test function in v vs variables in u
											};
										};
										if ( mesh ->elem[targete].iLCv[l] > -1 ){
											v[l] = 1.0;
											integu = 0.0;
											integv = 0.0;
											// root element parameters
											rootu = 0.0;
											rootv = phi[l]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ); // variation root element u
											PDMEsh_integrateOverElement( rootu, rootv, OuterQuad[me].x[i], OuterQuad[me].y[i], phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ), phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ),
												InnerQuad[me],
												u, v,
												kernel_x, kernel_y,
												phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
												&integu, &integv );
											v[l] = 0.0;
											// add the integral values for the kernels (u/v) for the variable l
											if ( (mesh->elem[e].iLCv[k] >= startv)&&(mesh->elem[e].iLCv[k] <= endv) ){
												smpack_pmat_addval( A, mesh->elem[e].iLCv[k] + mesh->num_u, mesh ->elem[targete].iLCv[l] + mesh->num_u, -OuterQuad[me].w[i]*integv );
												// we should consider the anisotropic case and add values for the test function in v vs variables in u
											};
										};
									};
								};
							}else{
								for( k=0; k<3; k++ ){ // for each one of the test functions
									for( l=0; l<3; l++ ){ // for the unknow functions in the solution
										if ( mesh ->elem[targete].iLCu[l] > -1 ){
											u[l] = 1.0; // variation in target element u
											integu = 0.0;
											integv = 0.0;
											// root element parameters
											rootu = 0.0;
											rootv = 0.0;
											PDMEsh_integrateOverElement( rootu, rootv, OuterQuad[me].x[i], OuterQuad[me].y[i], phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ), phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ),
												InnerQuad[me],
												u, v,
												kernel_x, kernel_y,
												phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
												&integu, &integv );
											u[l] = 0.0;
											// add the integral values for the kernels (u/v) for the variable l
											if ( (mesh->elem[e].iLCu[k] >= startu)&&(mesh->elem[e].iLCu[k] <= endu) ){
												smpack_pmat_addval( A, mesh->elem[e].iLCu[k], mesh ->elem[targete].iLCu[l], -OuterQuad[me].w[i]*integu );
												// we should consider the anisotropic case and add values for the test function in v vs variables in u
											};
										};
										if ( mesh ->elem[targete].iLCv[l] > -1 ){
											v[l] = 1.0; // variation in target element v
											integu = 0.0;
											integv = 0.0;
											// root element parameters
											rootu = 0.0;
											rootv = 0.0;
											PDMEsh_integrateOverElement( rootu, rootv, OuterQuad[me].x[i], OuterQuad[me].y[i], phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ), phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ),
												InnerQuad[me],
												u, v,
												kernel_x, kernel_y,
												phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
												&integu, &integv );
											v[l] = 0.0;
											// add the integral values for the kernels (u/v) for the variable l
											if ( (mesh->elem[e].iLCv[k] >= startv)&&(mesh->elem[e].iLCv[k] <= endv) ){
												smpack_pmat_addval( A, mesh->elem[e].iLCv[k] + mesh->num_u, mesh ->elem[targete].iLCv[l] + mesh->num_u, -OuterQuad[me].w[i]*integv );
												// we should consider the anisotropic case and add values for the test function in v vs variables in u
											};
										};
										if ( mesh ->elem[e].iLCu[l] > -1 ){
											integu = 0.0;
											integv = 0.0;
											// root element parameters
			                                                                rootu = phi[l]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ); // variation root element u
											rootv = 0.0;
											PDMEsh_integrateOverElement( rootu, rootv, OuterQuad[me].x[i], OuterQuad[me].y[i], phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ), phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ),
												InnerQuad[me],
												u, v,
												kernel_x, kernel_y,
												phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
												&integu, &integv );
											// add the integral values for the kernels (u/v) for the variable l
											if ( (mesh->elem[e].iLCu[k] >= startu)&&(mesh->elem[e].iLCu[k] <= endu) ){
												smpack_pmat_addval( A, mesh->elem[e].iLCu[k], mesh ->elem[e].iLCu[l], -OuterQuad[me].w[i]*integu );
												// we should consider the anisotropic case and add values for the test function in v vs variables in u
											};
										};
										if ( mesh ->elem[e].iLCv[l] > -1 ){
											integu = 0.0;
											integv = 0.0;
											// root element parameters
											rootu = 0.0;
											rootv = phi[l]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ); // variation root element v
											PDMEsh_integrateOverElement( rootu, rootv, OuterQuad[me].x[i], OuterQuad[me].y[i], phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ), phi[k]( OuterQuad[me].xi[i], OuterQuad[me].et[i] ),
												InnerQuad[me],
												u, v,
												kernel_x, kernel_y,
												phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
												&integu, &integv );
											// add the integral values for the kernels (u/v) for the variable l
											if ( (mesh->elem[e].iLCv[k] >= startv)&&(mesh->elem[e].iLCv[k] <= endv) ){
												smpack_pmat_addval( A, mesh->elem[e].iLCv[k] + mesh->num_u, mesh ->elem[e].iLCv[l] + mesh->num_u, -OuterQuad[me].w[i]*integv );
												// we should consider the anisotropic case and add values for the test function in v vs variables in u
											};
										};
									};
								};
							};
							GeometryQuadratureFree( &(InnerQuad[me]) );
						};
					};
				};
				GeometryQuadratureFree( &(OuterQuad[me]) );
			};
		};
	};
#else
	// load the matrix entries
	for( e=0; e < mesh->num_elem; e++ ){
		// form the outer quadrature
		OuterQuadFunction( mesh->elem[e].T, &OuterQuad );
		GeometryTriangleSetXiEt( mesh->elem[e].T, &OuterQuad );
		// find the connectivity
		for( i=0; i<OuterQuad.num_points; i++ ){
			// reset the connectivity
			for( j=0; j < mesh->num_elem; j++ ){ conn[j] = 0; };
			// build the connectivity
			C.x = OuterQuad.x[i];
			C.y = OuterQuad.y[i];
			C.r = delta;
			PDMeshFormConnectivity( mesh, e, &C, PD_QUADRATURE_TOLERANCE*(delta * delta * 3.141592653589793), conn );
			// count the elements connected to this element
			count = 0;
			for( j=0; j < mesh->num_elem; j++ ){ count += conn[j]; };
			// integrate over the connected elements
			for( targete=0; targete < mesh->num_elem; targete++ ){ 
				if ( conn[targete] == 1 ){
					// elements are connected, add the integral associated with this element and this outer quad point
					GeometryDynamicQuadratureTriangleDiskIntersection( mesh->elem[targete].T, &C, &DC );
					GeometryDynamicQuadrature2GeometryQuadrature( DC, &InnerQuad );
					GeometryTriangleSetXiEt( mesh ->elem[ targete ].T, &InnerQuad );
					GeometryDynamicQuadratureFree( &DC );
					// need to do the integration
					if ( e == targete ){
						for( k=0; k<3; k++ ){ // for each one of the test functions
							for( l=0; l<3; l++ ){ // for the unknow functions in the solution
								if ( mesh ->elem[targete].iLCu[l] > -1 ){
									u[l] = 1.0;
									integu = 0.0;
									integv = 0.0;
									// root element parameters
									rootu = ( 1.0 - OuterQuad.xi[i] - OuterQuad.et[i])*u[0] + OuterQuad.xi[i]*u[1] + OuterQuad.et[i]*u[2];
									rootv = 0.0;
									PDMEsh_integrateOverElement( rootu, rootv, OuterQuad.x[i], OuterQuad.y[i], phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ), phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ),
										InnerQuad,
										u, v,
										kernel_x, kernel_y,
										phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
										&integu, &integv );
									u[l] = 0.0;
									// add the integral values for the kernels (u/v) for the variable l
									if ( mesh->elem[e].iLCu[k] > -1 ){
										smpack_pmat_addval( A, mesh->elem[e].iLCu[k], mesh ->elem[targete].iLCu[l], -OuterQuad.w[i]*integu );
										// we should consider the anisotropic case and add values for the test function in v vs variables in u
									};
								};
								if ( mesh ->elem[targete].iLCv[l] > -1 ){
									v[l] = 1.0;
									integu = 0.0;
									integv = 0.0;
									// root element parameters
									rootu = 0.0;
									rootv = ( 1.0 - OuterQuad.xi[i] - OuterQuad.et[i])*v[0] + OuterQuad.xi[i]*v[1] + OuterQuad.et[i]*v[2];
									PDMEsh_integrateOverElement( rootu, rootv, OuterQuad.x[i], OuterQuad.y[i], phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ), phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ),
										InnerQuad,
										u, v,
										kernel_x, kernel_y,
										phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
										&integu, &integv );
									v[l] = 0.0;
									// add the integral values for the kernels (u/v) for the variable l
									if ( mesh->elem[e].iLCv[k] > -1 ){
										smpack_pmat_addval( A, mesh->elem[e].iLCv[k] + mesh->num_u, mesh ->elem[targete].iLCv[l] + mesh->num_u, -OuterQuad.w[i]*integv );
										// we should consider the anisotropic case and add values for the test function in v vs variables in u
									};
								};
							};
						};
					}else{
						for( k=0; k<3; k++ ){ // for each one of the test functions
							for( l=0; l<3; l++ ){ // for the unknow functions in the solution
								if ( mesh ->elem[targete].iLCu[l] > -1 ){
									u[l] = 1.0; // variation in target element u
									integu = 0.0;
									integv = 0.0;
									// root element parameters
									rootu = 0.0;
									rootv = 0.0;
									PDMEsh_integrateOverElement( rootu, rootv, OuterQuad.x[i], OuterQuad.y[i], phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ), phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ),
										InnerQuad,
										u, v,
										kernel_x, kernel_y,
										phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
										&integu, &integv );
									u[l] = 0.0;
									// add the integral values for the kernels (u/v) for the variable l
									if ( mesh->elem[e].iLCu[k] > -1 ){
										smpack_pmat_addval( A, mesh->elem[e].iLCu[k], mesh ->elem[targete].iLCu[l], -OuterQuad.w[i]*integu );
										// we should consider the anisotropic case and add values for the test function in v vs variables in u
									};
								};
								if ( mesh ->elem[targete].iLCv[l] > -1 ){
									v[l] = 1.0; // variation in target element v
									integu = 0.0;
									integv = 0.0;
									// root element parameters
									rootu = 0.0;
									rootv = 0.0;
									PDMEsh_integrateOverElement( rootu, rootv, OuterQuad.x[i], OuterQuad.y[i], phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ), phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ),
										InnerQuad,
										u, v,
										kernel_x, kernel_y,
										phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
										&integu, &integv );
									v[l] = 0.0;
									// add the integral values for the kernels (u/v) for the variable l
									if ( mesh->elem[e].iLCv[k] > -1 ){
										smpack_pmat_addval( A, mesh->elem[e].iLCv[k] + mesh->num_u, mesh ->elem[targete].iLCv[l] + mesh->num_u, -OuterQuad.w[i]*integv );
										// we should consider the anisotropic case and add values for the test function in v vs variables in u
									};
								};
								if ( mesh ->elem[e].iLCu[l] > -1 ){
									integu = 0.0;
									integv = 0.0;
									// root element parameters
	                                                                rootu = phi[l]( OuterQuad.xi[i], OuterQuad.et[i] ); // variation root element u
									rootv = 0.0;
									PDMEsh_integrateOverElement( rootu, rootv, OuterQuad.x[i], OuterQuad.y[i], phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ), phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ),
										InnerQuad,
										u, v,
										kernel_x, kernel_y,
										phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
										&integu, &integv );
									// add the integral values for the kernels (u/v) for the variable l
									if ( mesh->elem[e].iLCu[k] > -1 ){
										smpack_pmat_addval( A, mesh->elem[e].iLCu[k], mesh ->elem[e].iLCu[l], -OuterQuad.w[i]*integu );
										// we should consider the anisotropic case and add values for the test function in v vs variables in u
									};
								};
								if ( mesh ->elem[e].iLCv[l] > -1 ){
									integu = 0.0;
									integv = 0.0;
									// root element parameters
									rootu = 0.0;
									rootv = phi[l]( OuterQuad.xi[i], OuterQuad.et[i] ); // variation root element v
									PDMEsh_integrateOverElement( rootu, rootv, OuterQuad.x[i], OuterQuad.y[i], phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ), phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ),
										InnerQuad,
										u, v,
										kernel_x, kernel_y,
										phi[ PDMesh_findFunction( mesh->elem[e].iLCu[k], mesh ->elem[ targete ].iLCu )], phi[ PDMesh_findFunction( mesh->elem[e].iLCv[k], mesh ->elem[ targete ].iLCv ) ],
										&integu, &integv );
									// add the integral values for the kernels (u/v) for the variable l
									if ( mesh->elem[e].iLCv[k] > -1 ){
										smpack_pmat_addval( A, mesh->elem[e].iLCv[k] + mesh->num_u, mesh ->elem[e].iLCv[l] + mesh->num_u, -OuterQuad.w[i]*integv );
										// we should consider the anisotropic case and add values for the test function in v vs variables in u
									};
								};
							};
						};
					};
					GeometryQuadratureFree( &InnerQuad );
				};
			};
		};
		GeometryQuadratureFree( &OuterQuad );
	};
#endif

#ifdef 	PD_USE_OPEN_MP
	free( OuterQuad );
	free( InnerQuad );
	for( i=0; i<_PD_OMP_MAX_NUM_THREADS; i++ ){
		free( conn[i] );
	};
	free( conn );
#else
	free( conn );
#endif
	free( phi );
};

void PDTestIntegration(  struct PDMesh *mesh, double (*kernel_x)(double,double,double,double,double,double,double,double), double (*kernel_y)(double,double,double,double,double,double,double,double), double delta, struct SMPACKPmat *A ){
	// load the matrix entries
        int e, i, j,k, l, targete, count;
        int *conn = (int*) malloc( mesh->num_elem * sizeof( int ) );
        struct GeometryQuadrature InnerQuad;
        struct GeometryQuadrature OuterQuad;
        struct GeometryDynamicQuadrature *DC; DC = NULL;
        struct GeometryDisk C;
        
        double rootu, rootv, u[3], v[3], integu, integv;
        
        int TestElement = -1;
        double testVal = 0.0;
        double exactVal = 0.0;
        
        e = 0;
        while( TestElement == -1 ){
                for( i=0; i<3; i++ ){
                        if ( (fabs( mesh->elem[e].T.x[i] - 0.5 ) < delta)&&(fabs( mesh->elem[e].T.y[i] - 0.5 ) < delta) ){
                                TestElement = e;
                        };
                };
                e++;
        };
        printf(" Test Element: %d\n",TestElement);
        
        double (**phi)(double, double);
	phi = ( double   (**)(double,double) ) malloc( 4 * sizeof(  double (*)(double,double)  )  );
	phi[0] = &phi_0;  phi[1] = &phi_1;  phi[2] = &phi_2;  phi[3] = &phi_3;
        
	for( e=TestElement; e <= TestElement; e++ ){
		// form the outer quadrature
		OuterQuadFunction( mesh->elem[e].T, &OuterQuad );
		GeometryTriangleSetXiEt( mesh->elem[e].T, &OuterQuad );
		// find the connectivity
		for( i=0; i<OuterQuad.num_points; i++ ){
                        exactVal += phi_0( OuterQuad.xi[i], OuterQuad.et[i] ) * OuterQuad.w[i] * delta * delta * 3.141592653589793;
                        //printf("  Exact phi value: %f\n",phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ) );
			// reset the connectivity
			for( j=0; j < mesh->num_elem; j++ ){ conn[j] = 0; };
			// build the connectivity
			C.x = OuterQuad.x[i];
			C.y = OuterQuad.y[i];
			C.r = delta;
			//printf(" Tol 1: %f\n",PD_QUADRATURE_TOLERANCE*(delta * delta * 3.141592653589793) );
			//printf(" Tol 2: %f\n",PD_QUADRATURE_TOLERANCE );
                        //printf(" Element area: %f\n",mesh->elem[e].T.det*0.5);
			//PDMeshFormConnectivity( mesh, e, &C, PD_QUADRATURE_TOLERANCE, conn );
			PDMeshFormConnectivity( mesh, e, &C, PD_QUADRATURE_TOLERANCE*(delta * delta * 3.141592653589793), conn );
			count = 0; for( j=0; j < mesh->num_elem; j++ ){ count += conn[j]; };
			
			//printf(" NBR = %d \n",mesh->elem[TestElement].nbrs[1]);
			//printf(" Area Brute: %f\n",GeometryTriangleIntersectDiskAreaBrute(mesh->elem[302].T, &C,1.E-8)  );
			//printf(" Area Exact: %f\n",GeometryTriangleIntersectDiskAreaExact(mesh->elem[302].T,&C) );
			//printf(" %f %f %f %f %f %f\n",mesh->elem[302].T.x[0],mesh->elem[302].T.y[0],mesh->elem[302].T.x[1],mesh->elem[302].T.y[1],mesh->elem[302].T.x[2],mesh->elem[302].T.y[2]);
			//printf(" %f %f %f\n",C.x,C.y,C.r);
			
			//PDMeshFormConnectivity( mesh, e, &C, PD_QUADRATURE_TOLERANCE, conn );
			// count the elements connected to this element
                        //printf(" x= %f y= %f\n",OuterQuad.x[i], OuterQuad.y[i]);
                        //printf(" %d\n",j);
                        // PASS 2
                        //for( j=0; j < mesh->num_elem; j++ ){ conn[j] = 0; };
                        //PDMeshFormConnectivity( mesh, OuterQuad.x[i], OuterQuad.y[i], e, delta, PD_QUADRATURE_TOLERANCE / ((double) count), conn );
                        //count = 0;
                        //for( j=0; j < mesh->num_elem; j++ ){ count += conn[j]; };
                        
			// integrate over the connected elements
                        //printf(" HERE 1 num elements = %d   e = %d \n",mesh->num_elem, e);
                        //printf(" Eleemnts Connected to e = %d and point i = %d \n",e, i);
                        //printf(" Count = %d   x = %f  y = %f\n",count,OuterQuad.x[i],OuterQuad.y[i] );
			for( targete=0; targete < mesh->num_elem; targete++ ){ 
                                //printf(" HERE 1.1  target = %d \n",targete);
				if ( conn[targete] == 1 ){
					//printf(" Connected to target = %d \n",targete);
					//printf("%d\n",targete);
					// elements are connected, add the integral associated with this element and this outer quad point
					GeometryDynamicQuadratureTriangleDiskIntersection( mesh->elem[targete].T, &C, &DC );
					GeometryDynamicQuadrature2GeometryQuadrature( DC, &InnerQuad );
					GeometryTriangleSetXiEt( mesh ->elem[ targete ].T, &InnerQuad );
					GeometryDynamicQuadratureFree( &DC );
					// need to do the integration
                                        //printf(" HERE 2 \n");
					if ( e == targete ){
                                                //printf(" HERE 3 \n");
                                                k = 0; // integrave vs the k = 0 test function
                                                integu = 0.0;
                                                integv = 0.0;
                                                u[0] = 0.0; u[1] = 0.0; u[2] = 0.0;
                                                v[0] = 0.0; v[1] = 0.0; v[2] = 0.0;
                                                PDMEsh_integrateOverElement( rootu, rootv, OuterQuad.x[i], OuterQuad.y[i], phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ), phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ),
                                                        InnerQuad,
                                                        u, v,
                                                        kernel_x, kernel_y,
                                                        &phi_3, &phi_3,
                                                        &integu, &integv );
                                                //printf(" Self Area Appox: %2.16f\n",-integu);
                                                //printf(" Self Area Exact: %2.16f\n",phi[k]( OuterQuad.xi[i], OuterQuad.et[i] )*GeometryTriangleIntersectDiskAreaBrute(mesh->elem[targete].T, &C,1.E-8) );
                                                testVal -= OuterQuad.w[i] * integu;
					}else{
                                                //printf(" HERE 4 \n");
                                                k = 0; // integrave vs the k = 0 test function
                                                integu = 0.0;
                                                integv = 0.0;
                                                u[0] = 0.0; u[1] = 0.0; u[2] = 0.0;
                                                v[0] = 0.0; v[1] = 0.0; v[2] = 0.0;
                                                PDMEsh_integrateOverElement( rootu, rootv, OuterQuad.x[i], OuterQuad.y[i], phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ), phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ),
                                                        InnerQuad,
                                                        u, v,
                                                        kernel_x, kernel_y,
                                                        &phi_3, &phi_3,
                                                        &integu, &integv );
                                                //printf(" Other Area Appox: %2.16f\n",-integu);
                                                //printf(" Other Area Exact: %2.16f\n",phi[k]( OuterQuad.xi[i], OuterQuad.et[i] )*GeometryTriangleIntersectDiskAreaBrute(mesh->elem[e].T, &C,1.E-8) );
                                                //printf(" Error: %2.16f\n",phi[k]( OuterQuad.xi[i], OuterQuad.et[i] )*GeometryTriangleIntersectDiskAreaBrute(mesh->elem[targete].T, &C,1.E-8) + integu );
                                                //printf("  phi value: %f\n",phi[k]( OuterQuad.xi[i], OuterQuad.et[i] ) );
                                                testVal -= OuterQuad.w[i] * integu;
                                                //printf(" HERE 5 \n");
					};
                                        //printf(" HERE 6 \n");
					GeometryQuadratureFree( &InnerQuad );
				};
			};
		};
		GeometryQuadratureFree( &OuterQuad );
	};
        printf(" Test Value = %2.16f \n",testVal);
        printf(" Expected   = %2.16f\n",exactVal);
        printf(" Error %2.16f \n",fabs(testVal-exactVal) );
        printf(" Relative Error %2.16f \n",100*fabs(testVal-exactVal)/fabs(exactVal) );
};

void PDMeshFormMass( struct PDMesh *mesh, struct SMPACKPmat *M ){
        int e, i, j;
        
        double D[3][3];
        double (**f)(double, double);
        f = ( double (**)(double,double) ) malloc( 3 * sizeof( double (*)(double,double) ) );
        f[0] = &phi_0; f[1] = &phi_1; f[2] = &phi_2;
        
        for( i=0; i<3; i++ ){
                for( j=0; j<3; j++ ){
                        D[i][j] = PDMesh_CanonicalIntegrateTwo( f[i], f[j] );
                };
        };
        
        // create the pattern
        struct SMPACKSpattern p;
	smpack_spattern_init( &p, mesh -> num_u + mesh -> num_v );
        //printf(" Size: %d\n",mesh -> num_u + mesh -> num_v);
        
        for( e=0; e<mesh->num_elem; e++ ){
		for( i=0; i<3; i++ ){
			for( j=0; j<3; j++ ){
				if ( (mesh->elem[e].iLCu[i] > -1) && (mesh->elem[e].iLCu[j] > -1) ){
					smpack_spattern_add( &p, mesh->elem[e].iLCu[i], mesh->elem[e].iLCu[j] );
					smpack_spattern_add( &p, mesh->elem[e].iLCu[j], mesh->elem[e].iLCu[i] );
				};
				if ( (mesh->elem[e].iLCv[i] > -1) && (mesh->elem[e].iLCv[j] > -1) ){
					smpack_spattern_add( &p, mesh -> num_u+mesh->elem[e].iLCv[i], mesh -> num_u+mesh->elem[e].iLCv[j] );
					smpack_spattern_add( &p, mesh -> num_u+mesh->elem[e].iLCv[j], mesh -> num_u+mesh->elem[e].iLCv[i] );
				};
			};
		};
	};
        
        smpack_pmat_create( M, &p );
        
        smpack_spattern_del( &p );
        
        // assemble the matrix values
        for( e=0; e<mesh->num_elem; e++ ){
		for( i=0; i<3; i++ ){
			for( j=0; j<3; j++ ){
				if ( (mesh->elem[e].iLCu[i] > -1) && (mesh->elem[e].iLCu[j] > -1) ){
					smpack_pmat_addval( M, mesh->elem[e].iLCu[i], mesh->elem[e].iLCu[j], mesh->elem[e].T.det * D[i][j] );
				};
				if ( (mesh->elem[e].iLCv[i] > -1) && (mesh->elem[e].iLCv[j] > -1) ){
					smpack_pmat_addval( M, mesh -> num_u+mesh->elem[e].iLCv[i], mesh -> num_u+mesh->elem[e].iLCv[j], mesh->elem[e].T.det * D[i][j] );
				};
			};
		};
	};
};

int PDMeshMarkForRefinement( struct PDMesh *mesh, int *to_refine, double tol ){
        // NOTE: if you plan on using iterative refinement, you should write a better test here
        //       check PDProblemSolveSteadyStateRefined in PD_SIMULATOR for what this function should return
	int e, i, j, bChanged = 0;
	double changeu, changev;
	double total_change;
	double nrm;
        double du, dv, dx, dy, ndu, ndx;

	for( e=0; e<mesh->num_elem; e++ ){
		to_refine[e] = 0;
	};

	for( e=0; e<mesh->num_elem; e++ ){
		changeu = 0.0;
		changev = 0.0;
		/* // this is L-2 Euclidian norm of the difference (at points)
                for( i=0; i<3; i++ ){
			changeu += (mesh->elem[e].u[i] - mesh->elem[e].u[(i+1)%3])*(mesh->elem[e].u[i] - mesh->elem[e].u[(i+1)%3]);
			changev += (mesh->elem[e].v[i] - mesh->elem[e].v[(i+1)%3])*(mesh->elem[e].v[i] - mesh->elem[e].v[(i+1)%3]);
		};
		changeu = sqrt( changeu );
		changev = sqrt( changev );
                if ( (changeu > tol) || (changev > tol) ){
			to_refine[e] = 1;
                        bChanged = 1;
		};
                */
                /*// use abs value of the max difference
                changeu = 0.0;
                changev = 0.0;
                for( i=0; i<3; i++ ){
                        if ( (fabs(mesh->elem[e].u[i] - mesh->elem[e].u[(i+1)%3])>tol)||(fabs(mesh->elem[e].v[i] - mesh->elem[e].v[(i+1)%3])) ){
                                to_refine[e] = 1;
                                bChanged = 1;
                        };
                };*/
                // difference betweent the values at the different points
                for( i=0; i<3; i++ ){
                        changeu = (mesh->elem[e].u[i] - mesh->elem[e].u[(i+1)%3]);
                        changev = (mesh->elem[e].v[i] - mesh->elem[e].v[(i+1)%3]);
                        total_change = sqrt( changeu*changeu + changev*changev );
                        nrm = sqrt( mesh->elem[e].u[i]*mesh->elem[e].u[i] + mesh->elem[e].v[i]*mesh->elem[e].v[i] ) + sqrt( mesh->elem[e].u[(i+1)%3]*mesh->elem[e].u[(i+1)%3] + mesh->elem[e].v[(i+1)%3]*mesh->elem[e].v[(i+1)%3] );
                        total_change = sqrt( changeu*changeu + changev*changev );
                        if ( total_change > tol ){
                                to_refine[e] = 1;
                                bChanged = 1;
                                for( j=0; j<3; j++ ){
                                        if ( mesh->elem[e].nbrs[j] > -1 ){
                                                to_refine[mesh->elem[e].nbrs[j]] = 1;
                                        };
                                };
                        };
                };
                /*// criteria for breaking the bonds
                for( i=0; i<3; i++ ){
                        du = (mesh->elem[e].u[i] - mesh->elem[e].u[(i+1)%3]);
                        dv = (mesh->elem[e].v[i] - mesh->elem[e].v[(i+1)%3]);
                        dx = (mesh->elem[e].T.x[i] - mesh->elem[e].T.x[(i+1)%3]);
                        dy = (mesh->elem[e].T.y[i] - mesh->elem[e].T.y[(i+1)%3]);
                        ndu = sqrt( (du+dx)*(du+dx) + (dv+dy)*(dv+dy) );
                        ndx = sqrt( dx*dx + dy*dy );
                        total_change = (ndu - ndx)/ndx;
                        if ( total_change > tol/6.0 ){
                                to_refine[e] = 1;
                                bChanged = 1;
                        };
                };*/
                // gradient of the solution
                /*for( i=0; i<3; i++ ){
			du = (mesh->elem[e].u[i] - mesh->elem[e].u[(i+1)%3]);
                        dv = (mesh->elem[e].v[i] - mesh->elem[e].v[(i+1)%3]);
                        dx = (mesh->elem[e].T.x[i] - mesh->elem[e].T.x[(i+1)%3]);
                        dy = (mesh->elem[e].T.y[i] - mesh->elem[e].T.y[(i+1)%3]);
                        total_change = sqrt( (du*du+dv*dv) / (dx*dx+dy*dy) );
                        if ( total_change > tol ){
                                to_refine[e] = 1;
                                bChanged = 1;
                        };
		};*/
	};
	/*for( e=0; e<mesh->num_elem; e++ ){
		if ( to_refine[e] == 1 ){
			return 1;
		};
	};
	return 0;*/
        return bChanged;
};

void PDMeshComputeError( struct PDMesh *mesh, double *err ){
	int e, i, j, bChanged = 0;
	double changeu, changev;
	double total_change;
	double nrm;
        double du, dv, dx, dy, ndu, ndx;
        for( e=0; e<mesh->num_elem; e++ ){
		err[e] = 0.0;
		for( i=0; i<3; i++ ){
			du = (mesh->elem[e].u[i] - mesh->elem[e].u[(i+1)%3]);
                        dv = (mesh->elem[e].v[i] - mesh->elem[e].v[(i+1)%3]);
                        dx = (mesh->elem[e].T.x[i] - mesh->elem[e].T.x[(i+1)%3]);
                        dy = (mesh->elem[e].T.y[i] - mesh->elem[e].T.y[(i+1)%3]);
                        total_change = sqrt( (du*du+dv*dv) / (dx*dx+dy*dy) );
                        if ( total_change > err[e] ){
				err[e] = total_change;
			};
		};
	};
};

int PDMeshMarkForRefinementErr( struct PDMesh *mesh, int *to_refine, double *olderr, double *newerr, double tol ){
	int e;
        double err = 0.0;
        int err_e = -1;
	for( e=0; e<mesh->num_elem; e++ ){
		to_refine[e] = ( fabs( olderr[e] - newerr[e] ) > tol ) ? 1 : 0;
                if ( fabs( olderr[e] - newerr[e] ) > err ){ err = fabs( olderr[e] - newerr[e] ); err_e = e; };
	};
	for( e=0; e<mesh->num_elem; e++ ){
		if ( to_refine[e] == 1 ){ return 1; };
	};
	return 0;
};

void PDMeshInvertMass( struct SMPACKFactorizedCHOLMOD *M, double *b, double *x ){
	smpack_pmat_CHOLMOD_solve( M, b, x );
};

void PDMeshWriteSolution( struct PDMesh *mesh, const char * filename ){
	int e, i;
	double *x = (double*) malloc( mesh->num_total * sizeof( double ) );
	double *y = (double*) malloc( mesh->num_total * sizeof( double ) );
	double *u = (double*) malloc( mesh->num_total * sizeof( double ) );
	double *v = (double*) malloc( mesh->num_total * sizeof( double ) );
	
	for( e=0; e<mesh->num_elem; e++ ){
		for( i=0; i<3; i++ ){
			x[ mesh->elem[e].iLCglobalu[i] ] = mesh->elem[e].T.x[i];
			y[ mesh->elem[e].iLCglobalu[i] ] = mesh->elem[e].T.y[i];
			u[ mesh->elem[e].iLCglobalu[i] ] = mesh->elem[e].u[i];
			v[ mesh->elem[e].iLCglobalu[i] ] = mesh->elem[e].v[i];
		};
	};
	
	FILE * fout = fopen( filename, "w");
	fprintf(fout,"%d \n",mesh->num_total);
	
	for( i=0; i<mesh->num_total; i++ ){
		fprintf(fout,"%f %f %f %f\n",x[i],y[i],u[i],v[i]);
	};
	
	fclose( fout );
	
	free( x );
	free( y );
	free( u );
	free( v );
};

#endif
