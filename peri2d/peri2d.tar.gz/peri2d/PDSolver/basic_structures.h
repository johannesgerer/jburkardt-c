/*
* This code isdistrubuted under GPLv3
* 
* Code Author: Miroslav Stoyanov, Nov 2011
* 
* Copyright (C) 2011  Miroslav Stoyanov
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* Since the GNU General Public License is longer than this entire code, 
* a copy of it can be obtained separately at <http://www.gnu.org/licenses/>
*/

#ifndef __BASIC_STRUCTURES_H_
#define __BASIC_STRUCTURES_H_

#define DEBUG
#ifdef DEBUG
#include <stdio.h>
#endif

#include <stdlib.h>
#include <math.h>

// ---------------------------------------------------------------------- //
// ------ GEOMETRY TRIANGLE
// ---------------------------------------------------------------------- //
struct GeometryTriangle {
        double x[3], y[3];
        double xi2x, xi2y, et2x, et2y, det;
};

struct GeometryDisk{
	double x, y, r; // center is at x, y and radius is r
};

struct GeometryIntersectDiskSegment{
	int num_points;
	double x[2], y[2];
};	

// ---------------------------------------------------------------------- //
// ------ GEOMETRY QUADRATURE
// ---------------------------------------------------------------------- //
struct GeometryQuadrature{
        int num_points;
        double *w, *x, *y, *xi, *et;
};

struct GeometryDynamicQuadrature{
	double x, y, w;
	struct GeometryDynamicQuadrature *next;
};


void GeometryTriangleSet( double x0, double y0, double x1, double y1, double x2, double y2, struct GeometryTriangle *T );
// sets x[3] and y[3] and then xi2x, xi2y, et2x, et2y and det 

void GeometryTriangleSetSafe( double x0, double y0, double x1, double y1, double x2, double y2, struct GeometryTriangle *T );
// sets x[3] and y[3] and then xi2x, xi2y, et2x, et2y and det 
// SetSafe checks for the ordering of the point to make sure that det is positive

void GeometryTriangleSetXiEt( struct GeometryTriangle T, struct GeometryQuadrature *Q );
// given a triangle (already set) and quadrature with num_points and x/y arrays set, then get xi, et

void GeometryTriangleSplit( struct GeometryTriangle T, struct GeometryTriangle *T1, struct GeometryTriangle *T2, struct GeometryTriangle *T3, struct GeometryTriangle *T4 );
// splits a triangle T into four smaller trianles T1, T2, T3, T4 (also calls GeometryTriangleSet on all the sub-triangles)

void GeometryTriangleBisect( struct GeometryTriangle T, struct GeometryTriangle *T1, struct GeometryTriangle *T2, int vertex );
// splits the triangle into two triangles using the vertex 0 - 2

void GeometryTriangleCopy( struct GeometryTriangle T, struct GeometryTriangle *T1 );
// just copy one triangle over the other, resets the det and other values

void GeometryFormIntersectDiskSegment( struct GeometryDisk *C, double x0, double y0, double x1, double y1, struct GeometryIntersectDiskSegment *I );
// finds the points of intersection between a circle C and a segment (x0,y0) - (x1,y1)

void GeometryDynamicQuadratureAddPoint( double x, double y, double w, struct GeometryDynamicQuadrature **Q );
// adds a new node to the quadrature stack

void GeometryDynamicQuadratureFree( struct GeometryDynamicQuadrature **Q );
// releases all memory used by the GeometryDynamicQuadrature stack (Q is returned as NULL)

void GeometryQuadratureFree( struct GeometryQuadrature *Q );
// release all memory used by the GeometryQuadrature

void GeometryDynamicQuadrature2GeometryQuadrature( struct GeometryDynamicQuadrature *DQ, struct GeometryQuadrature *SQ );
// convert the dynamic memory from DQ to contunious arrays from SQ

double GeometryTriangleIntersectDiskAreaBrute( struct GeometryTriangle T, struct GeometryDisk *C, double tolerance );
// returns the area of the intersection of a disk with the triangle T to within specific toletance

double GeometryTriangleIntersectDiskAreaExact( struct GeometryTriangle T, struct GeometryDisk *C );
// returns the exact area of the intersection between a triangle and disk

double GeometryTriangleSliceExact( double x0, double y0, double x1, double y1, struct GeometryDisk *C );
// returns the exact area of the slice

int GeometryTrianglePointInside( struct GeometryTriangle T, double x, double y );
// return 1 if the point x,y is inside T and 0 otherwise


// --------- QUADRATURES --------------- //
void GeometryDynamicQuadratureAdd3PointsTriangle( struct GeometryTriangle T, struct GeometryDynamicQuadrature **Q );
void GeometryQuadratureAdd3PointsTriangle( struct GeometryTriangle T, struct GeometryQuadrature *Q );
void GeometryDynamicQuadratureAdd6PointsTriangle( struct GeometryTriangle T, struct GeometryDynamicQuadrature **Q );
void GeometryQuadratureAdd6PointsTriangle( struct GeometryTriangle T, struct GeometryQuadrature *Q );
void GeometryDynamicQuadratureAdd7PointsTriangle( struct GeometryTriangle T, struct GeometryDynamicQuadrature **Q );
void GeometryQuadratureAdd7PointsTriangle( struct GeometryTriangle T, struct GeometryQuadrature *Q );
// adds quadrature points to the GeometryDynamicQuadrature stack, 6 points or 7 points
void GeometryDynamicQuadratureAdd12PointsDisk( double x, double y, double delta, struct GeometryDynamicQuadrature **Q );
void GeometryDynamicQuadratureAdd12PointsDiskSideSynced( struct GeometryTriangle T, double x, double y, double delta, struct GeometryDynamicQuadrature **Q );
void GeometryDynamicQuadratureAdd36PointsDisk( struct GeometryDisk *C, struct GeometryDynamicQuadrature **Q );
// add 16 point quadrature over slice of disk and a line
void GeometryDynamicQuadratureAddSlice( double x0, double y0, double x1, double y1, struct GeometryDisk *C, struct GeometryDynamicQuadrature **Q );
// bSmall indicates whether to take the small or big slice of the 1 means to take the small slice, 0 (or otherwise) gives the large slice
// (x0,y0) and (x1,y1) are assumed to tbe on the circle centered at (rx,ry) and with radius delta (i.e. || (xi,yi) - (rx,ry) || == delta)

void GeometryDynamicQuadratureTriangleDiskIntersection( struct GeometryTriangle T, struct GeometryDisk *C, struct GeometryDynamicQuadrature **Q );

#endif
