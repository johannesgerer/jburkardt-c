/*
* This code isdistrubuted under GPLv3
* 
* Code Author: Miroslav Stoyanov, Nov 2011
* 
* Copyright (C) 2011  Miroslav Stoyanov
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* Since the GNU General Public License is longer than this entire code, 
* a copy of it can be obtained separately at <http://www.gnu.org/licenses/>
*/

#ifndef __PD_SIMULATOR_C
#define __PD_SIMULATOR_C

#include "pd_simulator.h"

void PDProblemSetType( struct PDProblem *P, int Type ){
        if ( (Type == PD_PROBLEM_TIMEINTERATE) || (Type == PD_PROBLEM_STEADYSTATE) ){
                P ->ProblemType = Type;
        }else{
                printf(" ERROR: WRONG PROBLEM TYPE!!! \n");
        };
};

void PDProblemSetKernel( struct PDProblem *P, double (*kernel_u)(double,double,double,double,double,double,double,double), double (*kernel_v)(double,double,double,double,double,double,double,double), double delta ){
        P -> delta = delta;
        P -> kernel_u = kernel_u;
        P -> kernel_v = kernel_v;
};

void PDProblemSetExternal( struct PDProblem *P, double (*force_u)(double,double,double), double (*force_v)(double,double,double) ){
        P -> b_external_x = force_u;
        P -> b_external_y = force_v;
};

void PDProblemSetBoundary( struct PDProblem *P, double (*boundary_u)(double,double,double), double (*boundary_v)(double,double,double) ){
        P -> ux_bnd = boundary_u;
        P -> uy_bnd = boundary_v;
};

void PDProbleSetIntegrationParameters( struct PDProblem *P, double T0, double Tfinal, double dt ){
        P -> t = T0;
        P -> T_0 = T0;
        P -> T_final = Tfinal;
        P -> dt = dt;
};

void PDProblemSetDomainDiscretizationParameters( struct PDProblem *P, int Nx, int Ny, int boundary_conditions ){
        P -> Nx = Nx;
        P -> Ny = Ny;
        P -> boundary_conditions = boundary_conditions;
};

void PDProblemSetMeshInputFile( struct PDProblem *P, const char *meshfilename ){
        P -> ifmeshname = meshfilename;
};

void PDProblemSetQuadratureTolerance( double tolerance ){
	PD_QUADRATURE_TOLERANCE = tolerance;
};

void PDProblemSetRefinement( struct PDProblem *P, int bUse, double tol, int max_iterations ){
	P->bUseRefinement = bUse;
	if ( bUse == 1 ){
		P->localTolerance = tol;
                P->max_iterations = max_iterations;
	};
};

void PDProblemInitialize( struct PDProblem *P, int linear ){
        if ( P -> ProblemType == PD_PROBLEM_TIMEINTERATE ){
		if ( linear != 1 ){
                        printf(" WARNING: This version works only with Linear problems ... Assuming linear = 1 ");
                        linear = 1;
                };
                P ->linear = linear;
                // form the mesh
                P -> mesh = (struct PDMesh*) malloc( sizeof( struct PDMesh ) );
                if ( P -> ifmeshname == NULL ){
                        MeshFormUnit( P ->delta, 1.0/( (double) P->Nx), 1.0/( (double) P->Ny), P -> boundary_conditions, P->mesh );
                }else{
                        MeshRead( P -> mesh, P -> ifmeshname );
                };
                // form the quadrature
                if ( linear == 1 ){
			P -> A = (struct SMPACKPmat*) malloc( sizeof(struct SMPACKPmat) );
                        PDMeshFormOperator( P->mesh, P->kernel_u, P->kernel_v, P->delta, P->A );
                }else{
                        printf(" ERROR: THIS VERSION WORKS WITH LINEAR ONLY!!!\n");
                        return;
                };
                // form the mass matrix
                P -> M = (struct SMPACKPmat*) malloc( sizeof(struct SMPACKPmat) );
                PDMeshFormMass( P->mesh, P->M );
                // factorize the mass matrix
                P -> M_factor = (struct SMPACKFactorizedCHOLMOD*) malloc( sizeof(struct SMPACKFactorizedCHOLMOD) );
                smpack_pmat_CHOLMOD_factorize( *(P->M), P->M_factor );
                // set the initial conditions and the solution vector
                P ->solution_uv = (double*) malloc( (P->mesh->num_u+P->mesh->num_v) * sizeof(double) );
                P ->last_uv = (double*) malloc( (P->mesh->num_u+P->mesh->num_v) * sizeof(double) );
                int i;
                for( i=0; i < P->mesh->num_u+P->mesh->num_v; i++ ){
                        P ->solution_uv[i] = 0.0;
                        P ->last_uv[i] = 0.0;
                };
        }else if ( P -> ProblemType == PD_PROBLEM_STEADYSTATE ){
                if ( linear != 1 ){
                        printf(" WARNING: Steady State Works Only with Linear Problems ... Assuming linear = 1 ");
                        linear = 1;
                };
                // form the mesh
                P -> mesh = (struct PDMesh*) malloc( sizeof( struct PDMesh ) );
                if ( P -> ifmeshname == NULL ){
                        MeshFormUnit( P ->delta, 1.0/( (double) P->Nx), 1.0/( (double) P->Ny), P -> boundary_conditions, P->mesh );
                }else{
                        MeshRead( P -> mesh, P -> ifmeshname );
                };
                // form the operator matrix
                P -> A = (struct SMPACKPmat*) malloc( sizeof(struct SMPACKPmat) );
                
                PDMeshFormOperator( P->mesh, P->kernel_u, P->kernel_v, P->delta, P->A );
                
                // set the mass matrix to uninitialized
                P -> M = NULL;
                P -> M_factor = NULL;
                // reserve memory for the solution
                P ->solution_uv = (double*) malloc( (P->mesh->num_u+P->mesh->num_v) * sizeof(double) );
                int i;
                for( i=0; i < P->mesh->num_u+P->mesh->num_v; i++ ){
                        P ->solution_uv[i] = 0.0;
                };
        };
};

void PDProblemSolve( struct PDProblem *P ){
	if ( P -> ProblemType == PD_PROBLEM_TIMEINTERATE ){
		PDProblemIntegrate( P );
	}else if ( P -> ProblemType == PD_PROBLEM_STEADYSTATE ){
		PDProblemSolveSteadyState( P );
	}else{
		printf(" ERROR: Invalind Problem Type!!!\n");
	};
};

double PDProblemMax( int n, double *x ){
	// return the largest vaues of x in absolute value
	int i;
	double max = fabs( x[0] );
	for( i=1; i<n; i++ ){
		max = ( fabs(x[i]) > max ) ? fabs(x[i]) : max;
	};
	return max;
};

void PDProblemIntegrate( struct PDProblem *P ){
        printf(" Note from Miro: I haven't tested the time Integration since I made some other changes, it is possible that it doesn't work properly\n");
        printf("     this message is in pd_simulator PDProblemIntegrate\n");
        // this should solve the time dependent problem starting with initial condition and tracking B at each time step
        // few months ago I moved my focus from the potential of cracks (when you need time dependence) to the basic convergence
        // since then I have not tested this code. Given the operator A and M, the code should be simple enough, 
        // but you should be sceptical of the results that you are getting
	double *F = (double*) malloc( (P->mesh->num_u+P->mesh->num_v) * sizeof(double) );
	double *B = (double*) malloc( (P->mesh->num_u+P->mesh->num_v) * sizeof(double) );
	double *tmp = (double*) malloc( (P->mesh->num_u+P->mesh->num_v) * sizeof(double) );
	
	int nuv = P ->mesh->num_u + P ->mesh->num_v;
	double curr, max = 0.0;
	
	double Tout = P -> t + 1.0;
	
	while ( P -> t < P -> T_final ){
		
		// load the solution in the mesh structure
		PDMeshLoadUVfromLCdf( P->mesh, P -> t, P -> solution_uv, P->ux_bnd, P->uy_bnd ); 
		// compute the internal force
		if ( P ->linear == 1 ){
			smpack_pmat_act( *(P->A), P -> solution_uv, F, 1.0 );
		}else{
			printf(" ERROR: this version works only with Linear\n");
		};
		// compute the external force
		PDMesIntegrateCLexternal( P->mesh, P->t, P->b_external_x, P->b_external_y, B );
		// x^{n+1} = 2*x^n - x^{n-1} + inv(M) * dt^2 * ( Ax^n + B )
		daxpy( nuv, 1.0, B, 1, F, 1 );
		// invert the mass matrix
		PDMeshInvertMass( P->M_factor, F, tmp );
		// save the current step
		dcopy( nuv, P->solution_uv, 1, B, 1 );
		
		// scale and add other values
		dscal( nuv, 2.0, P->solution_uv, 1 );
		daxpy( nuv, P->dt*P->dt, tmp, 1, P->solution_uv, 1 );
		daxpy( nuv, -1.0, P->last_uv, 1, P->solution_uv, 1 );
		
		// restore the old solution
		dcopy( nuv, B, 1, P->last_uv, 1 );
		
		// compute the max 1D deviation
		curr = PDProblemMax(nuv,P->solution_uv);
		if ( curr > max ){ max = curr; };
		
		P -> t += P -> dt;
		
		if ( P -> t > Tout ){
			Tout += 1.0;
			printf(" Time: %1.3f  Maximum deviation: %2.16f \n",P->t,max );
		};
		
	};
        printf(" Time: %1.3f  Maximum deviation: %2.16f \n",P->t,max );
	
	free( tmp );
	free( B );
	free( F );
};

void PDProblemSolveSteadyStateFixed( struct PDProblem *P ){
        double *B = (double*) malloc( (P->mesh->num_u+P->mesh->num_v) * sizeof(double) );
        PDMesIntegrateCLexternal( P->mesh, 0, P->b_external_x, P->b_external_y, B );
        dscal( (P->mesh->num_u+P->mesh->num_v), -1.0, B, 1 );
        
        smpack_pmat_general_solve( *(P->A), B, P->solution_uv );
        free( B );
};

void PDProblemSolveSteadyStateRefined( struct PDProblem *P ){
        printf(" Note from Miro: the refinement code needs a way to detect whether or not an element needs refinement, this is currently unimplemented feature\n");
        printf("     this message is in pd_simulator PDProblemSolveSteadyStateRefined\n");
        // the problem here is that if a portion of the mesh is refined (or even if the entire mesh is refined) and delta is kept fixed, then the solution doesn't converge
        // this has to do with the observation of the convergence in the PD notes (if I forgot to give you a copy of the notes, then John certainly has a copy)
        // until the convergence part is resolved, there is no need to refine and this is mostly obsolete
        // I have an explanation on how this is supposed to work further down
	double *B = NULL; 
        int *to_refine = NULL;
        struct PDMesh *newmesh;
        void *tmp;
        
        char fname[256];
        
        int bLoop = 1;
        int bChange;
        int iter = 0;
        
        int e;
        
        while ( (bLoop == 1) && (iter<P->max_iterations) ){
                iter++;

		B = (double*) malloc( (P->mesh->num_u+P->mesh->num_v) * sizeof(double) );
		to_refine = (int*) malloc( (P->mesh->num_elem) * sizeof( int ) );

                PDMesIntegrateCLexternal( P->mesh, 0, P->b_external_x, P->b_external_y, B );
		dscal( (P->mesh->num_u+P->mesh->num_v), -1.0, B, 1 );
		
                smpack_pmat_general_solve( *(P->A), B, P->solution_uv );

		PDMeshLoadUVfromLCdf( P->mesh, 0, P -> solution_uv, P -> ux_bnd, P -> uy_bnd );
                
                bChange = PDMeshMarkForRefinement( P->mesh, to_refine, P -> localTolerance );
                // PDMeshMarkForRefinement is supposed to go over the solution (that is loaded in the mesh structure), 
                // test the solution element by element and then returns two things
                // first is the bChange variable that will tell the code whether or not a refinement step is needed (1 needs a refinement step)
                // second is the "to_refine" array, which is an array with 1 and 0 of size "number of elements"
                //    the array will set 1 for every element that needs to be refined and 0 otherwise
                //    note that the refinement function MeshRefine may refine more elements 
                //    i.e. we cannot have triangle and refine two of its neighbors without refining the triangle itself
                //    some triangles will be split in two and some will be split in four, PDMeshMarkForRefinement sets which triangles absolutely need to be split in 4       
                // the function is implemented in PD_COMPLEX_STRUCTURES
                
                bLoop = 0;
		if ( (iter<P->max_iterations) && (bChange == 1) ){
			// Create a new Mesh refined from the old one
			newmesh = (struct PDMesh*) malloc( sizeof( struct PDMesh ) );
			
                        MeshRefine( P -> mesh, to_refine, newmesh );
			// switch the mesh pointers and release all memory from the mesh and the operator
			tmp = (void*) (P -> mesh);
			P -> mesh = newmesh;
			newmesh = (struct PDMesh*) tmp;
                        
                        MeshFree( newmesh );
                        free( newmesh );
                        newmesh = NULL;
                        
			smpack_pmat_delete( P -> A );
                        
			// create the new operator (this can be expensive)
			PDMeshFormOperator( P->mesh, P->kernel_u, P->kernel_v, P->delta, P->A );
			
			// allocate the new solution
                        free( P -> solution_uv );
			P ->solution_uv = (double*) malloc( (P->mesh->num_u + P->mesh->num_v) * sizeof( double ) );
                        bLoop = 1;
                        
                        free( to_refine );
                        free( B );
		};
	};

};

void PDProblemSolveSteadyState( struct PDProblem *P ){
	if ( P -> bUseRefinement == 1 ){
		PDProblemSolveSteadyStateRefined( P );
	}else{
		PDProblemSolveSteadyStateFixed( P );
	};
};

double PDProblemSolutionNormL2( struct PDProblem *P ){
	double *tmp = (double*) malloc( (P->mesh->num_u+P->mesh->num_v) * sizeof(double) );
	int bMready = (P -> M == NULL) ? 0 : 1;
	int bMsane = 1;
	if ( bMready == 1 ){
		bMsane = ( P->M->num_rows == (P->mesh->num_u+P->mesh->num_v) ) ? 1 : 0;
	};
	if ( bMready == 0 ){
		P -> M = (struct SMPACKPmat*) malloc( sizeof(struct SMPACKPmat) );
                PDMeshFormMass( P->mesh, P->M );
	}else if ( bMsane == 0 ){
		smpack_pmat_delete( P -> M );
		PDMeshFormMass( P->mesh, P->M );
	};
	
	smpack_pmat_act( *(P->M), P -> solution_uv, tmp, 1.0 );
        
	double result = ddot( (P->mesh->num_u+P->mesh->num_v), P->solution_uv, 1, tmp, 1 );
	
	free( tmp );
	
	return sqrt( result );
};

void PDProblemTest( struct PDProblem *P ){
	double *tmp = (double*) malloc( (P->mesh->num_u+P->mesh->num_v) * sizeof(double) );
	double *tmp2 = (double*) malloc( (P->mesh->num_u+P->mesh->num_v) * sizeof(double) );
	int i;
	int nuv = P ->mesh->num_u + P ->mesh->num_v;
	
	for( i=0; i<nuv; i++ ){ tmp[i] = 0.0; };
	
	int pnt = P->mesh->num_v;
        
        PDTestIntegration( P->mesh, P->kernel_u, P->kernel_v, P->delta, P->A );
	
	free( tmp2 );
	free( tmp );
};

void PDProblemWriteSolution( struct PDProblem *P, const char * filename ){
	PDMeshLoadUVfromLCdf( P->mesh, P->t, P->solution_uv, P->ux_bnd, P->uy_bnd );
	PDMeshWriteSolution( P->mesh, filename );
};

void PDProblemShowInfo( struct PDProblem *P ){
	printf(" Information about the Peridynamics Problem\n");
        printf(" --------------------------------------\n");
        if ( P -> ProblemType == PD_PROBLEM_TIMEINTERATE ){
                printf("    --- TIME INTEGRATION PROBLEM --- \n");
                printf(" Mesh                   Nx = %d\n",P->Nx);
                printf("                        Ny = %d\n",P->Ny);
                printf("                     delta = %f\n",P->delta);
                printf(" Integration Interval   T0 = %f\n",P->T_0);
                printf("                      Tend = %f\n",P->T_final);
                printf("                        dt = %f\n",P->dt);
                printf(" --------------------------------------\n");
        }else if ( P -> ProblemType == PD_PROBLEM_STEADYSTATE ){
                printf("    --- STEADY STATE PROBLEM --- \n");
                printf(" Mesh                   Nx = %d\n",P->Nx);
                printf("                        Ny = %d\n",P->Ny);
                printf("                     delta = %f\n",P->delta);
                printf("  Use Iterative Refinement = ");
                if ( P ->bUseRefinement == 1 ){
                        printf("True\n");
                }else{
                        printf("False\n");
                };
                printf(" --------------------------------------\n");
        };
};

#endif
