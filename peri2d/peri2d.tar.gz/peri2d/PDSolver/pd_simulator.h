/*
* This code isdistrubuted under GPLv3
* 
* Code Author: Miroslav Stoyanov, Nov 2011
* 
* Copyright (C) 2011  Miroslav Stoyanov
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* Since the GNU General Public License is longer than this entire code, 
* a copy of it can be obtained separately at <http://www.gnu.org/licenses/>
*/

#ifndef __PD_SIMULATOR_H
#define __PD_SIMULATOR_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "pd_complex_structures.h"

#include "../SMPACK/smpack.h"

#include "acml.h"


#define PD_PROBLEM_TIMEINTERATE 1
#define PD_PROBLEM_STEADYSTATE 2 // linear problems only

struct PDProblem{
        int ProblemType; // the type of problem that we will be solving
        
        // domain discretization parameters
        int Nx; // number of elements in x direction
        int Ny; // number of elements in y direction
        int boundary_conditions; // describes the type of boundary that we use
        
        // input mesh filename
        const char * ifmeshname;
        
        // integration parameters
        double t;
        double T_0;
        double T_final;
        double dt;
        
        // problem parameters
        double delta;
        
        // function pointers for the kernel, forcing function and boundary conditions
	double (*kernel_u)(double,double,double,double,double,double,double,double); // PD kernel
	// up, vp, u, v, xp, yp, x, y
	double (*kernel_v)(double,double,double,double,double,double,double,double);
	double (*b_external_x)(double,double,double); // external force
	// t, x, y
	double (*b_external_y)(double,double,double);
	double (*ux_bnd)(double,double,double); // boundary conditions for the Dirichlet boundary
	// t, x, y
	double (*uy_bnd)(double,double,double);
	
	// type of problem (if llinear is 1, then use a linear problem, otherwise do non-linear)
	int linear; 
	
	// refinement specifications
	int bUseRefinement; // 1 to use 0 to not use
	double localTolerance; // maximum acceptable difference between local u values
        int max_iterations; // the maximum number of iterations for the refinement process
        
        // work variables - Time Integration
        struct PDMesh *mesh;
        struct SMPACKPmat *M; // mass matrix
        struct SMPACKPmat *A; // for linear problems
        struct SMPACKFactorizedCHOLMOD *M_factor;
        double *solution_uv;
        double *last_uv;
};

void PDProblemSetType( struct PDProblem *P, int Type );
// sets the type of PD problem (time integration or steady state)

void PDProblemSetKernel( struct PDProblem *P, double (*kernel_u)(double,double,double,double,double,double,double,double), double (*kernel_v)(double,double,double,double,double,double,double,double), double delta );
// set the internal parameters for the material

void PDProblemSetExternal( struct PDProblem *P, double (*force_u)(double,double,double), double (*force_v)(double,double,double) );
// set the external forces for the problem

void PDProblemSetBoundaryFunctions( struct PDProblem *P, double (*boundary_u)(double,double,double), double (*boundary_v)(double,double,double) );
// set the boundary forces for the problem

void PDProbleSetIntegrationParameters( struct PDProblem *P, double T0, double Tfinal, double dt );
// set the integration parameters and sets the curent time to T0

void PDProblemSetDomainDiscretizationParameters( struct PDProblem *P, int Nx, int Ny, int boundary_conditions );
// set the parameters for the mesh discretization

void PDProblemSetMeshInputFile( struct PDProblem *P, const char *meshfilename );
// set the filename to read the input mesh

void PDProblemSetQuadratureTolerance( double tolerance );
// set PD_QUADRATURE_TOLERANCE for how fine the discretization of the disk/triangle intersection should be

void PDProblemSetRefinement( struct PDProblem *P, int bUse, double tol, int max_iterations );
// set bUse = 1 to use refinement or 0 to turn it off (if bUse is 0, tol is irrelevant)
// only works with Steady State Problems (for now)

void PDProblemInitialize( struct PDProblem *P, int linear );
// AFTER all the parameters have been set, we can initialize the mesh and mass matrix

void PDProblemSolve( struct PDProblem *P );
// solve the problem, calls PDProblemIntegrate(...) or PDProblemSolveSteadyState(...) depending on the problem type

void PDProblemIntegrate( struct PDProblem *P );
// integrate until Tend

void PDProblemSolveSteadyState( struct PDProblem *P );
// solve the steady state problem (using adaptive mesh)

double PDProblemSolutionNormL2( struct PDProblem *P );
// returns the L2 norm of the solution

void PDProblemTest( struct PDProblem *P );
// does a test on the code

void PDProblemShowInfo( struct PDProblem *P );
// show information abou the problem

void PDProblemWriteSolution( struct PDProblem *P, const char * filename );
// write the solution into the file

#endif
