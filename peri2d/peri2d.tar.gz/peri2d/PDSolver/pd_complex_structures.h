/*
* This code isdistrubuted under GPLv3
* 
* Code Author: Miroslav Stoyanov, Nov 2011
* 
* Copyright (C) 2011  Miroslav Stoyanov
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* Since the GNU General Public License is longer than this entire code, 
* a copy of it can be obtained separately at <http://www.gnu.org/licenses/>
*/

#ifndef __PD_COMPLEX_STRUCTURES_H
#define __PD_COMPLEX_STRUCTURES_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "../SMPACK/smpack.h"
#include "mesh.h"

// specify the quadrature tolerance
extern double PD_QUADRATURE_TOLERANCE;

// specify whether to use OpenMP or not
#define PD_USE_OPEN_MP
#define _PD_OMP_MAX_NUM_THREADS (8) // the max number of threads for the connectivity in constructing the operator
#define _PD_OMP_READ_SPLIT( me, nthreads, N, start, end, length ) \
	(me) = omp_get_thread_num(); \
	(nthreads) = omp_get_num_threads(); \
	(start) = (me) * (N) / (nthreads); \
	(end) = (me+1) * (N) / (nthreads) - 1; \
	(length) = (end) - (start) + 1;
#define _PD_OMP_JUST_SPLIT( me, nthreads, N, start, end, length ) \
	(start) = (me) * (N) / (nthreads); \
	(end) = (me+1) * (N) / (nthreads) - 1; \
	(length) = (end) - (start) + 1;


void PDMeshFromQuadratureOverTriangle( double x, double y, double delta, struct GeometryTriangle T, double tolerance, struct GeometryDynamicQuadrature **Q );
// forms a quadrature over the triangle T that captures the area of the intersection with the disk to within "toletance"

void PDMeshFormConnectivity( struct PDMesh *mesh, int current, struct GeometryDisk *C, double tolerance, int *conn );
// recursively map the elements connected to x and y to *conn

void PDMeshFormQuadrature( struct PDMesh *mesh );
// builds the quadrature for the problem

void PDMeshLoadUVfromLCdf( struct PDMesh *mesh, double t, double *uv, double (*ux_bnd)(double,double,double), double (*uy_bnd)(double,double,double) );
// load the values from u/v vector of CL degrees of freedom into the individual mesh elements

void PDMesIntegrateCLexternal( struct PDMesh *mesh, double t, double (*b_external_x)(double,double,double), double (*b_external_y)(double,double,double), double *B );
// computes the external force B

void PDMeshProjectFunctionOnMesh( struct PDMesh *mesh, double t, double (*fu)(double,double,double), double (*fv)(double,double,double), double *F );
// projects (fu,fv) onto the vector F

void PDMeshFormOperator( struct PDMesh *mesh, double (*kernel_x)(double,double,double,double,double,double,double,double), double (*kernel_y)(double,double,double,double,double,double,double,double), double delta, struct SMPACKPmat *A );
// forms a matrix describing the internal forces (linear kernels only)
// quadratures are not references

void PDMeshFormMass( struct PDMesh *mesh, struct SMPACKPmat *M );
// forms the mass matrix for the mess

void PDMeshInvertMass( struct SMPACKFactorizedCHOLMOD *M, double *b, double *x );
// computes x = inv(M) * b

int PDMeshMarkForRefinement( struct PDMesh *mesh, int *to_refine, double tol );
// returns an array with 0 or 1 depending on whether the element e needs to be refined (to_refine needs to be allocated, but not initialized)
// checks the change in solution within the element
// returns 1 if there are any elements to be refined, 0 otherwise

void PDMeshComputeError( struct PDMesh *mesh, double *err );
// computes an error vector for each element (not really an error, it could be a gradient or something

int PDMeshMarkForRefinementErr( struct PDMesh *mesh, int *to_refine, double *olderr, double *newerr, double tol );
// mark for refinement using olderr and newerr values computer by PDMeshComputeError

void PDMeshWriteSolution( struct PDMesh *mesh, const char * filename );
// write the mesh into the filename (call PDMeshLoadUVfromLCdf beforeyou call this one)
// file format is:
// line 1: 1 int for num of arrows
// line 2 and on: for each arrow x, y, u, v

#endif
