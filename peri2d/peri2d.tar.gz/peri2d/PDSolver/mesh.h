/*
* This code isdistrubuted under GPLv3
* 
* Code Author: Miroslav Stoyanov, Nov 2011
* 
* Copyright (C) 2011  Miroslav Stoyanov
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* Since the GNU General Public License is longer than this entire code, 
* a copy of it can be obtained separately at <http://www.gnu.org/licenses/>
*/

#ifndef __MESH_H_
#define __MESH_H_

//#define MP_DEBUG
// safemode adda a bunch of error chacking that shouldn't be needed in normal circumstances
#define MP_SAFEMODE
//#ifdef DEBUG
// needed for the write-out funciton
#include <stdio.h>
//#endif

#include <stdlib.h>
#include <math.h>

#include "basic_structures.h"

// specify the dirichlet boundary
// None means all boundary is Neumann
#define MESH_BOUNDARY_NONE 	 (0)
#define MESH_BOUNDARY_LEFT 	 (1)
#define MESH_BOUNDARY_RIGHT	 (2)
#define MESH_BOUNDARY_TOP	 (4)
#define MESH_BOUNDARY_BOTTOM (8)

struct MeshElement{
	struct GeometryTriangle T;
	// indexes
	int iLCu[3], iLCv[3]; // Linear Contiuous u and v degrees of freedom
	int iLCglobalu[3]; // Linear Contiuous u and v global indexes
        // boundary
        int bBoundary; // holds whether or not the element this a boundary element
	// neighbouring elements
	int nbrs[3];
	// Quadratures
	struct GeometryQuadrature OuterQuad;
	// store the u/v values loaded at each step
	double u[3], v[3];
	// if this mesh comes from a refined mesh, this will keep the original index
	int mother_element;
};

struct PDMesh{
	int num_elem; // number of elements
	int num_u; // number of unknowns in u (x direction)
	int num_v; // number of unknowns in v (y direction)
	int num_total; // number of total funcitons (including the knows boundary conditions)
	struct MeshElement *elem; // the elements
};

void MeshFormUnit( double delta, double dx, double dy, int boundary_cond, struct PDMesh *mesh );
// form a 2d mesh over a unit square with dx and dy
// boundary_cond is the bitwise sum of PD_BOUNDARY_LEFT, PD_BOUNDARY_RIGHT ....

void MeshRefine( struct PDMesh *oldmesh, int *to_refine, struct PDMesh *newmesh );
// refines the mesh oldmesh into the new empty mesh newmesh
// to_refine marks with 1 the elements to tbe refined and 0 elements to not be refined
// to_refine returns an array with 1s for all the elements that were refines (full refinement)

void MeshWriteMesh( struct PDMesh *mesh, const char * filename );
// writes out the mesh for the current problem
// format isas follows
//	 line 1: one integer containing the number of elements
//       line 2-N+1: doubles(6) x0 y0 x1 y1 x2 y2 integers(13) bBoundary, global0, global1, global2, unknowns u0, u1, u2, v0, v1, v2, neighbours nbrs0, nbrs1, nbrs2

void MeshRead( struct PDMesh *mesh, const char *filename );
// reads a mesh written with MeshWeiteMesh

void MeshFree( struct PDMesh *mesh );
// free the memory associated with the mesh



#endif
