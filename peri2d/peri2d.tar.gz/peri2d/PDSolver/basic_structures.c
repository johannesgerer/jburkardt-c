/*
* This code isdistrubuted under GPLv3
* 
* Code Author: Miroslav Stoyanov, Nov 2011
* 
* Copyright (C) 2011  Miroslav Stoyanov
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* Since the GNU General Public License is longer than this entire code, 
* a copy of it can be obtained separately at <http://www.gnu.org/licenses/>
*/

#ifndef __BASIC_STRUCTURES_C_
#define __BASIC_STRUCTURES_C_

#include "basic_structures.h"

double _mp_gauss_1d4_w[4] = { 0.347854845137454, 0.652145154862546, 0.652145154862546, 0.347854845137454 };
double _mp_gauss_1d4_x[4] = { 0.861136311594053,-0.339981043584856, 0.339981043584856, 0.861136311594053 };
double _mp_cheby_1d4_w[4] = { 0.217078713422706, 0.568319449974742, 0.568319449974742, 0.217078713422706 };
double _mp_cheby_1d4_x[4] = {-0.809016994374947,-0.309016994374947, 0.309016994374947, 0.809016994374947 };

// ---------------------------------------------------------------------- //
// ------ EUCLIDEAN DISTANCE
// ---------------------------------------------------------------------- //
double edist( double x0, double y0, double x1, double y1 ){
	return sqrt( (x0-x1)*(x0-x1) + (y0-y1)*(y0-y1) );
};

// ---------------------------------------------------------------------- //
// ------ GEOMETRY TRIANGLE
// ---------------------------------------------------------------------- //
void GeometryTriangleSet( double x0, double y0, double x1, double y1, double x2, double y2, struct GeometryTriangle *T ){
        T->x[0] = x0; T->y[0] = y0;
	T->x[1] = x1; T->y[1] = y1;
	T->x[2] = x2; T->y[2] = y2;
        T->xi2x = T->x[1] - T->x[0]; T->et2x = T->x[2] - T->x[0];
        T->xi2y = T->y[1] - T->y[0]; T->et2y = T->y[2] - T->y[0];
        T->det = T->xi2x * T->et2y - T->xi2y * T->et2x;
};

void GeometryTriangleSetSafe( double x0, double y0, double x1, double y1, double x2, double y2, struct GeometryTriangle *T ){
        T->x[0] = x0; T->y[0] = y0;
	T->x[1] = x1; T->y[1] = y1;
	T->x[2] = x2; T->y[2] = y2;
        T->xi2x = T->x[1] - T->x[0]; T->et2x = T->x[2] - T->x[0];
        T->xi2y = T->y[1] - T->y[0]; T->et2y = T->y[2] - T->y[0];
        T->det = T->xi2x * T->et2y - T->xi2y * T->et2x;
        if ( T -> det < 0.0 ){
                GeometryTriangleSet( x0, y0, x2, y2, x1, y1, T );
        };
};

void GeometryTriangleSetXiEt( struct GeometryTriangle T, struct GeometryQuadrature *Q ){
        int i;
        double dx, dy;
        for( i=0; i<Q->num_points; i++ ){
                dx = Q->x[i] - T.x[0];
                dy = Q->y[i] - T.y[0];
                Q->xi[i] = ( T.et2y * dx - T.et2x * dy ) / T.det;
                Q->et[i] = (-T.xi2y * dx + T.xi2x * dy ) / T.det;
        };
};

void GeometryTriangleSplit( struct GeometryTriangle T, struct GeometryTriangle *T1, struct GeometryTriangle *T2, struct GeometryTriangle *T3, struct GeometryTriangle *T4 ){
	GeometryTriangleSet( T.x[0], T.y[0], 0.5*(T.x[0]+T.x[1]), 0.5*(T.y[0]+T.y[1]), 0.5*(T.x[0]+T.x[2]), 0.5*(T.y[0]+T.y[2]), T1 );
	GeometryTriangleSet( T.x[1], T.y[1], 0.5*(T.x[1]+T.x[2]), 0.5*(T.y[1]+T.y[2]), 0.5*(T.x[0]+T.x[1]), 0.5*(T.y[0]+T.y[1]), T2 );
	GeometryTriangleSet( T.x[2], T.y[2], 0.5*(T.x[0]+T.x[2]), 0.5*(T.y[0]+T.y[2]), 0.5*(T.x[1]+T.x[2]), 0.5*(T.y[1]+T.y[2]), T3 );
	GeometryTriangleSet( 0.5*(T.x[1]+T.x[2]), 0.5*(T.y[1]+T.y[2]), 0.5*(T.x[0]+T.x[2]), 0.5*(T.y[0]+T.y[2]), 0.5*(T.x[0]+T.x[1]), 0.5*(T.y[0]+T.y[1]), T4 );
};
void GeometryTriangleBisect( struct GeometryTriangle T, struct GeometryTriangle *T1, struct GeometryTriangle *T2, int vertex ){
        int vertex1 = (vertex+1)%3;
        int vertex2 = (vertex+2)%3;
        GeometryTriangleSet( 0.5*(T.x[vertex1]+T.x[vertex2]), 0.5*(T.y[vertex1]+T.y[vertex2]), T.x[vertex], T.y[vertex], T.x[vertex1], T.y[vertex1], T1 );
        GeometryTriangleSet( 0.5*(T.x[vertex1]+T.x[vertex2]), 0.5*(T.y[vertex1]+T.y[vertex2]), T.x[vertex2], T.y[vertex2], T.x[vertex], T.y[vertex], T2 );
};
void GeometryTriangleCopy( struct GeometryTriangle T, struct GeometryTriangle *T1 ){
        GeometryTriangleSet( T.x[0], T.y[0], T.x[1], T.y[1], T.x[2], T.y[2], T1 );
};

void GeometryDynamicQuadratureAddPoint( double x, double y, double w, struct GeometryDynamicQuadrature **Q ){
	struct GeometryDynamicQuadrature *tmp = (struct GeometryDynamicQuadrature*) malloc( sizeof(struct GeometryDynamicQuadrature) );
	tmp ->next = *Q;
	tmp -> x = x; tmp -> y = y; tmp -> w = w;
	*Q = tmp;
};

void GeometryDynamicQuadratureFree( struct GeometryDynamicQuadrature **Q ){
	struct GeometryDynamicQuadrature *tmp = NULL;
	while ( *Q != NULL ){
		tmp = *Q;
		*Q = (*Q) -> next;
		free( tmp );
	};
	*Q = NULL;
};

void GeometryQuadratureFree( struct GeometryQuadrature *Q ){
	Q->num_points = 0;
	free( Q -> w );
	free( Q -> x );
	free( Q -> y );
	free( Q -> xi );
	free( Q -> et );
};

void GeometryFormIntersectDiskSegment( struct GeometryDisk *C, double x0, double y0, double x1, double y1, struct GeometryIntersectDiskSegment *I ){
	// || (v0 - c) + alpha * ( v1 - v0 ) || = r, in other words, u = v0 - c and z = v1 - v0
	double ux = x0 - C->x;
	double uy = y0 - C->y;
	double zx = x1 - x0;
	double zy = y1 - y0;
	double dis = (zx*ux+zy*uy)*(zx*ux+zy*uy) - (zx*zx+zy*zy)*(ux*ux+uy*uy-C->r*C->r);
	if ( dis < 1.E-12 ){ // since we use the square-root of that, we need to consider small values of dis
		I -> num_points = 0;
		return;
	}else{
		I -> num_points = 0;
		double alpha = ( -(zx*ux+zy*uy) - sqrt( dis )) / ( zx*zx + zy*zy );
		if ( (alpha>1.E-7) && (alpha<1.0-1.E-7) ){
			I -> x[ I -> num_points ] = x0 + alpha * zx;
			I -> y[ I -> num_points ] = y0 + alpha * zy;
			I -> num_points ++;
		};
		alpha = ( -(zx*ux+zy*uy) + sqrt( dis )) / ( zx*zx + zy*zy );
		if ( (alpha>1.E-7) && (alpha<1.0-1.E-7) ){
			I -> x[ I -> num_points ] = x0 + alpha * zx;
			I -> y[ I -> num_points ] = y0 + alpha * zy;
			I -> num_points ++;
		};
	};
};

void GeometryDynamicQuadrature2GeometryQuadrature( struct GeometryDynamicQuadrature *DQ, struct GeometryQuadrature *SQ ){
	int i;
	struct GeometryDynamicQuadrature *tmp = DQ;
	SQ->num_points = 0;
	while ( tmp != NULL ){ SQ->num_points++; tmp = tmp -> next; }; // count the entries
	SQ->w = (double*) malloc( SQ->num_points * sizeof( double ) );
	SQ->x = (double*) malloc( SQ->num_points * sizeof( double ) );
	SQ->y = (double*) malloc( SQ->num_points * sizeof( double ) );
	SQ->xi = (double*) malloc( SQ->num_points * sizeof( double ) );
	SQ->et = (double*) malloc( SQ->num_points * sizeof( double ) );
	tmp = DQ;
	for( i=0; i<SQ->num_points; i++ ){
		SQ->w[i] = tmp -> w;
		SQ->x[i] = tmp -> x;
		SQ->y[i] = tmp -> y;
		tmp = tmp -> next;
	};
};

double GeometryTriangleIntersectDiskAreaBrute( struct GeometryTriangle T, struct GeometryDisk *C, double tolerance ){
	int N = (int) ( sqrt( T.det / ( 2.0 * tolerance ) ) + 1.0 );
	double dxi = 1.0 / ( (double)N ), det = 1.0 / ( (double)N ); // this is delta eta
	double xi = 0.0, et;
	double x_i, y_i;
	double integ = 0.0;
	while ( xi < 1.0 ){
		et = 0.0;
		while ( et + xi + dxi/3.0 + det/3.0 < 1.0 ){
			x_i = T.xi2x * (xi + dxi/3.0) + T.et2x * (et + det/3.0) + T.x[0];
			y_i = T.xi2y * (xi + dxi/3.0) + T.et2y * (et + det/3.0) + T.y[0];
                        integ += ( edist( x_i, y_i, C->x, C->y ) <= C->r ) ? 1.0 : 0.0;
			if ( xi + et + 2.0*dxi/3.0 + 2.0*det/3.0 < 1.0 ){
				x_i = T.xi2x * (xi + 2.0*dxi/3.0) + T.et2x * (et + 2.0*det/3.0) + T.x[0];
				y_i = T.xi2y * (xi + 2.0*dxi/3.0) + T.et2y * (et + 2.0*det/3.0) + T.y[0];
				integ += ( edist( x_i, y_i, C->x, C->y ) <= C->r ) ? 1.0 : 0.0;
			};
			et += det;
		};
		xi += dxi;
	};
	return integ * T.det / ( 2.0 * N * N );
};

int GeometryTrianglePointInside( struct GeometryTriangle T, double x, double y ){
	double dx = x - T.x[0];
	double dy = y - T.y[0];
	double xi = ( T.et2y * dx - T.et2x * dy ) / T.det;
	double et = (-T.xi2y * dx + T.xi2x * dy ) / T.det;
	return ( (xi>=0.0)&&(xi<=1.0)&&(et>=0.0)&&(et<=1.0)&&(xi+et<=1.0) ) ? 1 : 0;
};

void GeometryDynamicQuadratureAdd3PointsTriangle( struct GeometryTriangle T, struct GeometryDynamicQuadrature **Q ){
	struct GeometryDynamicQuadrature *tmp;
	// ---- point 1
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*T.det/3.0;
	tmp -> x = 0.5* (T.x[0] + T.x[1]);
	tmp -> y = 0.5* (T.y[0] + T.y[1]);
	tmp -> next = *Q; *Q = tmp;
	// ---- point 2
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*T.det/3.0;
	tmp -> x = 0.5* (T.x[1] + T.x[2]);
	tmp -> y = 0.5* (T.y[1] + T.y[2]);
	tmp -> next = *Q; *Q = tmp;
	// ---- point 3
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*T.det/3.0;
	tmp -> x = 0.5* (T.x[2] + T.x[0]);
	tmp -> y = 0.5* (T.y[2] + T.y[0]);
	tmp -> next = *Q; *Q = tmp;
};

void GeometryQuadratureAdd3PointsTriangle( struct GeometryTriangle T, struct GeometryQuadrature *Q ){
	Q->num_points = 3;
	Q->w  = (double*) malloc( 3*sizeof(double) );
	Q->x  = (double*) malloc( 3*sizeof(double) );
	Q->y  = (double*) malloc( 3*sizeof(double) );
	Q->xi = (double*) malloc( 3*sizeof(double) );
	Q->et = (double*) malloc( 3*sizeof(double) );
	// ---- point 1
	Q->w[0] = 0.5*T.det/3.0;
	Q->x[0] = 0.5* (T.x[0] + T.x[1]);
	Q->y[0] = 0.5* (T.y[0] + T.y[1]);
	// ---- point 2
	Q->w[1] = 0.5*T.det/3.0;
	Q->x[1] = 0.5* (T.x[1] + T.x[2]);
	Q->y[1] = 0.5* (T.y[1] + T.y[2]);
	// ---- point 3
	Q->w[2] = 0.5*T.det/3.0;
	Q->x[2] = 0.5* (T.x[2] + T.x[0]);
	Q->y[2] = 0.5* (T.y[2] + T.y[0]);
};

void GeometryDynamicQuadratureAdd6PointsTriangle( struct GeometryTriangle T, struct GeometryDynamicQuadrature **Q ){
	struct GeometryDynamicQuadrature *tmp;
	// ---- point 1
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.10995174365532*T.det;
	tmp -> x = T.xi2x * 0.816847572980459 + T.et2x * 0.091576213509771 + T.x[0];
	tmp -> y = T.xi2y * 0.816847572980459 + T.et2y * 0.091576213509771 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
	// ---- point 2
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.10995174365532*T.det;
	tmp -> x = T.xi2x * 0.091576213509771 + T.et2x * 0.816847572980459 + T.x[0];
	tmp -> y = T.xi2y * 0.091576213509771 + T.et2y * 0.816847572980459 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
	// ---- point 3
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.10995174365532*T.det;
	tmp -> x = T.xi2x * 0.091576213509771 + T.et2x * 0.091576213509771 + T.x[0];
	tmp -> y = T.xi2y * 0.091576213509771 + T.et2y * 0.091576213509771 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
	// ---- point 4
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.223381589678011*T.det;
	tmp -> x = T.xi2x * 0.10810301816807 + T.et2x * 0.445948490915965 + T.x[0];
	tmp -> y = T.xi2y * 0.10810301816807 + T.et2y * 0.445948490915965 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
	// ---- point 5
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.223381589678011*T.det;
	tmp -> x = T.xi2x * 0.445948490915965 + T.et2x * 0.10810301816807 + T.x[0];
	tmp -> y = T.xi2y * 0.445948490915965 + T.et2y * 0.10810301816807 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
	// ---- point 6
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.223381589678011*T.det;
	tmp -> x = T.xi2x * 0.445948490915965 + T.et2x * 0.445948490915965 + T.x[0];
	tmp -> y = T.xi2y * 0.445948490915965 + T.et2y * 0.445948490915965 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
};

void GeometryQuadratureAdd6PointsTriangle( struct GeometryTriangle T, struct GeometryQuadrature *Q ){
	Q->num_points = 6;
	Q->w  = (double*) malloc( 6*sizeof(double) );
	Q->x  = (double*) malloc( 6*sizeof(double) );
	Q->y  = (double*) malloc( 6*sizeof(double) );
	Q->xi = (double*) malloc( 6*sizeof(double) );
	Q->et = (double*) malloc( 6*sizeof(double) );
	// ---- point 1
	Q->w[0] = 0.5*0.10995174365532*T.det;
	Q->x[0] = T.xi2x * 0.816847572980459 + T.et2x * 0.091576213509771 + T.x[0];
	Q->y[0] = T.xi2y * 0.816847572980459 + T.et2y * 0.091576213509771 + T.y[0];
	// ---- point 2
	Q->w[1] = 0.5*0.10995174365532*T.det;
	Q->x[1] = T.xi2x * 0.091576213509771 + T.et2x * 0.816847572980459 + T.x[0];
	Q->y[1] = T.xi2y * 0.091576213509771 + T.et2y * 0.816847572980459 + T.y[0];
	// ---- point 3
	Q->w[2] = 0.5*0.10995174365532*T.det;
	Q->x[2] = T.xi2x * 0.091576213509771 + T.et2x * 0.091576213509771 + T.x[0];
	Q->y[2] = T.xi2y * 0.091576213509771 + T.et2y * 0.091576213509771 + T.y[0];
	// ---- point 4
	Q->w[3] = 0.5*0.223381589678011*T.det;
	Q->x[3] = T.xi2x * 0.10810301816807 + T.et2x * 0.445948490915965 + T.x[0];
	Q->y[3] = T.xi2y * 0.10810301816807 + T.et2y * 0.445948490915965 + T.y[0];
	// ---- point 5
	Q->w[4] = 0.5*0.223381589678011*T.det;
	Q->x[4] = T.xi2x * 0.445948490915965 + T.et2x * 0.10810301816807 + T.x[0];
	Q->y[4] = T.xi2y * 0.445948490915965 + T.et2y * 0.10810301816807 + T.y[0];
	// ---- point 6
	Q->w[5] = 0.5*0.223381589678011*T.det;
	Q->x[5] = T.xi2x * 0.445948490915965 + T.et2x * 0.445948490915965 + T.x[0];
	Q->y[5] = T.xi2y * 0.445948490915965 + T.et2y * 0.445948490915965 + T.y[0];
};

void GeometryDynamicQuadratureAdd7PointsTriangle( struct GeometryTriangle T, struct GeometryDynamicQuadrature **Q ){
	struct GeometryDynamicQuadrature *tmp;
	// ---- point 1
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.225*T.det;
	tmp -> x = T.xi2x * 0.333333333333333 + T.et2x * 0.333333333333333 + T.x[0];
	tmp -> y = T.xi2y * 0.333333333333333 + T.et2y * 0.333333333333333 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
	// ---- point 2
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.125939180544827*T.det;
	tmp -> x = T.xi2x * 0.797426985353087 + T.et2x * 0.101286507323456 + T.x[0];
	tmp -> y = T.xi2y * 0.797426985353087 + T.et2y * 0.101286507323456 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
	// ---- point 3
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.125939180544827*T.det;
	tmp -> x = T.xi2x * 0.101286507323456 + T.et2x * 0.797426985353087 + T.x[0];
	tmp -> y = T.xi2y * 0.101286507323456 + T.et2y * 0.797426985353087 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
	// ---- point 4
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.125939180544827*T.det;
	tmp -> x = T.xi2x * 0.101286507323456 + T.et2x * 0.101286507323456 + T.x[0];
	tmp -> y = T.xi2y * 0.101286507323456 + T.et2y * 0.101286507323456 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
	// ---- point 5
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.132394152788506*T.det;
	tmp -> x = T.xi2x * 0.059715871789770 + T.et2x * 0.470142064105115 + T.x[0];
	tmp -> y = T.xi2y * 0.059715871789770 + T.et2y * 0.470142064105115 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
	// ---- point 6
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.132394152788506*T.det;
	tmp -> x = T.xi2x * 0.470142064105115 + T.et2x * 0.059715871789770 + T.x[0];
	tmp -> y = T.xi2y * 0.470142064105115 + T.et2y * 0.059715871789770 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
	// ---- point 7
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*0.132394152788506*T.det;
	tmp -> x = T.xi2x * 0.470142064105115 + T.et2x * 0.470142064105115 + T.x[0];
	tmp -> y = T.xi2y * 0.470142064105115 + T.et2y * 0.470142064105115 + T.y[0];
	tmp -> next = *Q; *Q = tmp;
};

void GeometryQuadratureAdd7PointsTriangle( struct GeometryTriangle T, struct GeometryQuadrature *Q ){
	Q->num_points = 7;
	Q->w  = (double*) malloc( 7*sizeof(double) );
	Q->x  = (double*) malloc( 7*sizeof(double) );
	Q->y  = (double*) malloc( 7*sizeof(double) );
	Q->xi = (double*) malloc( 7*sizeof(double) );
	Q->et = (double*) malloc( 7*sizeof(double) );
	// ---- point 1
	Q->w[0] = 0.5*0.225*T.det;
	Q->x[0] = T.xi2x * 0.333333333333333 + T.et2x * 0.333333333333333 + T.x[0];
	Q->y[0] = T.xi2y * 0.333333333333333 + T.et2y * 0.333333333333333 + T.y[0];
	// ---- point 2
	Q->w[1] = 0.5*0.125939180544827*T.det;
	Q->x[1] = T.xi2x * 0.797426985353087 + T.et2x * 0.101286507323456 + T.x[0];
	Q->y[1] = T.xi2y * 0.797426985353087 + T.et2y * 0.101286507323456 + T.y[0];
	// ---- point 3
	Q->w[2] = 0.5*0.125939180544827*T.det;
	Q->x[2] = T.xi2x * 0.101286507323456 + T.et2x * 0.797426985353087 + T.x[0];
	Q->y[2] = T.xi2y * 0.101286507323456 + T.et2y * 0.797426985353087 + T.y[0];
	// ---- point 4
	Q->w[3] = 0.5*0.125939180544827*T.det;
	Q->x[3] = T.xi2x * 0.101286507323456 + T.et2x * 0.101286507323456 + T.x[0];
	Q->y[3] = T.xi2y * 0.101286507323456 + T.et2y * 0.101286507323456 + T.y[0];
	// ---- point 5
	Q->w[4] = 0.5*0.132394152788506*T.det;
	Q->x[4] = T.xi2x * 0.059715871789770 + T.et2x * 0.470142064105115 + T.x[0];
	Q->y[4] = T.xi2y * 0.059715871789770 + T.et2y * 0.470142064105115 + T.y[0];
	// ---- point 6
	Q->w[5] = 0.5*0.132394152788506*T.det;
	Q->x[5] = T.xi2x * 0.470142064105115 + T.et2x * 0.059715871789770 + T.x[0];
	Q->y[5] = T.xi2y * 0.470142064105115 + T.et2y * 0.059715871789770 + T.y[0];
	// ---- point 7
	Q->w[6] = 0.5*0.132394152788506*T.det;
	Q->x[6] = T.xi2x * 0.470142064105115 + T.et2x * 0.470142064105115 + T.x[0];
	Q->y[6] = T.xi2y * 0.470142064105115 + T.et2y * 0.470142064105115 + T.y[0];
};

void GeometryDynamicQuadratureAdd12PointsDisk( double x, double y, double delta, struct GeometryDynamicQuadrature **Q ){
	double diskx[4]  = { -0.80901699437495, -0.30901699437495, 0.30901699437495, 0.80901699437495 };
        double diskw[4]  = {  0.36931636609870,  0.59756643294804, 0.59756643294804, 0.36931636609870 };
        double gaussx[3] = { -0.774596669241,    0.0,              0.774596669241 };
        double gaussw[3] = {  0.55555555555556,  0.88888888888889, 0.55555555555556 };
        struct GeometryDynamicQuadrature *tmp;
        int i, j;
        for( i=0; i<4; i++ ){ // for the lines in the disk integral
                for( j=0; j<3; j++ ){ // add the Gaussian integrals for the lines
                        tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
                        tmp -> w = diskw[i] * gaussw[j] * sqrt( 1.0 - diskx[i]*diskx[i] )*delta*delta;
                        tmp -> x = x + delta*diskx[i];
                        tmp -> y = y + gaussx[j] * sqrt( 1.0 - diskx[i]*diskx[i] ) * delta;
                        tmp -> next = *Q; *Q = tmp;
                };
        };
};

void GeometryDynamicQuadratureAdd36PointsDisk( struct GeometryDisk *C, struct GeometryDynamicQuadrature **Q ){
        double diskx[6]  = { 0.90096886790242, 0.62348980185873, 0.22252093395631, -0.22252093395631, -0.62348980185873, -0.90096886790242 };
        double diskw[6]  = { 0.19472656676044, 0.35088514880954, 0.43754662381298,  0.43754662381298,  0.35088514880954,  0.19472656676044 };
        double gaussx[6] = { -0.93246951, -0.66120939, -0.23861918, 0.23861918, 0.66120939, 0.93246951 };
        double gaussw[6] = {  0.17132449,  0.36076157,  0.46791393, 0.46791393, 0.36076157, 0.17132449 };
        int i, j;
        struct GeometryDynamicQuadrature *tmp;
        for( i=0; i<6; i++ ){ // for the lines in the disk integral
                for( j=0; j<6; j++ ){ // add the Gaussian integrals for the lines
                        tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
                        tmp -> w = diskw[i] * gaussw[j] * sqrt( 1.0 - diskx[i]*diskx[i] )*C->r*C->r;
                        tmp -> x = C->x + C->r*diskx[i];
                        tmp -> y = C->y + gaussx[j] * sqrt( 1.0 - diskx[i]*diskx[i] ) * C->r;
                        tmp -> next = *Q; *Q = tmp;
                };
        };
};

void GeometryDynamicQuadratureAdd12PointsDiskSideSynced( struct GeometryTriangle T, double x, double y, double delta, struct GeometryDynamicQuadrature **Q ){
	double xi = ( T.et2y * (x - T.x[0]) - T.et2x * (y - T.y[0]) ) / T.det;
	double et = (-T.xi2y * (x - T.x[0]) + T.xi2x * (y - T.y[0]) ) / T.det;
	double zi = 1.0 - xi - et;
	double hdx, hdy, vdx, vdy; // vertical and horizontal directions x and y components
	// determine the closest side
	if ( xi < et ){
		if ( zi < xi ){
			// zi is the smallest since zi < xi < et, pick hypotenuse
			hdx = T.x[2] - T.x[1];
			hdy = T.y[2] - T.y[1];
		}else{
			// xi is the smallest since xi < zi and xi < et, vertical leg
			hdx = T.x[0] - T.x[2];
			hdy = T.y[0] - T.y[2];
		};
	}else{
		if ( zi < et ){
			// zi is the smallest since zi < et < xi, pick hypotenuse
			hdx = T.x[2] - T.x[1];
			hdy = T.y[2] - T.y[1];
		}else{
			// et is the smallest since et < zi and et < xi, horizontal leg
			hdx = T.x[1] - T.x[0];
			hdy = T.y[1] - T.y[0];
		};
	};
	xi = sqrt( hdx*hdx + hdy*hdy ); // use xi as a dummy variable
	hdx /= xi; hdy /= xi;
	// get the orthogonal direction
	vdx = -hdy; vdy = hdx;
	// add the 12 points
	struct GeometryDynamicQuadrature *tmp;
	// ---- point 1  quad disk point 1 - quad line point 1
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.36931636609870 * 0.55555555555556* sqrt( 1.0 - 0.80901699437495*0.80901699437495 )*delta*delta;
	tmp -> x = x - delta*0.80901699437495*hdx - 0.774596669241*sqrt(1.0-0.80901699437495*0.80901699437495)*delta*vdx;
	tmp -> y = y - delta*0.80901699437495*hdy - 0.774596669241*sqrt(1.0-0.80901699437495*0.80901699437495)*delta*vdy;
	tmp -> next = *Q; *Q = tmp;
	// ---- point 2  quad disk point 1 - quad line point 2
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.36931636609870 * 0.88888888888889* sqrt( 1.0 - 0.80901699437495*0.80901699437495 )*delta*delta;
	tmp -> x = x - delta*0.80901699437495*hdx;
	tmp -> y = y - delta*0.80901699437495*hdy;
	tmp -> next = *Q; *Q = tmp;
	// ---- point 3  quad disk point 1 - quad line point 3
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.36931636609870 * 0.55555555555556* sqrt( 1.0 - 0.80901699437495*0.80901699437495 )*delta*delta;
	tmp -> x = x - delta*0.80901699437495*hdx + 0.774596669241*sqrt(1.0-0.80901699437495*0.80901699437495)*delta*vdx;
	tmp -> y = y - delta*0.80901699437495*hdy + 0.774596669241*sqrt(1.0-0.80901699437495*0.80901699437495)*delta*vdy;
	tmp -> next = *Q; *Q = tmp;
	// ---- point 4  quad disk point 2 - quad line point 1
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.59756643294895 * 0.55555555555556 * sqrt( 1.0 - 0.30901699437495*0.30901699437495 )*delta*delta;
	tmp -> x = x - delta*0.30901699437495*hdx - 0.774596669241*sqrt(1.0-0.30901699437495*0.30901699437495)*delta*vdx;
	tmp -> y = y - delta*0.30901699437495*hdy - 0.774596669241*sqrt(1.0-0.30901699437495*0.30901699437495)*delta*vdy;
	tmp -> next = *Q; *Q = tmp;
	// ---- point 5  quad disk point 2 - quad line point 2
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.59756643294895 * 0.88888888888889 * sqrt( 1.0 - 0.30901699437495*0.30901699437495 )*delta*delta;
	tmp -> x = x - delta*0.30901699437495*hdx;
	tmp -> y = y - delta*0.30901699437495*hdy;
	tmp -> next = *Q; *Q = tmp;
	// ---- point 6  quad disk point 2 - quad line point 3
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.59756643294895 * 0.55555555555556 * sqrt( 1.0 - 0.30901699437495*0.30901699437495 )*delta*delta;
	tmp -> x = x - delta*0.30901699437495*hdx + 0.774596669241*sqrt(1.0-0.30901699437495*0.30901699437495)*delta*vdx;
	tmp -> y = y - delta*0.30901699437495*hdy + 0.774596669241*sqrt(1.0-0.30901699437495*0.30901699437495)*delta*vdy;
	tmp -> next = *Q; *Q = tmp;
	// ---- point 7  quad disk point 3 - quad line point 1
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.59756643294895 * 0.55555555555556 * sqrt( 1.0 - 0.30901699437495*0.30901699437495 )*delta*delta;
	tmp -> x = x + delta*0.30901699437495*hdx - 0.774596669241*sqrt(1.0-0.30901699437495*0.30901699437495)*delta*vdx;
	tmp -> y = y + delta*0.30901699437495*hdy - 0.774596669241*sqrt(1.0-0.30901699437495*0.30901699437495)*delta*vdy;
	tmp -> next = *Q; *Q = tmp;
	// ---- point 8  quad disk point 3 - quad line point 2
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.59756643294895 * 0.88888888888889 * sqrt( 1.0 - 0.30901699437495*0.30901699437495 )*delta*delta;
	tmp -> x = x + delta*0.30901699437495*hdx;
	tmp -> y = y + delta*0.30901699437495*hdy;
	tmp -> next = *Q; *Q = tmp;
	// ---- point 9  quad disk point 3 - quad line point 3
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.59756643294895 * 0.55555555555556 * sqrt( 1.0 - 0.30901699437495*0.30901699437495 )*delta*delta;
	tmp -> x = x + delta*0.30901699437495*hdx + 0.774596669241*sqrt(1.0-0.30901699437495*0.30901699437495)*delta*vdx;
	tmp -> y = y + delta*0.30901699437495*hdy + 0.774596669241*sqrt(1.0-0.30901699437495*0.30901699437495)*delta*vdy;
	tmp -> next = *Q; *Q = tmp;
	// ---- point 10  quad disk point 4 - quad line point 1
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.36931636609870 * 0.55555555555556* sqrt( 1.0 - 0.80901699437495*0.80901699437495 )*delta*delta;
	tmp -> x = x + delta*0.80901699437495*hdx - 0.774596669241*sqrt(1.0-0.80901699437495*0.80901699437495)*delta*vdx;
	tmp -> y = y + delta*0.80901699437495*hdy - 0.774596669241*sqrt(1.0-0.80901699437495*0.80901699437495)*delta*vdy;
	tmp -> next = *Q; *Q = tmp;
	// ---- point 11  quad disk point 4 - quad line point 2
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.36931636609870 * 0.88888888888889* sqrt( 1.0 - 0.80901699437495*0.80901699437495 )*delta*delta;
	tmp -> x = x + delta*0.80901699437495*hdx;
	tmp -> y = y + delta*0.80901699437495*hdy;
	tmp -> next = *Q; *Q = tmp;
	// ---- point 12  quad disk point 4 - quad line point 3
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.36931636609870 * 0.55555555555556* sqrt( 1.0 - 0.80901699437495*0.80901699437495 )*delta*delta;
	tmp -> x = x + delta*0.80901699437495*hdx + 0.774596669241*sqrt(1.0-0.80901699437495*0.80901699437495)*delta*vdx;
	tmp -> y = y + delta*0.80901699437495*hdy + 0.774596669241*sqrt(1.0-0.80901699437495*0.80901699437495)*delta*vdy;
	tmp -> next = *Q; *Q = tmp;
};

double GeometryTriangleSliceExact( double x0, double y0, double x1, double y1, struct GeometryDisk *C ){
        double dx = x1-x0, dy = y1-y0;
        double theta = 2.0*asin( sqrt( dx*dx + dy*dy ) / (2.0 * C->r) );
        double small_area = 0.5*C->r*C->r*( theta - sin( theta ) );
        return ( ( (C->y-y1)*dx - (C->x-x1)*dy < 0.0 ) ) ? small_area : C->r*C->r*M_PI - small_area;
};

double GeometryTriangleIntersectDiskAreaExact( struct GeometryTriangle T, struct GeometryDisk *C ){
        struct GeometryIntersectDiskSegment cross[3];
        struct GeometryTriangle TT;
	int i, vertex;
        double area = 0.0;
	// get the intersection points
	for( i=0; i<3; i++ ){
		GeometryFormIntersectDiskSegment( C, T.x[i], T.y[i], T.x[(i+1)%3], T.y[(i+1)%3], &cross[i] );
	};
	// get the ordering of the most points
	int first = 0, second = 0, third = 0;
	for( i=1; i<3; i++ ){
		if ( cross[i].num_points > cross[first].num_points ){
			first = i;
		};
	};
	second = (first+1)%3;
	for( i=0; i<3; i++ ){
		if ( (i != first) && (cross[i].num_points > cross[second].num_points) ){
			second = i;
		};
	};
	third = (first+1)%3;
	if ( third == second ){ third = (first+2)%3; };
	// consider the separate cases
        if ( cross[first].num_points == 0 ){
                if ( (cross[second].num_points != 0) || (cross[third].num_points != 0) ){
                        printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry first is 0, but second or third is not\n");
                };
                if ( (edist( T.x[0], T.y[0], C->x, C->y ) < C->r+1.E-7 )&&
                     (edist( T.x[1], T.y[1], C->x, C->y ) < C->r+1.E-7 )&&
                     (edist( T.x[2], T.y[2], C->x, C->y ) < C->r+1.E-7 ) ){
                             area = 0.5 * T.det;
                }else{
                        if ( GeometryTrianglePointInside( T, C->x, C->y ) == 1 ){
                                area = M_PI * C->r * C->r;
                        }else{
                                area = 0.0;
                        };
                };
        }else if ( cross[first].num_points == 1 ){
                if ( (cross[second].num_points != 1)||(cross[third].num_points != 0) ){
                        printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry, we have 100 or 111 or 12*\n");
                        printf(" Triangle  %f %f %f %f %f %f\n",T.x[0],T.y[0],T.x[1],T.y[1],T.x[2],T.y[2]);
                        printf(" Disk: %f %f %f\n",C->x,C->y,C->r);
                };
                vertex = -1;
                for( i=0; i<3; i++ ){ 
                        if ( edist( T.x[i], T.y[i], C->x, C->y ) < C->r+1.E-7 ){
                                vertex = i;
                                break;
                        };
                };
                if ( vertex == -1 ){
                        printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry, we have 110 but none of the vertexes are inside the disk\n");
                };
                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[first].x[0], cross[first].y[0], cross[second].x[0], cross[second].y[0], &TT );
                area += 0.5 * TT.det;
                area += GeometryTriangleSliceExact( TT.x[2], TT.y[2], TT.x[1], TT.y[1], C );
                if ( edist( T.x[(vertex+1)%3], T.y[(vertex+1)%3], C->x, C->y ) < C->r+1.E-7 ){
                        // we have two points inside
                        if ( ((vertex+1)%3 == first) ){
                                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[first].x[0], cross[first].y[0], T.x[(vertex+1)%3], T.y[(vertex+1)%3], &TT );
                                area += 0.5*TT.det;
                        }else{
                                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[second].x[0], cross[second].y[0], T.x[(vertex+1)%3], T.y[(vertex+1)%3], &TT );
                                area += 0.5*TT.det;
                        };
                }else if ( edist( T.x[(vertex+2)%3], T.y[(vertex+2)%3], C->x, C->y ) < C->r+1.E-7 ){
                        if ( ((vertex+1)%3 == first) ){
                                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[first].x[0], cross[first].y[0], T.x[(vertex+2)%3], T.y[(vertex+2)%3], &TT );
                                area += 0.5*TT.det;
                        }else{
                                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[second].x[0], cross[second].y[0], T.x[(vertex+2)%3], T.y[(vertex+2)%3], &TT );
                                area += 0.5*TT.det;
                        };
                };
        }else{
                if ( cross[second].num_points == 2 ){
                        if ( cross[third].num_points == 2 ){
                                for( i=0; i<3; i++ ){
                                        GeometryTriangleSetSafe( T.x[(i+1)%3], T.y[(i+1)%3], cross[(i+1)%3].x[0], cross[(i+1)%3].y[0], cross[i].x[1], cross[i].y[1], &TT );
                                        area += GeometryTriangleSliceExact( TT.x[1], TT.y[1], TT.x[2], TT.y[2], C );
                                };
                                GeometryTriangleSetSafe( cross[0].x[0], cross[0].y[0], cross[2].x[1], cross[2].y[1], cross[2].x[0], cross[2].y[0], &TT );
                                area += 0.5*TT.det;
                                GeometryTriangleSetSafe( cross[2].x[0], cross[2].y[0], cross[0].x[1], cross[0].y[1], cross[0].x[0], cross[0].y[0], &TT );
                                area += 0.5*TT.det;
                                GeometryTriangleSetSafe( cross[2].x[0], cross[2].y[0], cross[1].x[1], cross[1].y[1], cross[0].x[1], cross[0].y[1], &TT );
                                area += 0.5*TT.det;
                                GeometryTriangleSetSafe( cross[1].x[0], cross[1].y[0], cross[1].x[1], cross[1].y[1], cross[0].x[1], cross[0].y[1], &TT );
                                area += 0.5*TT.det;
                        }else if ( cross[third].num_points == 1 ){
                               printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry, we have 221\n"); 
                        }else{
                                GeometryTriangleSetSafe( cross[first].x[0], cross[first].y[0], cross[first].x[1], cross[first].y[1], cross[second].x[0], cross[second].y[0], &TT );
                                area += 0.5*TT.det;
                                area += GeometryTriangleSliceExact( TT.x[2], TT.y[2], TT.x[1], TT.y[1], C );
                                GeometryTriangleSetSafe( cross[second].x[0], cross[second].y[0], cross[first].x[0], cross[first].y[0], cross[second].x[1], cross[second].y[1], &TT );
                                area += 0.5*TT.det;
                                area += GeometryTriangleSliceExact( TT.x[2], TT.y[2], TT.x[1], TT.y[1], C );
                        };
                }else if ( cross[second].num_points == 1 ){
                        if ( cross[third].num_points == 1 ){
                                vertex = -1;
                                for( i=0; i<3; i++ ){ 
                                        if ( edist( T.x[i], T.y[i], C->x, C->y ) < C->r+1.E-7 ){
                                                vertex = i;
                                                break;
                                        };
                                };
                                // add triangles
                                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[vertex].x[0], cross[vertex].y[0], cross[(vertex+2)%3].x[0], cross[(vertex+2)%3].y[0], &TT );
                                area += 0.5*TT.det;
                                GeometryTriangleSetSafe( cross[vertex].x[0], cross[vertex].y[0], cross[(vertex+2)%3].x[0], cross[(vertex+2)%3].y[0], cross[(vertex+1)%3].x[0], cross[(vertex+1)%3].y[0], &TT );
                                area += 0.5*TT.det;
                                GeometryTriangleSetSafe( cross[(vertex+2)%3].x[0], cross[(vertex+2)%3].y[0], cross[(vertex+1)%3].x[0], cross[(vertex+1)%3].y[0], cross[(vertex+1)%3].x[1], cross[(vertex+1)%3].y[1], &TT );
                                area += 0.5*TT.det;
                                // add slices
                                GeometryTriangleSetSafe( T.x[(vertex+1)%3], T.y[(vertex+1)%3], cross[vertex].x[0], cross[vertex].y[0], cross[(vertex+1)%3].x[0], cross[(vertex+1)%3].y[0], &TT );
                                area += GeometryTriangleSliceExact( TT.x[1], TT.y[1], TT.x[2], TT.y[2], C );
                                GeometryTriangleSetSafe( T.x[(vertex+2)%3], T.y[(vertex+2)%3], cross[(vertex+2)%3].x[0], cross[(vertex+2)%3].y[0], cross[(vertex+1)%3].x[1], cross[(vertex+1)%3].y[1], &TT );
                                area += GeometryTriangleSliceExact( TT.x[1], TT.y[1], TT.x[2], TT.y[2], C );
                        }else{
                                printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry, we have 210 or 212\n"); 
                        };
                }else{
                        if ( cross[third].num_points != 0 ){
                                printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry, we have 201 or 202\n"); 
                        };
                        area += GeometryTriangleSliceExact( cross[first].x[0], cross[first].y[0], cross[first].x[1], cross[first].y[1], C );
                };
        };
        return area;
};

void GeometryDynamicQuadratureTriangleDiskIntersection( struct GeometryTriangle T, struct GeometryDisk *C, struct GeometryDynamicQuadrature **Q ){
	struct GeometryIntersectDiskSegment cross[3];
        struct GeometryTriangle TT;
	int i, vertex;
	// get the intersection points
	for( i=0; i<3; i++ ){
		GeometryFormIntersectDiskSegment( C, T.x[i], T.y[i], T.x[(i+1)%3], T.y[(i+1)%3], &cross[i] );
	};
	// get the ordering of the most points
	int first = 0, second = 0, third = 0;
	for( i=1; i<3; i++ ){
		if ( cross[i].num_points > cross[first].num_points ){
			first = i;
		};
	};
	second = (first+1)%3;
	for( i=0; i<3; i++ ){
		if ( (i != first) && (cross[i].num_points > cross[second].num_points) ){
			second = i;
		};
	};
	third = (first+1)%3;
	if ( third == second ){ third = (first+2)%3; };
	// consider the separate cases
        if ( cross[first].num_points == 0 ){
                if ( (cross[second].num_points != 0) || (cross[third].num_points != 0) ){
                        printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry first is 0, but second or third is not\n");
                };
                if ( (edist( T.x[0], T.y[0], C->x, C->y ) < C->r+1.E-7 )&&
                     (edist( T.x[1], T.y[1], C->x, C->y ) < C->r+1.E-7 )&&
                     (edist( T.x[2], T.y[2], C->x, C->y ) < C->r+1.E-7 ) ){
                             // triangle is entirely covered
                             GeometryDynamicQuadratureAdd6PointsTriangle( T, Q );
                }else{
                        if ( GeometryTrianglePointInside( T, C->x, C->y ) == 1 ){
                                // disk is entirely within
                                GeometryDynamicQuadratureAdd36PointsDisk( C, Q );
                        }else{
                                // no intersection
                                return;
                        };
                };
        }else if ( cross[first].num_points == 1 ){
                if ( (cross[second].num_points != 1)||(cross[third].num_points != 0) ){
                        printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry, we have 100 or 111 or 12*\n");
                        printf(" Triangle  %f %f %f %f %f %f\n",T.x[0],T.y[0],T.x[1],T.y[1],T.x[2],T.y[2]);
                        printf(" Disk: %f %f %f\n",C->x,C->y,C->r);
                        printf(" First = %d  Second = %d  Third = %d\n",first,second,third);
                        printf(" cross[first] num_points = %d  x = %f  y = %f\n",cross[first].num_points,cross[first].x[0],cross[first].y[0]);
                        printf(" num_points for second = %d   num_points for third = %d\n",cross[second].num_points,cross[third].num_points);
                };
                vertex = -1;
                for( i=0; i<3; i++ ){ 
                        if ( edist( T.x[i], T.y[i], C->x, C->y ) < C->r+1.E-7 ){
                                vertex = i;
                                break;
                        };
                };
                if ( vertex == -1 ){
                        printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry, we have 110 but none of the vertexes are inside the disk\n");
                };
                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[first].x[0], cross[first].y[0], cross[second].x[0], cross[second].y[0], &TT );
                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                GeometryDynamicQuadratureAddSlice( TT.x[2], TT.y[2], TT.x[1], TT.y[1], C, Q );
                if ( edist( T.x[(vertex+1)%3], T.y[(vertex+1)%3], C->x, C->y ) < C->r+1.E-7 ){
                        // we have two points inside
                        if ( ((vertex+1)%3 == first) ){
                                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[first].x[0], cross[first].y[0], T.x[(vertex+1)%3], T.y[(vertex+1)%3], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                        }else{
                                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[second].x[0], cross[second].y[0], T.x[(vertex+1)%3], T.y[(vertex+1)%3], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                        };
                }else if ( edist( T.x[(vertex+2)%3], T.y[(vertex+2)%3], C->x, C->y ) < C->r+1.E-7 ){
                        if ( ((vertex+1)%3 == first) ){
                                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[first].x[0], cross[first].y[0], T.x[(vertex+2)%3], T.y[(vertex+2)%3], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                        }else{
                                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[second].x[0], cross[second].y[0], T.x[(vertex+2)%3], T.y[(vertex+2)%3], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                        };
                };
        }else{
                if ( cross[second].num_points == 2 ){
                        if ( cross[third].num_points == 2 ){
                                for( i=0; i<3; i++ ){
                                        GeometryTriangleSetSafe( T.x[(i+1)%3], T.y[(i+1)%3], cross[(i+1)%3].x[0], cross[(i+1)%3].y[0], cross[i].x[1], cross[i].y[1], &TT );
                                        GeometryDynamicQuadratureAddSlice( TT.x[1], TT.y[1], TT.x[2], TT.y[2], C, Q );
                                };
                                GeometryTriangleSetSafe( cross[0].x[0], cross[0].y[0], cross[2].x[1], cross[2].y[1], cross[2].x[0], cross[2].y[0], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                                GeometryTriangleSetSafe( cross[2].x[0], cross[2].y[0], cross[0].x[1], cross[0].y[1], cross[0].x[0], cross[0].y[0], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                                GeometryTriangleSetSafe( cross[2].x[0], cross[2].y[0], cross[1].x[1], cross[1].y[1], cross[0].x[1], cross[0].y[1], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                                GeometryTriangleSetSafe( cross[1].x[0], cross[1].y[0], cross[1].x[1], cross[1].y[1], cross[0].x[1], cross[0].y[1], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                        }else if ( cross[third].num_points == 1 ){
                               printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry, we have 221\n"); 
                        }else{
                                GeometryTriangleSetSafe( cross[first].x[0], cross[first].y[0], cross[first].x[1], cross[first].y[1], cross[second].x[0], cross[second].y[0], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                                GeometryDynamicQuadratureAddSlice( TT.x[2], TT.y[2], TT.x[1], TT.y[1], C, Q );
                                GeometryTriangleSetSafe( cross[second].x[0], cross[second].y[0], cross[first].x[0], cross[first].y[0], cross[second].x[1], cross[second].y[1], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                                GeometryDynamicQuadratureAddSlice( TT.x[2], TT.y[2], TT.x[1], TT.y[1], C, Q );
                        };
                }else if ( cross[second].num_points == 1 ){
                        if ( cross[third].num_points == 1 ){
                                vertex = -1;
                                for( i=0; i<3; i++ ){ 
                                        if ( edist( T.x[i], T.y[i], C->x, C->y ) < C->r+1.E-7 ){
                                                vertex = i;
                                                break;
                                        };
                                };
                                // add triangles
                                GeometryTriangleSetSafe( T.x[vertex], T.y[vertex], cross[vertex].x[0], cross[vertex].y[0], cross[(vertex+2)%3].x[0], cross[(vertex+2)%3].y[0], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                                GeometryTriangleSetSafe( cross[vertex].x[0], cross[vertex].y[0], cross[(vertex+2)%3].x[0], cross[(vertex+2)%3].y[0], cross[(vertex+1)%3].x[0], cross[(vertex+1)%3].y[0], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                                GeometryTriangleSetSafe( cross[(vertex+2)%3].x[0], cross[(vertex+2)%3].y[0], cross[(vertex+1)%3].x[0], cross[(vertex+1)%3].y[0], cross[(vertex+1)%3].x[1], cross[(vertex+1)%3].y[1], &TT );
                                GeometryDynamicQuadratureAdd6PointsTriangle( TT, Q );
                                // add slices
                                GeometryTriangleSetSafe( T.x[(vertex+1)%3], T.y[(vertex+1)%3], cross[vertex].x[0], cross[vertex].y[0], cross[(vertex+1)%3].x[0], cross[(vertex+1)%3].y[0], &TT );
                                GeometryDynamicQuadratureAddSlice( TT.x[1], TT.y[1], TT.x[2], TT.y[2], C, Q );
                                GeometryTriangleSetSafe( T.x[(vertex+2)%3], T.y[(vertex+2)%3], cross[(vertex+2)%3].x[0], cross[(vertex+2)%3].y[0], cross[(vertex+1)%3].x[1], cross[(vertex+1)%3].y[1], &TT );
                                GeometryDynamicQuadratureAddSlice( TT.x[1], TT.y[1], TT.x[2], TT.y[2], C, Q );
                        }else{
                                printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry, we have 210 or 212\n"); 
                        };
                }else{
                        if ( cross[third].num_points != 0 ){
                                printf(" GeometryTriangleIntersectDiskAreaExact: wierd geometry, we have 201 or 202\n"); 
                        };
                        GeometryDynamicQuadratureAddSlice( cross[first].x[0], cross[first].y[0], cross[first].x[1], cross[first].y[1], C, Q );
                };
        };
};

// -------------------------------------------------------------------------------------------------------------- //
// ---------------- SLICE QUADRATURE ----------- //
// -------------------------------------------------------------------------------------------------------------- //

//#define __MP_CUTOFF_SIN_ (0.057308549091406)
//#define __MP_CUTOFF_SIN_ (0.028654274545703)
//#define __MP_CUTOFF_SIN_ (0.014327137272852)
//#define __MP_CUTOFF_SIN_ (0.007163568636426)
#define __MP_CUTOFF_SIN_ (0.003581784318213)
//#define __MP_CUTOFF_SIN_ (0.001790892155)

void MGDQAD_recurse_stage3( double x0, double y0, double x1, double y1, struct GeometryDisk *C, double *w, struct GeometryDynamicQuadrature **Q ){
        double mx = - (y1 - y0);
        double my =   (x1 - x0);
        double nrm = sqrt( mx*mx + my*my );
        mx = C->x + C->r * mx / nrm;
        my = C->y + C->r * my / nrm;
        
        struct GeometryTriangle T;
        GeometryTriangleSet( x0, y0, x1, y1, mx, my, &T );

        struct GeometryDynamicQuadrature *tmp;
	// ---- point 1 -- increment the old weight
        *w += 0.5*T.det/3.0;
	// ---- point 2
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*T.det/3.0;
	tmp -> x = 0.5* (T.x[1] + T.x[2]);
	tmp -> y = 0.5* (T.y[1] + T.y[2]);
	tmp -> next = *Q; *Q = tmp;
	// ---- point 3
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*T.det/3.0;
	tmp -> x = 0.5* (T.x[2] + T.x[0]);
	tmp -> y = 0.5* (T.y[2] + T.y[0]);
	tmp -> next = *Q; *Q = tmp;
        double sinhalftheta = 0.5 * sqrt( (x0-x1)*(x0-x1) + (y0-y1)*(y0-y1) ) / C -> r;
        if ( sinhalftheta > __MP_CUTOFF_SIN_ ){
                MGDQAD_recurse_stage3( mx, my, x1, y1, C, &((*Q)->next->w), Q );
                MGDQAD_recurse_stage3( x0, y0, mx, my, C, &((*Q)->w), Q );
        };
};

void MGDQAD_recurse_stage2( double x0, double y0, double x1, double y1, struct GeometryDisk *C, struct GeometryDynamicQuadrature **Q ){
        double mx = - (y1 - y0);
        double my =   (x1 - x0);
        double nrm = sqrt( mx*mx + my*my );
        mx = C->x + C->r * mx / nrm;
        my = C->y + C->r * my / nrm;
        struct GeometryTriangle T;
        GeometryTriangleSet( x0, y0, x1, y1, mx, my, &T );

        struct GeometryDynamicQuadrature *tmp;
	// ---- point 1
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*T.det/3.0;
	tmp -> x = 0.5* (T.x[0] + T.x[1]);
	tmp -> y = 0.5* (T.y[0] + T.y[1]);
	tmp -> next = *Q; *Q = tmp;
	// ---- point 2
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*T.det/3.0;
	tmp -> x = 0.5* (T.x[1] + T.x[2]);
	tmp -> y = 0.5* (T.y[1] + T.y[2]);
	tmp -> next = *Q; *Q = tmp;
	// ---- point 3
	tmp = (struct GeometryDynamicQuadrature *) malloc( sizeof( struct GeometryDynamicQuadrature ) );
	tmp -> w = 0.5*T.det/3.0;
	tmp -> x = 0.5* (T.x[2] + T.x[0]);
	tmp -> y = 0.5* (T.y[2] + T.y[0]);
	tmp -> next = *Q; *Q = tmp;
        double sinhalftheta = 0.5 * sqrt( (x0-x1)*(x0-x1) + (y0-y1)*(y0-y1) ) / C -> r;
        if ( sinhalftheta > __MP_CUTOFF_SIN_ ){
                MGDQAD_recurse_stage3( mx, my, x1, y1, C, &((*Q)->next->w), Q );
                MGDQAD_recurse_stage3( x0, y0, mx, my, C, &((*Q)->w), Q );
        };
};

void MGDQAD_recurse_stage1( double x0, double y0, double x1, double y1, struct GeometryDisk *C, struct GeometryDynamicQuadrature **Q ){
        // adds 6 point quadrature and if the next level is small enough, then it moves to 3 point quadrature stage2
        double mx = - (y1 - y0);
        double my =   (x1 - x0);
        double nrm = sqrt( mx*mx + my*my );
        mx = C->x + C->r * mx / nrm;
        my = C->y + C->r * my / nrm;

        struct GeometryTriangle T;
        GeometryTriangleSet( x0, y0, x1, y1, mx, my, &T );
        GeometryDynamicQuadratureAdd6PointsTriangle( T, Q );

        nrm = (mx-x0)*(mx-x0) + (my-y0)*(my-y0); // check for the length of the side, if it exceeds the length of the radius times sqrt(2), then go for another 6 point revision

        if ( nrm >= 2.0 * C->r * C->r ){
                // go for another 6 point revision
                MGDQAD_recurse_stage1( mx, my, x1, y1, C, Q );
                MGDQAD_recurse_stage1( x0, y0, mx, my, C, Q );
        }else{
                double sinhalftheta = 0.5 * sqrt( (x0-x1)*(x0-x1) + (y0-y1)*(y0-y1) ) / C -> r;
                if ( sinhalftheta > __MP_CUTOFF_SIN_ ){
                        MGDQAD_recurse_stage2( mx, my, x1, y1, C, Q );
                        MGDQAD_recurse_stage2( x0, y0, mx, my, C, Q );
                };
        };
};

void GeometryDynamicQuadratureAddSlice( double x0, double y0, double x1, double y1, struct GeometryDisk *C, struct GeometryDynamicQuadrature **Q ){
        // the cutoff criteria should be that the area of the next level is less than tol (hardcode to 10^(-6)
        // area for theta is ( theta - sin( theta ) / ( 2 PI ), for the next level it is 2 *( theta /2 - sin( theta/2) ) / ( 2 * PI ) < tol
        // this gives theta ~ 0.11467993 or sin( theta ) = 0.114428726652876 or sin( theta/2 ) = 0.057308549091406
        // for larger portion of the radious, use 6 points, for smaller pieces, use 3 points
        // note that the 3 points can be done efficiently since the next level overlaps with the previous one and we can simply adjust the weights
        // this would lead to even less points
        
        double mx = - (y1 - y0);
        double my =   (x1 - x0);
        double nrm = sqrt( mx*mx + my*my );
        mx = C->x + C->r * mx / nrm;
        my = C->y + C->r * my / nrm;
        nrm = (mx-x0)*(mx-x0) + (my-y0)*(my-y0); // check for the length of the side, if it exceeds the length of the radius times sqrt(2), then go for another 6 point revision
        if ( nrm >= 2.0 * C->r * C->r ){
                // go for another 6 point revision
                MGDQAD_recurse_stage1( x0, y0, x1, y1, C, Q );
        }else{
                double sinhalftheta = 0.5 * sqrt( (x0-x1)*(x0-x1) + (y0-y1)*(y0-y1) ) / C -> r;
                if ( sinhalftheta > 0.057308549091406 ){
                        MGDQAD_recurse_stage2( x0, y0, x1, y1, C, Q );
                };
        };
};

#endif
