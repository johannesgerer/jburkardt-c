/*
* This code isdistrubuted under GPLv3
* 
* Code Author: Miroslav Stoyanov, Nov 2011
* 
* Copyright (C) 2011  Miroslav Stoyanov
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* Since the GNU General Public License is longer than this entire code, 
* a copy of it can be obtained separately at <http://www.gnu.org/licenses/>
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "pd_simulator.h"

double PD_DELTA = 0.1;

double kernel_test_u( double up, double vp, double u, double v, double xp, double yp, double x, double y ){
	double dist = sqrt( (xp-x)*(xp-x) + (yp-y)*(yp-y) );
	return (( dist < PD_DELTA ) ? 1.0 : 0.0 );
};
double kernel_test_v( double up, double vp, double u, double v, double xp, double yp, double x, double y ){
	double dist = sqrt( (xp-x)*(xp-x) + (yp-y)*(yp-y) );
	return (( dist < PD_DELTA ) ? 1.0 : 0.0 );
};

double kernel_jump_u( double up, double vp, double u, double v, double xp, double yp, double x, double y ){
	double dist = sqrt( (xp-x)*(xp-x) + (yp-y)*(yp-y) );
	if ( dist < 1.E-4 ){ printf(" Dist is: %e\n",dist); };
	return (( dist < PD_DELTA ) ? 3.0 * (up - u) / ( dist * PD_DELTA * PD_DELTA * PD_DELTA * M_PI ) : 0.0 );
};
double kernel_jump_v( double up, double vp, double u, double v, double xp, double yp, double x, double y ){
	double dist = sqrt( (xp-x)*(xp-x) + (yp-y)*(yp-y) );
	return (( dist < PD_DELTA ) ? 3.0 * (vp - v) / ( dist * PD_DELTA * PD_DELTA * PD_DELTA * M_PI ) : 0.0 );
};

double b_force_symmetric_pull_u( double t, double x, double y ){
	return 0.0;
};
double b_force_symmetric_pull_v( double t, double x, double y ){
	if ( (y < 0.1 + 1.E-7) ){
		return -0.01;
	}else if ( (y > 1.0 - 0.1 - 1.E-7) ){
		return 0.01;
	}else{
		return 0;
	};
};

double b_force_bottom_pull_u( double t, double x, double y ){
	return 0.0;
};
double b_force_bottom_pull_v( double t, double x, double y ){
	if ( (y < 0.1 + 1.E-7) ){
		return -0.01;
	}else{
		return 0;
	};
};

double b_force_test_u( double t, double x, double y ){
	//return 0.0;
        //return -0.01*( (12.0*x-6.0)*(y*y-1.0) + (4.0*x*x*x - 6*x*x) ); // this matcher u = 0 on top and u' = 0 on sides
        return -0.01*sin( M_PI * x) * sin( M_PI * y ); // this matches u = 0 on all sided
};
double b_force_test_v( double t, double x, double y ){
	/*if ( (y < 0.1 + 1.E-7) ){
		return -0.01;
	}else{
		return 0;
	};*/
	//return -0.01*sin( PD_PI * x) * sin( PD_PI * y ); // this matches u = 0 on all sided
        return 0;
};

int boundary = MESH_BOUNDARY_LEFT | MESH_BOUNDARY_RIGHT | MESH_BOUNDARY_TOP | MESH_BOUNDARY_BOTTOM;
const double refine_tolerance = 0.05;


double boundary_homogenious( double t, double x, double y ){
	return 0.0;
};


int main( int argc, char** argv ){
        
        struct PDProblem P;
        
        int Nx = 10, Ny = 10;
        int printHelp = 0;
        
        double dt = 1.0/1024.0, Tend = 1.0;
        int max_iter = 1, use_refine = 0;
        
        int problemType = PD_PROBLEM_STEADYSTATE;
        
        const char * ofname = NULL;
        const char * meshin = NULL;
        const char * fmesh = NULL;
        
        if ( argc == 1 ){
                printHelp = 1;
        };
        
        int i = 1;
        while( (i < argc)&&(printHelp==0) ){ // sanity check for the input
                if ( !( (strcmp(argv[i],"-Nx") == 0)||(strcmp(argv[i],"-Ny") == 0)||(strcmp(argv[i],"-delta") == 0)||
			(strcmp(argv[i],"-dt") == 0)||(strcmp(argv[i],"-Tend") == 0)||(strcmp(argv[i],"-o") == 0)||
			(strcmp(argv[i],"-s") == 0)||(strcmp(argv[i],"-i") == 0)||(strcmp(argv[i],"-maxi") == 0)||
                        (strcmp(argv[i],"-mesh")==0)||(strcmp(argv[i],"-fmesh")==0)||(strcmp(argv[i],"-refine")==0)
				) ){
                        printHelp = 1;
                        i++;
                }else{
			if ( (strcmp(argv[i],"-s") == 0)||(strcmp(argv[i],"-i") == 0)||(strcmp(argv[i],"-refine") == 0) ){
				i++;
			}else{
				i+=2;
			};
                };
        };
        
        if ( printHelp == 1 ){
                printf(" Usage: \n      ./pdsolver -Nx 10 -Ny 10 -delta 0.2\n");
                printf(" Options:\n");
                printf("     --help          print this information\n");
                printf("     -s              steady state problem\n");
                printf("     -i              time integration problem\n");
                printf("     -Nx (integer)   specify number of cells in X direction\n");
                printf("     -Ny (integer)   specify number of cells in Y direction\n");
                printf("     -delta (double) specify peridynamics delta\n");
                printf("     -dt   (double)  specify time discretization parameter dt\n");
                printf("     -Tend (double)  specify end time\n");
                printf("      \n");
                printf("     -maxi (integer) specify the maximum number of refinement iterations\n");
                printf("     -refine         use iterative refinement for the steady state (need a metric)\n");
                printf("     -mesh (string)  specify a file with the first mesh to use\n");
                printf("     -fmesh (string)  (OUTPUT) filename for the final mesh\n");
                printf("     -o     (string)  (OUTPUT) filename for the final solution\n");
                return 0;
        };
        
        i = 1;
        while( i < argc ){
                if ( strcmp(argv[i],"-Nx") == 0 ){
                        Nx = atoi( argv[i+1] );
                        if ( Nx <= 0 ){
                                printf(" ERROR: Nx has to be positive.\n");
                                return 1;
                        };
                        i+=2;
                }else  if ( strcmp(argv[i],"-Ny") == 0 ){
                        Ny = atoi( argv[i+1] );
                        if ( Ny <= 0 ){
                                printf(" ERROR: Ny has to be positive.\n");
                                return 1;
                        };
                        i+=2;
                }else if ( strcmp(argv[i],"-delta") == 0 ){
                        PD_DELTA = atof( argv[i+1] );
                        if ( PD_DELTA <= 0 ){
                                printf(" ERROR: delta has to be positive.\n");
                                return 1;
                        };
                        i+=2;
                }else if ( strcmp(argv[i],"-dt") == 0 ){
                        dt = atof( argv[i+1] );
                        if ( dt <= 0 ){
                                printf(" ERROR: dt has to be positive.\n");
                                return 1;
                        };
                        i+=2;
                }else if ( strcmp(argv[i],"-Tend") == 0 ){
                        Tend = atof( argv[i+1] );
                        if ( Tend <= 0 ){
                                printf(" ERROR: Tend has to be positive.\n");
                                return 1;
                        };
                        i+=2;
                }else if ( strcmp(argv[i],"-maxi") == 0 ){
                        max_iter = atof( argv[i+1] );
                        if ( max_iter <= 0 ){
                                printf(" ERROR: the maximum number of iterations should be a positive number (1 means no refinement).\n");
                                return 1;
                        };
                        i+=2;
                }else if ( strcmp(argv[i],"-mesh") == 0 ){
                        meshin = argv[i+1];
                        i+=2;
                }else if ( strcmp(argv[i],"-o") == 0 ){
                        ofname = argv[i+1];
                        i+=2;
                }else if ( strcmp(argv[i],"-fmesh") == 0 ){
                        fmesh = argv[i+1];
                        i+=2;
                }else if ( strcmp(argv[i],"-s") == 0 ){
			problemType = PD_PROBLEM_STEADYSTATE;
			i++;
		}else if ( strcmp(argv[i],"-i") == 0 ){
			problemType = PD_PROBLEM_TIMEINTERATE;
			i++;
		}else if ( strcmp(argv[i],"-refine") == 0 ){
			use_refine = 1;
			i++;
		};
        };
        
        // Set Problem Type for Steady State
        PDProblemSetType( &P, problemType );
        
	// internal forces
        //PDProblemSetKernel( &P, &kernel_test_u, &kernel_test_v, PD_DELTA );
        PDProblemSetKernel( &P, &kernel_jump_u, &kernel_jump_v, PD_DELTA );
        
        // external forces
        //PDProblemSetExternal( &P, &b_force_symmetric_pull_u, &b_force_symmetric_pull_v );
        //PDProblemSetExternal( &P, &b_force_bottom_pull_u, &b_force_bottom_pull_v );
        PDProblemSetExternal( &P, &b_force_test_u, &b_force_test_v );
        
        // boundary conditions
        PDProblemSetBoundary( &P, &boundary_homogenious, &boundary_homogenious );
        
        // mesh discretization
	//PDProblemSetDomainDiscretizationParameters( &P, Nx, Ny, 0, 0, 0, 0, 0 );
	PDProblemSetDomainDiscretizationParameters( &P, Nx, Ny, boundary );
        PDProblemSetMeshInputFile( &P, meshin );
	
	// time integratino parameters
	PDProbleSetIntegrationParameters( &P, 0.0, Tend, dt );
	
	// set refinement parametrs
	PDProblemSetRefinement( &P, use_refine, refine_tolerance, max_iter );
	
	PDProblemShowInfo( &P );

// ------------------------------------------------ //
// ------------- BEGIN THE SOLUTION --------------- //
// ------------------------------------------------ //

	PDProblemInitialize( &P, 1 );
	
	PDProblemSolve( &P );
	
	//PDProblemTest( &P );
        
        if ( problemType == PD_PROBLEM_STEADYSTATE ){
                printf(" L-2 norm of the solution: %2.16f\n", PDProblemSolutionNormL2(&P ) );
        };
	
        if ( ofname != NULL ){
                PDProblemWriteSolution( &P, ofname );
        };
        
        if ( fmesh != NULL ){
		MeshWriteMesh( P.mesh, fmesh );
	};

        return 0;
};
