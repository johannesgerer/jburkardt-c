#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "smpack.h"

// for GMRES
struct UserData{
        struct SMPACKPmat *A;
};
void funcA( double *x, double *r, void* ud );

int main( int argc, char **argv ){

        int showHelp = 0;
        if ( (argc != 2) || ( !( (strcmp(argv[1],"-GMRES") == 0)||(strcmp(argv[1],"-PGMRES") == 0)||(strcmp(argv[1],"-CHOLS") == 0) ) ) ){
                showHelp = 1;
        };
        if ( showHelp == 1 ){
                printf(" This function tests the SMPACK module. \n");
                printf(" Usage: ./smpack_demo <option> \n");
                printf("   OPTIONS:\n");
                printf("      -GMRES: simple test on the GMRES module\n");
                printf("      -PGMRES: simple test on the GMRES module using MILU preconditioner\n");
                printf("      -CHOLS: simple test on the datastructures of the CHOLMOD module\n");
                return 0;
        };
        
        if (strcmp(argv[1],"-GMRES") == 0){ // test GMRES
                int i, N=10;
                struct SMPACKSpattern p;
                struct SMPACKPmat A;
                double *x = (double*) malloc( N*sizeof( double ) );
                double *b = (double*) malloc( N*sizeof( double ) );
                double sum;
                smpack_spattern_init( &p, 10 ); // get a 10 by 10 matrix
                for( i=0; i<N; i++ ){
                        if ( i>0 ){ smpack_spattern_add( &p, i, i-1 ); };
                        smpack_spattern_add( &p, i, i );
                        if ( i<N-1 ){ smpack_spattern_add( &p, i, i+1 ); };
                };
                
                smpack_pmat_create( &A, &p );
                smpack_spattern_del( &p );
                
                for( i=0; i<N; i++ ){
                        if ( i>0 ){ smpack_pmat_addval( &A, i, i-1, 1.0 ); };
                        smpack_pmat_addval( &A, i, i, -2.0 );
                        if ( i<N-1 ){ smpack_pmat_addval( &A, i, i+1, 1.0 ); };
                };
                
                for( i=0; i<N; i++ ){
                        x[i] = (double) i;
                };
                
                smpack_pmat_act( A, x, b, 1.0 );
                
                for( i=0; i<N; i++ ){
                        x[i] = 0.0;
                };
                
                smpack_GMRES_general( A, x, b, N, 10, 5, 1.E-9 );
                
                sum = 0.0;
                for( i=0; i<N; i++ ){
                        sum += ( x[i] - ((double)i) )*( x[i] - ((double)i) );
                };
                sum = sqrt( sum );
                printf(" Residual from a simple test: %e\n",sum );
        };
        
        if (strcmp(argv[1],"-PGMRES") == 0){ // test GMRES
                int i, N=10;
                struct SMPACKSpattern p;
                struct SMPACKPmat A;
                double *x = (double*) malloc( N*sizeof( double ) );
                double *b = (double*) malloc( N*sizeof( double ) );
                double sum;
                smpack_spattern_init( &p, 10 ); // get a 10 by 10 matrix
                for( i=0; i<N; i++ ){
                        if ( i>0 ){ smpack_spattern_add( &p, i, i-1 ); };
                        smpack_spattern_add( &p, i, i );
                        if ( i<N-1 ){ smpack_spattern_add( &p, i, i+1 ); };
                };
                
                smpack_pmat_create( &A, &p );
                smpack_spattern_del( &p );
                
                for( i=0; i<N; i++ ){
                        if ( i>0 ){ smpack_pmat_addval( &A, i, i-1, 1.0 ); };
                        smpack_pmat_addval( &A, i, i, -2.0 );
                        if ( i<N-1 ){ smpack_pmat_addval( &A, i, i+1, 1.0 ); };
                };
                
                for( i=0; i<N; i++ ){
                        x[i] = (double) i;
                };
                
                smpack_pmat_act( A, x, b, 1.0 );
                
                for( i=0; i<N; i++ ){
                        x[i] = 0.0;
                };
                
                smpack_GMRES_general_MILU( A, x, b, N, 2, 5, 1.E-9 );
                
                sum = 0.0;
                for( i=0; i<N; i++ ){
                        sum += ( x[i] - ((double)i) )*( x[i] - ((double)i) );
                };
                sum = sqrt( sum );
                printf(" Residual from a simple test: %e\n",sum );
        };
        
        if (strcmp(argv[1],"-CHOLS") == 0){ // test CHOLS
		int i, j, N=6;
                struct SMPACKSpattern p;
                struct SMPACKPmat A;
                double *x = (double*) malloc( N*sizeof( double ) );
                double *b = (double*) malloc( N*sizeof( double ) );
                double sum;
                smpack_spattern_init( &p, 6 );
                
                for( i=0; i<N; i++ ){
                        if ( i>0 ){ smpack_spattern_add( &p, i, i-1 ); };
                        smpack_spattern_add( &p, i, i );
                        if ( i<N-1 ){ smpack_spattern_add( &p, i, i+1 ); };
                };
                
                smpack_pmat_create( &A, &p );
                smpack_spattern_del( &p );
                
                for( i=0; i<N; i++ ){
                        if ( i>0 ){ smpack_pmat_addval( &A, i, i-1, -1.0 ); };
                        smpack_pmat_addval( &A, i, i, 2.0 );
                        if ( i<N-1 ){ smpack_pmat_addval( &A, i, i+1, -1.0 ); };
                };
                
                //for( i=0; i<A.pntr[N]; i++ ){
                //        printf(" A.vals[%d] = %f\n",i,A.vals[i]);
                //};
                
                struct SMPACKFactorizedCHOLMOD chol;
                chol.c.final_ll = (1==1);
                
                smpack_pmat_CHOLMOD_factorize_llt( A, &chol );
                
                int *pntr = (int*) chol.L->p;
                int *nz = (int*) chol.L->nz;
                int *indx = (int*) chol.L->i;
                double *vals = (double*) chol.L->x;
                
                for( i=0; i<N; i++ ){
                        printf(" L->p[i] = %d\n",pntr[i] );
                        for( j=pntr[i]; j<pntr[i]+nz[i]; j++ ){
                                printf(" %d ",indx[j]);
                        };
                        printf("\n");
                        for( j=pntr[i]; j<pntr[i]+nz[i]; j++ ){
                                printf(" %f ",vals[j]);
                        };
                        printf("\n");
                };
                printf(" ---- \n");
                
                //for( i=0; i<N; i++ ){
                //        x[i] = (double) i;
                //};
                
                //smpack_pmat_act( A, x, b, 1.0 );
                
                for( i=0; i<N; i++ ){
                        b[i] = 0.0;
                        x[i] = 0.0;
                };
                b[5] = 1.0;
                
                smpack_pmat_CHOLMOD_solve_l( &chol, b, x );
                
                for( i=0; i<N; i++ ){
                        printf(" %f \n",x[i]);
                };
                
                /* // This looks into the supernodal structure
                int nsuper = chol.L->nsuper;
                printf(" L->super: %d\n",nsuper);
                int *super = (int*) chol.L->super;
                if ( super == NULL ){
			printf(" NULL \n");
		};
                for( i=0; i<nsuper+1; i++ ){
			printf(" L->super[%d] = %d\n",i,super[i]);
		};*/
                
	};


        return 0;
};

void funcA( double *x, double *r, void* ud ){
        struct UserData *Matrix = (struct UserData*) ud;
        smpack_pmat_act( *(Matrix->A), x, r, 1.0 );
};
