/*
* This code is distrubuted under GPLv3
* 
* Code Author: Miroslav Stoyanov, Nov 2011
* 
* Copyright (C) 2011  Miroslav Stoyanov
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* Since the GNU General Public License is longer than this entire code, 
* a copy of it can be obtained separately at <http://www.gnu.org/licenses/>
*/

/*
 * This library creates a sparse matrix structure in row packed from struct SMPACKPmat.
 * There are functions and structures needed to generate a sparse pattern using dynamic memory (struct SMPACKSpattern)
 * There are several solvers available, iterative GMRES with MILU preconditioning as well as interface to
 * Tim Davis' SuiteSparse implementation of Umfpack and Cholmod.
 */

#ifndef __SMPACK_H__
#define __SMPACK_H__

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "acml.h"

// you can compile the library with -DSMPACK_NO_OPENMP to disable OpenMP
// if you define SMPACK_NO_OPENMP right before including this header you will force smpack to use only sequential functions (regardless of how it was compiled)
#ifndef SMPACK_NO_OPENMP
#define SMPACK_OPENMP
#endif

// you can compile the library with -DSMPACK_NO_SUITESPARSE to disable the SuteSparse interface (cannot call any of the Tim Davis' solvers withuot this interface)
// you can also define SMPACK_NO_SUITESPARSE right befor eincluding this header
#ifndef SMPACK_NO_SUITESPARSE
#define SMPACK_SUITESPARSE // for Umfpack and Cholmod
#endif

#ifdef SMPACK_OPENMP
	#include "omp.h"
#endif

struct SMPACK_spnode{ // a node for the sparse pattern
	int indx;
	struct SMPACK_spnode *next;
};

struct SMPACKSpattern{ // sparse pattern
	int num_rows;
	int *count;
	struct SMPACK_spnode **sp;
};

struct SMPACKPmat{ // sparse matrix structure (row packed)
	int num_rows;
	int *pntr; // pointers to the rows
	int *indx; // indexes of the rows
	double *vals; // associated values
};

struct SMPACKFactorizedMILU{
	int num_rows;
	int *pntr; // pointers to the rows
	int *indx; // indexes of the rows
	double *vals; // associated values
	int *indxD; // the diagonal entries
	int *indxT; // the corresponding transposed entrie
	int *pntrC; // pointers for the columns
	int *indxC; // indexes for the columns
};

#ifdef SMPACK_SUITESPARSE
#include "umfpack.h"
#include "cholmod.h"

struct SMPACKFactorizedUMFPACK{
    int num_rows;
    int *pntr;
    int *indx;
    double *vals;
    void * Numeric;
};

struct SMPACKFactorizedCHOLMOD{
	cholmod_sparse *S;
	cholmod_dense *x, *b;
	cholmod_factor *L;
	cholmod_common c;
	int size;
};
#endif


void smpack_spattern_init( struct SMPACKSpattern *p, int n ); // initialize a new pattern with n rows
void smpack_spattern_add( struct SMPACKSpattern *p, int r, int indx ); // add entrie to the pattern
void smpack_spattern_del( struct SMPACKSpattern *p ); // delete the pattern (release memory)

void smpack_pmat_create( struct SMPACKPmat *m, struct SMPACKSpattern *p ); // create a matrix with the pattern
void smpack_pmat_delete( struct SMPACKPmat *m ); // release all memory used by m
void smpack_pmat_addval( struct SMPACKPmat *m, int r, int c, double val ); // increment entrie at (r,c) by val
void smpack_pmat_repval( struct SMPACKPmat *m, int r, int c, double val ); // replace the entrie at (r,c) with val
// WARNING: if the the index isn't properly set, addval and repval enter into an infinite loop, use smpack_pmat_test_index if uncertain
int smpack_pmat_test_index( struct SMPACKPmat *m, int r, int c ); // returns 0 if the pattenrn contains r,c and 1 otherwise

#ifdef SMPACK_OPENMP
void smpack_pmat_scale( struct SMPACKPmat *m, double alpha ); // scale m by alpha
#else
#define smpack_pmat_scale smpack_pmat_scale_seq
#endif
void smpack_pmat_scale_seq( struct SMPACKPmat *m, double alpha );


void smpack_pmat_fwrite( FILE *ofs, struct SMPACKPmat m ); // writes m into the stream (binary format)
void smpack_pmat_fread( FILE *ofs, struct SMPACKPmat *m ); // read matrix form stream (init patterns and all, matrix shoud be empty)

void smpack_pmat_fwrite_ascii( struct SMPACKPmat m, const char *filename ); // writes m into an ascii file
void smpack_pmat_fread_ascii( struct SMPACKPmat *m, const char *filename ); // read matrix form an ascii faile


#ifdef SMPACK_OPENMP
void smpack_pmat_copy_pattern( struct SMPACKPmat m, struct SMPACKPmat *targ );
#else
#define smpack_pmat_copy_pattern smpack_pmat_copy_pattern_seq
#endif
void smpack_pmat_copy_pattern_seq( struct SMPACKPmat m, struct SMPACKPmat *targ );
// copy the pattern of m into targ
void smpack_pmat_copy_pattern_minor( struct SMPACKPmat m, struct SMPACKPmat *targ, int nun_rows, int nun_cols );
// copy the pattern for the first nr rows and nc columns of m into tagr
void smpack_pmat_copy_pattern_block( struct SMPACKPmat m, struct SMPACKPmat *targ, int start_row, int start_col, int end_row, int end_col );
// copy the block start_row:end_row to start_col:end_col into targ (start and end are included)


#ifdef SMPACK_OPENMP
void smpack_pmat_copy( struct SMPACKPmat m, struct SMPACKPmat *targ );
#else
#define smpack_pmat_copy smpack_pmat_copy_seq
#endif
void smpack_pmat_copy_seq( struct SMPACKPmat m, struct SMPACKPmat *targ );
// copy m to target


#ifdef SMPACK_OPENMP
void smpack_pmat_add( struct SMPACKPmat m, struct SMPACKPmat *targ, double alpha );
#else
#define smpack_pmat_add smpack_pmat_add_seq
#endif
void smpack_pmat_add_seq( struct SMPACKPmat m, struct SMPACKPmat *targ, double alpha );
// add alpha*m to target (i.e target += m*alpha)


#ifdef SMPACK_OPENMP
void smpack_pmat_act( struct SMPACKPmat m, double *x, double *r, double alpha );
#else
#define smpack_pmat_act smpack_pmat_act_seq
#endif
// returns r = alpha * m * x + beta * r // default should be alpha = 1.0, beta = 0.0
void smpack_pmat_act_seq( struct SMPACKPmat m, double *x, double *r, double alpha );
void smpack_pmat_act_select( struct SMPACKPmat m, double *x, double *r, int start, int end, double alpha );
// select is to be called from within OpenMP block (avoids respawning treads)
// it performs the action from rows start to end

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//---------------- SOLVERS ----------------------------------------------------------------------------//
/////////////////////////////////////////////////////////////////////////////////////////////////////////

void smpack_pmat_MILU_analyze( struct SMPACKPmat m, struct SMPACKFactorizedMILU *ilu );
void smpack_pmat_MILU_factorize( struct SMPACKPmat m, struct SMPACKFactorizedMILU *ilu );
void smpack_pmat_MILU_solve( struct SMPACKFactorizedMILU *ilu, double *x );
void smpack_pmat_MILU_free( struct SMPACKFactorizedMILU *ilu );
// analyze, factorize, solve and delete for the MILU factroization

int smpack_GMRES( void (*funcA)(double*,double*,void*), double *x, double *b, void *ud, int size, int max_inner, int max_outer, double tol );
// solves Ax=b, i.e. funcA( x, r, ud ) -> r == b
// x contains the initial guess
// size is the problem size, max_inner and max_outer are the maximum number of inner and outer iterations
// tol is the desired tolerance
// the method returns 0 if convergence is reached and 1 if the final error exceeds tol
int smpack_GMRES_general( struct SMPACKPmat A, double *x, double *b, int size, int max_inner, int max_outer, double tol );
// solves Ax = b using GMRES, however, there is no preconditioning so this will probably have hard time converging
int smpack_GMRES_general_MILU( struct SMPACKPmat A, double *x, double *b, int size, int max_inner, int max_outer, double tol );
// solves Ax = b using GMRES, using MILU preconditioner


#ifdef SMPACK_SUITESPARSE
// the UMFPACK solver is for sparse matrix with any generic structure
void smpack_pmat_UMFPACK_factorize( struct SMPACKPmat m, struct SMPACKFactorizedUMFPACK *umf );
void smpack_pmat_UMFPACK_solve( struct SMPACKFactorizedUMFPACK umf, double *b, double *x );
void smpack_pmat_UMFPACK_solve_transposed( struct SMPACKFactorizedUMFPACK umf, double *b, double *x );
void smpack_pmat_UMFPACK_free( struct SMPACKFactorizedUMFPACK *umf );

void smpack_pmat_general_solve( struct SMPACKPmat m, double *b, double *x );

// Cholmod solver is specifically tuned for symmetric definite matrices (L*D*L')
void smpack_pmat_CHOLMOD_factorize( struct SMPACKPmat m, struct SMPACKFactorizedCHOLMOD *chol );
void smpack_pmat_CHOLMOD_factorize_llt( struct SMPACKPmat m, struct SMPACKFactorizedCHOLMOD *chol ); // same as factorize, but uses L*L' factorization and can only be applied to SPD matrices
void smpack_pmat_CHOLMOD_solve( struct SMPACKFactorizedCHOLMOD *chol, double *b, double *x );
void smpack_pmat_CHOLMOD_solve_l( struct SMPACKFactorizedCHOLMOD *chol, double *b, double *x ); // only solves Lx = b
void smpack_pmat_CHOLMOD_free( struct SMPACKFactorizedCHOLMOD *chol );


#endif


#ifdef SMPACK_OPENMP

// some macros to use with OpenMP
// to read me and nthreads and split them
#define _SMPACK_OMP_READ_SPLIT( me, nthreads, N, start, end, length ) \
	(me) = omp_get_thread_num(); \
	(nthreads) = omp_get_num_threads(); \
	(start) = (me) * (N) / (nthreads); \
	(end) = (me+1) * (N) / (nthreads) - 1; \
	(length) = (end) - (start) + 1; 

// to just split if me and nthreads have been read
#define _SMPACK_OMP_SPLIT( me, nthreads, N, start, end, length ) \
	(start) = (me) * (N) / (nthreads); \
	(end) = (me+1) * (N) / (nthreads) - 1; \
	(length) = (end) - (start) + 1; 

#endif


#endif

//////////////////////////////////////////////////////////////////////////////////////////
// -------------- MATLAB CODE TO LOAD THE BINARY MATRIX --------------------------------//
//////////////////////////////////////////////////////////////////////////////////////////
/*fid = fopen( filename, 'r' );

%----------------------------------------------------------------
%                load A
%----------------------------------------------------------------
sz = fread( fid, 1, 'int32' );
vl = fread( fid, 1, 'int32' );

disp(['  Matrix size: ',num2str(sz),'   ',num2str(vl)]);

[ pntr ] = fread( fid, sz+1, 'int32' );
vl = pntr(sz+1);
disp(['  Number of non-zeros: ',num2str(vl)]);
[ indx ] = fread( fid, vl, 'int32' );
[ vals ] = fread( fid, vl, 'double' );

indx = indx + 1;

spntr = zeros( vl, 1 );
for i = 1:sz
    spntr( pntr( i )+1:pntr( i+1 ), 1 ) = i*ones( pntr( i+1, 1 ) - pntr( i ), 1 );
end;
A = sparse( spntr, indx, vals, sz, sz, vl );

fclose( fid );*/
//////////////////////////////////////////////////////////////////////////////////////////
