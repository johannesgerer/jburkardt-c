/*
* This code isdistrubuted under GPLv3
* 
* Code Author: Miroslav Stoyanov, Nov 2011
* 
* Copyright (C) 2011  Miroslav Stoyanov
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* Since the GNU General Public License is longer than this entire code, 
* a copy of it can be obtained separately at <http://www.gnu.org/licenses/>
*/

#ifndef __SMPACK_CPP__
#define __SMPACK_CPP__

#include "smpack.h"

void smpack_spattern_init( struct SMPACKSpattern *p, int n ){
	int i;
	p->sp = (struct SMPACK_spnode**) malloc( n * sizeof( struct SMPACK_spnode* ) );
	p->count = (int*) malloc( n * sizeof(int) );
	p->num_rows = n;
	for( i=0; i<n; i++ ){ p->count[i] = 0; p->sp[i] = NULL; };
};

void smpack_spattern_add( struct SMPACKSpattern *p, int r, int indx ){
	if ( p->count[r] == 0 ){ // add as the first entry
		p->sp[r] = (struct SMPACK_spnode*) malloc( sizeof(struct SMPACK_spnode) );
		p->sp[r] -> next = NULL;
		p->sp[r] -> indx = indx;
		p->count[r]++;
	}else if ( p->sp[r] -> indx > indx ){ // add before the first entry
		struct SMPACK_spnode *t = (struct SMPACK_spnode*) malloc( sizeof(struct SMPACK_spnode) );
		t -> indx = indx;
		t -> next = p->sp[r];
		p->sp[r] = t;
		p->count[r]++;
	}else if ( p->sp[r] -> indx == indx ){ // do nothing (entrie is repeating)
	}else if ( p->count[r] == 1 ){ // only one node, add after the node
		p->sp[r] -> next = (struct SMPACK_spnode*) malloc( sizeof(struct SMPACK_spnode) );
		p->sp[r] -> next -> indx = indx;
		p->sp[r] -> next -> next = NULL;
		p->count[r]++;
	}else{ // we have at least two nodes, then we can loop looking one node ahead
		struct SMPACK_spnode *t = p->sp[r];
		int loop = 1;
		while ( loop == 1 ){
			if ( t -> next -> indx == indx ){ // entrie already here
				loop = 0;
			}else if ( t -> next -> indx > indx ){ // add here
				struct SMPACK_spnode *d = (struct SMPACK_spnode*) malloc( sizeof(struct SMPACK_spnode) );
				d -> next = t -> next;
				t -> next = d;
				d -> indx = indx;
				p->count[r]++;
				loop = 0;
			}else if ( t -> next -> next == NULL ){ // if next entrie is still smaller than the index
				t = t -> next;
				t -> next = (struct SMPACK_spnode*) malloc( sizeof(struct SMPACK_spnode) );
				t = t -> next;
				t -> next = NULL;
				t -> indx = indx;
				p->count[r]++;
				loop = 0;
			}else{ // go on
				t = t -> next;
			};
		};
	};
};

void smpack_spattern_del( struct SMPACKSpattern *p ){
	int i;
	struct SMPACK_spnode *t;
	for ( i=0; i<p->num_rows; i++ ){
		t = p->sp[i];
		while ( p->sp[i] != NULL ){
			p->sp[i] = p->sp[i] -> next;
			free( t );
			t = p->sp[i];
		};
	};
	free( p->sp );
	free( p->count );
	p->num_rows = 0;
};

void smpack_pmat_create( struct SMPACKPmat *m, struct SMPACKSpattern *p ){
	int i, j, count = 0;

	// set the constants
	m->num_rows = p->num_rows;

	// count number of entries
	for( i=0; i<p->num_rows; i++ ){
		count += p->count[i];
	};

	// declare the memory needed
	m -> pntr = (int*) malloc( (m->num_rows + 1) * sizeof(int) );
	m -> indx = (int*) malloc( count * sizeof(int) );
	m -> vals = (double*) malloc( count * sizeof(double) );

	// set the pointers
	m->pntr[0] = 0;
	for( i=1; i<m->num_rows; i++ ){
		m->pntr[i] = m->pntr[i-1] + p->count[i-1];
	};
	m->pntr[m->num_rows] = count;

	// copy the indexes
	struct SMPACK_spnode * t;
	for( i=0; i<m->num_rows; i++ ){
		t = p->sp[i];
		for( j=m->pntr[i]; j<m->pntr[i+1]; j++ ){
			m->indx[j] = t -> indx;
			t = t -> next;
		};
	};

	//dscal( count, 0.0, m->vals, 1 ); // this is buggy sometimes
        for( i=0; i<count; i++ ){ m->vals[i] = 0.0; };
};

void smpack_pmat_delete( struct SMPACKPmat *m ){
	free( m->pntr ); m->pntr = NULL;
	free( m->indx ); m->indx = NULL;
	free( m->vals ); m->vals = NULL;
	m->num_rows = 0.0;
};

void smpack_pmat_addval( struct SMPACKPmat *m, int r, int c, double val ){
	int start = m->pntr[r];
	int end = m->pntr[r+1];
	int i = (start+end)/2;
	while ( m->indx[i] != c ){
		if ( m->indx[i] < c ){
			start = i + 1;
		}else{
			end = i - 1;
		};
		i = (start+end)/2;
	};
	m->vals[i] += val;
};

void smpack_pmat_repval( struct SMPACKPmat *m, int r, int c, double val ){
	int start = m->pntr[r];
	int end = m->pntr[r+1];
	int i = (start+end)/2;
	while ( m->indx[i] != c ){
		if ( m->indx[i] < c ){
			start = i + 1;
		}else{
			end = i - 1;
		};
		i = (start+end)/2;
	};
	m->vals[i] += val;
};

int smpack_pmat_test_index( struct SMPACKPmat *m, int r, int c ){
        if ( (r<0) || (r>m->num_rows) ){ return 1; }; // the row is out of range
        int i;
        for( i=m->pntr[r]; i<m->pntr[r+1]; i++ ){
                if ( m->indx[i] == c ){ return 0; }; // found the entry
        };
        return 1; // looped over the row and the entry is missing
};

#ifdef SMPACK_OPENMP
void smpack_pmat_scale( struct SMPACKPmat *m, double alpha ){ // scale m by alpha
	int start, end, length, me, nthreads;
        if ( alpha == 0.0 ){ // handle an ACML bug, we have to work with this case separately
                int i;
                #pragma omp parallel private(start,end,me,nthreads,i)
                {
                        _SMPACK_OMP_READ_SPLIT( me, nthreads, m->pntr[m->num_rows], start, end, length );
                        for( i=start; i<=end; i++ ){
                                m->vals[i] = 0.0;
                        };
                };
        }else{
                #pragma omp parallel private(start,end,me,nthreads)
                {
                        _SMPACK_OMP_READ_SPLIT( me, nthreads, m->pntr[m->num_rows], start, end, length );
                        dscal( length, alpha, &(m->vals[start]), 1 );
                };
        };
};
#endif

void smpack_pmat_scale_seq( struct SMPACKPmat *m, double alpha ){
        if ( alpha == 0.0 ){ // there is a bug with ACML and we have handle this case separately
                int i;
                for( i=0; i<m->pntr[m->num_rows]; i++ ){
                        m->vals[i] = 0.0;
                };
        }else{
                dscal( m->pntr[m->num_rows], alpha, m->vals, 1 );
        };
};

void smpack_pmat_fwrite( FILE *ofs, struct SMPACKPmat m ){
        int written;
	written = fwrite( &(m.num_rows), 1, sizeof(int), ofs );
	
	written = fwrite( m.pntr, (m.num_rows + 1), sizeof( int ), ofs );
	written = fwrite( m.indx, m.pntr[m.num_rows], sizeof( int ), ofs );
	written = fwrite( m.vals, m.pntr[m.num_rows], sizeof( double ), ofs );
};

void smpack_pmat_fread( FILE *ifs, struct SMPACKPmat *m ){
        int read;
	read = fread( &(m->num_rows), 1, sizeof(int), ifs );
	
	m->pntr = (int*) malloc( (m->num_rows)*sizeof(int) );
	read = fread( m->pntr, m->num_rows+1, sizeof(int), ifs );

	m->indx = (int*) malloc( m->pntr[m->num_rows] * sizeof(int) );
	m->vals = (double*) malloc( m->pntr[m->num_rows] * sizeof(double) );
	read = fread( m->indx, m->pntr[m->num_rows], sizeof(int), ifs );
	read = fread( m->vals, m->pntr[m->num_rows], sizeof(double), ifs );
};

void smpack_pmat_fwrite_ascii( struct SMPACKPmat m, const char *filename ){ // writes m into an ascii file
        int i;
        FILE * fout = fopen( filename, "w");
        fprintf(fout,"%d \n",m.num_rows);
        for( i=0; i<m.num_rows+1; i++ ){
                fprintf(fout,"%d\n",m.pntr[i]);
        };
        for( i=0; i<m.pntr[m.num_rows]; i++ ){
                fprintf(fout,"%d\n",m.indx[i]);
        };
        for( i=0; i<m.pntr[m.num_rows]; i++ ){
                fprintf(fout,"%2.16lf\n",m.vals[i]);
        };
        fclose( fout );
};

void smpack_pmat_fread_ascii( struct SMPACKPmat *m, const char *filename ){ // read matrix form an ascii faile
        int i, r;
        FILE * fout = fopen( filename, "r");
        r = fscanf(fout,"%d\n",&(m->num_rows));
        m->pntr = (int*) malloc( (m->num_rows+1) * sizeof( int ) );
        for( i=0; i<m->num_rows+1; i++ ){
                r = fscanf(fout,"%d\n",&(m->pntr[i]));
        };
        m->indx = (int*) malloc( (m->pntr[m->num_rows]) * sizeof( int ) );
        m->vals = (double*) malloc( (m->pntr[m->num_rows]) * sizeof( double ) );
        for( i=0; i<m->pntr[m->num_rows]; i++ ){
                r = fscanf(fout,"%d\n",&(m->indx[i]));
        };
        for( i=0; i<m->pntr[m->num_rows]; i++ ){
                r = fscanf(fout,"%lf\n",&(m->vals[i]));
        };
        fclose( fout );
};

#ifdef SMPACK_OPENMP
void smpack_pmat_copy_pattern( struct SMPACKPmat m, struct SMPACKPmat *targ ){
	int i, start, end, length, me, nthreads;
        targ->num_rows = m.num_rows;
        targ->pntr = (int*) malloc( (targ->num_rows+1) * sizeof(int) );
        targ->indx = (int*) malloc( (m.pntr[m.num_rows]) *sizeof(int) );
        targ->vals = (double*) malloc( (m.pntr[m.num_rows]) *sizeof(double) );
        
        #pragma omp parallel private(start,end,me,nthreads,i)
        {
                _SMPACK_OMP_READ_SPLIT( me, nthreads, m.num_rows+1, start, end, length );
                for( i=start; i<=end; i++ ){
                        targ->pntr[i] = m.pntr[i];
                };
                _SMPACK_OMP_SPLIT( me, nthreads, m.pntr[m.num_rows], start, end, length );
                for( i=start; i<=end; i++ ){
                        targ->indx[i] = m.indx[i];
                };
                
        };
};
#endif

void smpack_pmat_copy_pattern_seq( struct SMPACKPmat m, struct SMPACKPmat *targ ){
        int i;
        targ->num_rows = m.num_rows;
        targ->pntr = (int*) malloc( (targ->num_rows+1) * sizeof(int) );
        for( i=0; i<=targ->num_rows; i++ ){ targ->pntr[i] = m.pntr[i]; };
        targ->indx = (int*) malloc( (targ->pntr[targ->num_rows]) *sizeof(int) );
        targ->vals = (double*) malloc( (targ->pntr[targ->num_rows]) *sizeof(double) );
        for( i=0; i<targ->pntr[targ->num_rows]; i++ ){ targ->indx[i] = m.indx[i]; };
};

void smpack_pmat_copy_pattern_minor( struct SMPACKPmat m, struct SMPACKPmat *targ, int nun_rows, int nun_cols ){
        int i, j, k, count =0;
        for( i=0; i < nun_rows; i++ ){
                for( j=m.pntr[i]; (j<m.pntr[i+1])&&(m.indx[j] < nun_cols); j++ ){
                        count++;
                };
        };
        targ->num_rows = nun_rows;
        targ->pntr = (int*) malloc( (targ->num_rows + 1)*sizeof(int) );
        targ->pntr[targ->num_rows] = count;
        targ->indx = (int*) malloc( targ->pntr[targ->num_rows] * sizeof(int) );
        targ->vals = (double*) malloc( targ->pntr[targ->num_rows] * sizeof(double) );
        k = 0;
        for( i=0; i < nun_rows; i++ ){
                targ->pntr[i] = k;
                for( j=m.pntr[i]; (j<m.pntr[i+1])&&(m.indx[j] < nun_cols); j++ ){
                        targ->indx[k] = m.indx[j];
                        k++;
                };
        };
};

void smpack_pmat_copy_pattern_block( struct SMPACKPmat m, struct SMPACKPmat *targ, int start_row, int start_col, int end_row, int end_col ){
        int i, j, k, count =0;
        for( i=start_row; i < end_row; i++ ){
                for( j=m.pntr[i]; (j<m.pntr[i+1])&&(m.indx[j] < end_col); j++ ){
                        if ( m.indx[j] >= start_col ) count++;
                };
        };
        targ->num_rows = end_row - start_row;
        targ->pntr = (int*) malloc( (targ->num_rows + 1) * sizeof(int) );
        targ->pntr[targ->num_rows] = count;
        targ->indx = (int*) malloc( targ->pntr[targ->num_rows] * sizeof(int) );
        targ->vals = (double*) malloc( targ->pntr[targ->num_rows] * sizeof(double) );
        k = 0;
        for( i=start_row; i < end_row; i++ ){
                targ->pntr[i-start_row] = k;
                for( j=m.pntr[i]; (j<m.pntr[i+1])&&(m.indx[j] < end_col); j++ ){
                        if ( m.indx[j] >= start_col ){
                                targ->indx[k] = m.indx[j]-start_col;
                                k++;
                        };
                };
        };
};

#ifdef SMPACK_OPENMP
void smpack_pmat_copy( struct SMPACKPmat m, struct SMPACKPmat *targ ){
        int me, nthreads, start, end, length;
        #pragma omp parallel private(me, nthreads, start, end, length)
        {
                _SMPACK_OMP_READ_SPLIT(me,nthreads,m.pntr[m.num_rows],start,end,length);
                dcopy( length, &(m.vals[start]), 1, &(targ->vals[start]), 1 );
        };
};
#endif

void smpack_pmat_copy_seq( struct SMPACKPmat m, struct SMPACKPmat *targ ){
        dcopy( m.pntr[m.num_rows], m.vals, 1, targ->vals, 1 );
};


#ifdef SMPACK_OPENMP
void smpack_pmat_add( struct SMPACKPmat m, struct SMPACKPmat *targ, double alpha ){
        int me, nthreads, start, end, length;
        #pragma omp parallel private(me, nthreads, start, end, length)
        {
                _SMPACK_OMP_READ_SPLIT(me,nthreads,m.pntr[m.num_rows],start,end,length);
                daxpy( length, alpha, &(m.vals[start]), 1, &(targ->vals[start]), 1 );
        };
};
#endif

void smpack_pmat_add_seq( struct SMPACKPmat m, struct SMPACKPmat *targ, double alpha ){
        daxpy( m.num_rows, alpha, m.vals, 1, targ->vals, 1 );
};


#ifdef SMPACK_OPENMP
void smpack_pmat_act( struct SMPACKPmat m, double *x, double *r, double alpha ){
	int me, nthreads, start, end, length, i;
        #pragma omp parallel private(me, nthreads, start, end, length, i)
        {
                _SMPACK_OMP_READ_SPLIT( me, nthreads, m.num_rows, start, end, length )
                for( i=start; i <= end; i++ ){
                        r[i] = alpha * ddoti( m.pntr[i+1] - m.pntr[i], &(m.vals[m.pntr[i]]), &(m.indx[m.pntr[i]]), &x[1] );
                };
        };
};
#endif

void smpack_pmat_act_seq( struct SMPACKPmat m, double *x, double *r, double alpha ){
	int i;
        for( i=0; i < m.num_rows; i++ ){
                r[i] = alpha * ddoti( m.pntr[i+1] - m.pntr[i], &(m.vals[m.pntr[i]]), &(m.indx[m.pntr[i]]), &x[1] );
        };
};

void smpack_pmat_act_select( struct SMPACKPmat m, double *x, double *r, int start, int end, double alpha ){
	int i;
        for( i=start; i <= end; i++ ){
                r[i] = alpha * ddoti( m.pntr[i+1] - m.pntr[i], &(m.vals[m.pntr[i]]), &(m.indx[m.pntr[i]]), &x[1] );
        };
};


void smpack_pmat_MILU_analyze( struct SMPACKPmat m, struct SMPACKFactorizedMILU *ilu ){
	int i, j, k;
	ilu->num_rows = m.num_rows;
	ilu->pntr = (int*) malloc( (ilu->num_rows+1) * sizeof(int) );
	ilu->pntrC = (int*) malloc( (ilu->num_rows+1) * sizeof(int) );
	ilu->indxD = (int*) malloc( ilu->num_rows * sizeof(int) );
	for( i=0; i <= ilu->num_rows; i++ ){
		ilu->pntr[i] = m.pntr[i];
	};
	ilu->pntrC[ilu->num_rows] = ilu->pntr[ilu->num_rows];
	ilu->indxT = (int*) malloc( ilu->pntr[ilu->num_rows] * sizeof(int) );
	ilu->indx = (int*) malloc( ilu->pntr[ilu->num_rows] * sizeof(int) );
	ilu->indxC = (int*) malloc( ilu->pntr[ilu->num_rows] * sizeof(int) );
	ilu->vals = (double*) malloc( ilu->pntr[ilu->num_rows] * sizeof(double) );
	for( i=0; i < ilu->pntr[ilu->num_rows]; i++ ){
		ilu->indx[i] = m.indx[i];
	};

	// get the diagonal entrie for each row
	for( i=0; i<ilu->num_rows; i++ ){
		j = ilu->pntr[i];
		while( (j<ilu->pntr[i+1])&&(ilu->indx[j]<i) ){ j++; }
		if ( ilu->indx[j] == i ){ ilu->indxD[i] = j; };
	};

	for( i=0; i<ilu->num_rows; i++ ){
		ilu->pntrC[i] = 0;
	};
	for( j=0; j<ilu->pntr[ilu->num_rows]; j++ ){
		ilu->pntrC[ ilu->indx[j] + 1 ]++;
	};
	for( i=1; i<=ilu->num_rows; i++ ){
		ilu->pntrC[i] += ilu->pntrC[i-1];
	};

	int *cnt = (int*) malloc( ilu->num_rows * sizeof(int) );
	for( i=0; i<ilu->num_rows; i++ ){
		cnt[i] = 0;
	};

	for( i=0; i<ilu->num_rows; i++ ){
		for( j=ilu->pntr[i]; j<ilu->pntr[i+1]; j++ ){
			ilu->indxC[ ilu->pntrC[ ilu->indx[j] ] + cnt[ ilu->indx[j] ] ] = i;
			ilu->indxT[ ilu->pntrC[ ilu->indx[j] ] + cnt[ ilu->indx[j] ] ] = j;
			cnt[ ilu->indx[j] ] ++;
		};
	};

	free( cnt );
};

void smpack_pmat_MILU_factorize( struct SMPACKPmat m, struct SMPACKFactorizedMILU *ilu ){
	int N, i, j, jr, jt, k, ii, jj;
	int start, end, current;
	int found;
	double d, e;
	
	N = m.num_rows;

	dcopy( m.pntr[N], m.vals, 1, ilu->vals, 1 );

	for( i=0; i<N-1; i++ ){
		d = 1.0 / ilu->vals[ ilu->indxD[i] ];
		for( j=ilu->indxD[i]+1; j<ilu->pntrC[i+1]; j++ ){
			jr = ilu->indxC[j];
			jt = ilu->indxT[j];
			e = d* ilu->vals[jt];
			ilu->vals[jt] = e;
			for( k=ilu->indxD[i]+1; k < ilu->pntr[i+1]; k++ ){
				start = ilu->pntr[jr];
				end = ilu->pntr[jr+1] - 1;
				current = (start+end) / 2;
				while( (start<end) && (ilu->indx[current] != ilu->indx[k]) ){
					if ( ilu->indx[current] < ilu->indx[k] ){
						start = current + 1;
					}else{
						end = current - 1;
					};
					current = (start+end)/2;
				};
				if ( ilu->indx[current] == ilu->indx[k] ){
					ilu->vals[current] -= e * ilu->vals[k];
				}else{
					ilu->vals[ilu->indxD[jr]] -= e * ilu->vals[k];
				};
			};
		};
	};
};

void smpack_pmat_MILU_solve( struct SMPACKFactorizedMILU *ilu, double *x ){
	int i;
	for( i=1; i < ilu->num_rows; i++ ){
		if ( (ilu->indxD[i] - ilu->pntr[i]) > 0 )
			x[i] -= ddoti( (ilu->indxD[i] - ilu->pntr[i]), &(ilu->vals[ilu->pntr[i]]), &(ilu->indx[ilu->pntr[i]]), &x[1] );
	};
	for( i=ilu->num_rows-1; i>=0; i-- ){
		if ( (ilu->pntr[i+1] - ilu->indxD[i] - 1) > 0 ){
			x[i] -= ddoti( (ilu->pntr[i+1] - ilu->indxD[i] - 1), &(ilu->vals[ilu->indxD[i]+1]), &(ilu->indx[ilu->indxD[i]+1]), &x[1] );
		};
		x[i] /= ilu->vals[ilu->indxD[i]];
	};
};

void smpack_pmat_MILU_free( struct SMPACKFactorizedMILU *ilu ){
	free( ilu->pntr );
	free( ilu->indx );
	free( ilu->vals );
	free( ilu->indxC );
	free( ilu->indxD );
	free( ilu->indxT );
};

int smpack_GMRES( void (*funcA)(double*,double*,void*), double *x, double *b, void *ud, int size, int max_inner, int max_outer, double tol ){
        if ( max_inner < 2 ){ max_inner = 2; }; // it makes no sense to stop before 2 iterations (unless we have converged)
        double H[max_inner][max_inner+1]; // holds the transformation for the normalized basis
        double W[max_inner+1][size]; // work space for the vector basis
        double R[size]; // residual vector
        double S[max_inner], C[max_inner+1]; // sin and cos of the Givens rotations
        double Z[max_inner]; // holds the coefficients of the solution
        
        double alpha, h_k; // temp variables
        
        int i, j; // loop variables i, j and k is the size of the computed basis
        
        double outer_res = tol + 1.0, inner_res; // outer and inner residual
        int outer_itr = 0, inner_itr; // counts the inner and outer iterations
        
        while ( (outer_res > tol ) && ( outer_itr < max_outer ) ){
                
                funcA( x, W[1], ud ); // call the funtion to compute W_1 = A x
                
                dcopy( size, b, 1, W[0], 1 );
                daxpy( size, -1.0, W[1], 1, W[0], 1 ); // W_0 = b - Ax
                
                Z[0] = dnrm2( size, W[0], 1 );
                dscal( size, 1.0/Z[0], W[0], 1 ); // save the first normalized vector
                
                inner_res = Z[0]; // first residual
                inner_itr = 0; // counts the size of the basis
                
                while ( (inner_res > tol) && (inner_itr < max_inner) ){
                        inner_itr++;
                        
                        funcA( W[inner_itr-1], W[inner_itr], ud );
                        
                        for( i=0; i<inner_itr; i++ ){ // normalize the vector with respect to the previous vectors
                                H[inner_itr-1][i] = ddot( size, W[inner_itr], 1, W[i], 1 );
                                daxpy( size, -H[inner_itr-1][i], W[i], 1, W[inner_itr], 1 );
                        };
                        
                        h_k = dnrm2( size, W[inner_itr], 1 ); // set the next basis vector
                        dscal( size, 1.0/h_k, W[inner_itr], 1 );
                        
                        for ( i=0; i<inner_itr-1; i++ ){ // form the next row of the transformation
                                alpha = H[inner_itr-1][i];
                                H[inner_itr-1][i]   = C[i] * alpha + S[i] * H[inner_itr-1][i+1];
                                H[inner_itr-1][i+1] = S[i] * alpha - C[i] * H[inner_itr-1][i+1];
                        };
                        
                        alpha = sqrt( h_k * h_k  +  H[inner_itr-1][inner_itr-1] * H[inner_itr-1][inner_itr-1] );
                        
                        // set the next set og Givens rotations
                        S[inner_itr-1] = h_k / alpha;	        
                        C[inner_itr-1] = H[inner_itr-1][inner_itr-1] / alpha;
			
                        H[inner_itr-1][inner_itr-1] = alpha;
                        
                        // Z is used to reconstruct the solution in the end
                        Z[inner_itr] = S[inner_itr-1]*Z[inner_itr-1];
			Z[inner_itr-1] = C[inner_itr-1]*Z[inner_itr-1]; // apply it on z
                        
                        inner_res = fabs(Z[inner_itr]);
                };
                
                inner_itr--;
                
                if ( inner_itr > -1 ){ // if the first guess was not within TOL of the true solution
			Z[inner_itr] /= H[inner_itr][inner_itr];
			for( i=inner_itr-1; i>-1; i-- ){
				h_k = 0.0;
				for( j=i+1; j<=inner_itr; j++ ){
					h_k += H[j][i] * Z[j];
				};
				Z[i] = ( Z[i] - h_k ) / H[i][i];
			};

			for( i=0; i<=inner_itr; i++ ){
				daxpy( size, Z[i], W[i], 1, x, 1 );
			};
		};
                
                outer_res = inner_res;
                outer_itr++;
        };
        
        return (outer_res > tol) ? 1 : 0;
};

int smpack_GMRES_general( struct SMPACKPmat A, double *x, double *b, int size, int max_inner, int max_outer, double tol ){
	struct SmpackUserData{
		struct SMPACKPmat *A;
	};
	void funcA( double *x, double *r, void* ud ){
		struct SmpackUserData *Matrix = (struct SmpackUserData*) ud;
		smpack_pmat_act( *(Matrix->A), x, r, 1.0 );
	};
	struct SmpackUserData UD;
	UD.A = &A;
	smpack_GMRES( &funcA, x, b, &UD, size, max_inner, max_outer, tol );
};

int smpack_GMRES_general_MILU( struct SMPACKPmat A, double *x, double *b, int size, int max_inner, int max_outer, double tol ){
	struct SmpackUserData{
		struct SMPACKPmat *A;
		struct SMPACKFactorizedMILU iLU;
	};
	void funcA( double *x, double *r, void* ud ){
		struct SmpackUserData *Matrix = (struct SmpackUserData*) ud;
		smpack_pmat_act( *(Matrix->A), x, r, 1.0 );
		smpack_pmat_MILU_solve( &(Matrix->iLU), r );
	};
	struct SmpackUserData UD;
	double Pb[size];
	UD.A = &A;
	smpack_pmat_MILU_analyze( A, &(UD.iLU) );
	smpack_pmat_MILU_factorize( A, &(UD.iLU) );
	
	dcopy( size, b, 1, Pb, 1 );
	smpack_pmat_MILU_solve( &(UD.iLU), Pb );
	
	smpack_GMRES( &funcA, x, Pb, &UD, size, max_inner, max_outer, tol );
	smpack_pmat_MILU_free( &(UD.iLU) );
};

#ifdef SMPACK_SUITESPARSE
void smpack_pmat_UMFPACK_factorize( struct SMPACKPmat m, struct SMPACKFactorizedUMFPACK *umf ){
	int i;
	umf->num_rows = m.num_rows;
	umf->pntr = (int*) malloc( ((umf->num_rows+1) + (umf->num_rows+1) % 2) * sizeof(int) );
	for( i=0; i<=umf->num_rows; i++ ){
		umf->pntr[i] = m.pntr[i];
	};
	umf->indx = (int*) malloc( (umf->pntr[umf->num_rows] + umf->pntr[umf->num_rows]%2) * sizeof(int) );
	umf->vals = (double*) malloc( umf->pntr[umf->num_rows] * sizeof(double) );
	for( i=0; i<umf->pntr[umf->num_rows]; i++ ){
		umf->indx[i] = m.indx[i];
	};
	dcopy( umf->pntr[umf->num_rows], m.vals, 1, umf->vals, 1 );

	void *Symbolic;
	umfpack_di_symbolic( umf->num_rows, umf->num_rows, umf->pntr, umf->indx, umf->vals, &Symbolic, NULL, NULL);
	umfpack_di_numeric( umf->pntr, umf->indx, umf->vals, Symbolic, &(umf->Numeric), NULL, NULL);
	umfpack_di_free_symbolic(&Symbolic);
};

void smpack_pmat_UMFPACK_solve( struct SMPACKFactorizedUMFPACK umf, double *b, double *x ){
	umfpack_di_solve(UMFPACK_A, umf.pntr, umf.indx, umf.vals, x, b, umf.Numeric, NULL, NULL);
};

void smpack_pmat_UMFPACK_solve_transposed( struct SMPACKFactorizedUMFPACK umf, double *b, double *x ){
	umfpack_di_solve(UMFPACK_At, umf.pntr, umf.indx, umf.vals, x, b, umf.Numeric, NULL, NULL);
};

void smpack_pmat_UMFPACK_free( struct SMPACKFactorizedUMFPACK *umf ){
	free( umf->pntr ); umf->pntr = NULL;
	free( umf->indx ); umf->indx = NULL;
	free( umf->vals ); umf->vals = NULL;
	umfpack_di_free_numeric( &(umf->Numeric) );
	umf->num_rows = 0;
};

void smpack_pmat_general_solve( struct SMPACKPmat m, double *b, double *x ){
	struct SMPACKFactorizedUMFPACK umf;
	smpack_pmat_UMFPACK_factorize( m, &umf );
	smpack_pmat_UMFPACK_solve( umf, b, x );
	smpack_pmat_UMFPACK_free( &umf );
};

void smpack_pmat_CHOLMOD_factorize( struct SMPACKPmat m, struct SMPACKFactorizedCHOLMOD *chol ){
	int i,j,k, N = m.num_rows;
	int *cnt = (int*) malloc( N * sizeof(int) );
	int total = 0;

	for( i=0; i<N; i++ ){ cnt[i] = 0; }; // set counter to zero

	for( i=0; i<N; i++ ){ // count below diagonal entries per column and total
		for( j=m.pntr[i]; j<m.pntr[i+1]; j++ ){
	        	cnt[ m.indx[j] ] += ( m.indx[j] <= i ? 1 : 0 );
	        	total += ( m.indx[j] <= i ? 1 : 0 );
		};
	};

	int * pntr = (int*) malloc( (N+1) * sizeof(int) );// inline matrix
	int * indx = (int*) malloc( total * sizeof(int) );
	double * vals = (double*) malloc( total * sizeof(double) );

	pntr[0] = 0;
	for( i=1; i<N; i++ ){ // set the pointers
		pntr[i] = pntr[i-1] + cnt[i-1];
	};
	pntr[N] = total;

	for( i=0; i<N; i++ ){ cnt[i] = 0; }; // set counter to zero

	for( i=0; i<N; i++ ){ // for each row
		for( j=m.pntr[i]; j<m.pntr[i+1]; j++ ){ // go over the enties
			if ( m.indx[j] <= i ){ // if below diagonal
				indx[ pntr[ m.indx[j] ] + cnt[ m.indx[j] ] ] = i;
				vals[ pntr[ m.indx[j] ] + cnt[ m.indx[j] ] ] = m.vals[j];
				cnt[ m.indx[j] ]++;
			};
		};
	};

	cholmod_start( &(chol->c) );
	chol->b = cholmod_allocate_dense( N, 1, N, CHOLMOD_REAL, &(chol->c) );
	chol->S = cholmod_allocate_sparse(N,N,pntr[N],1,1,-1,CHOLMOD_REAL,&(chol->c));

	int * tmp;
	tmp = (int*) chol->S ->p;
	for( i=0; i<= N; i++ ){
		tmp[i] = pntr[i];
	};
	tmp = (int*) chol->S ->i;
	for( i=0; i< total; i++ ){
		tmp[i] = indx[i];
	};
	tmp = NULL;

	double * dtemp = (double*) chol->S -> x;
	dcopy( total, vals, 1, dtemp, 1 );
	dtemp = NULL;

	chol->L = cholmod_analyze(chol->S, &(chol->c) );
	cholmod_factorize(chol->S, chol->L, &(chol->c) );

	chol->size = N;

	free( pntr );
	free( indx );
	free( vals );
	free( cnt );
};

void smpack_pmat_CHOLMOD_factorize_llt( struct SMPACKPmat m, struct SMPACKFactorizedCHOLMOD *chol ){
       int i,j,k, N = m.num_rows;
	int *cnt = (int*) malloc( N * sizeof(int) );
	int total = 0;

	for( i=0; i<N; i++ ){ cnt[i] = 0; }; // set counter to zero

	for( i=0; i<N; i++ ){ // count below diagonal entries per column and total
		for( j=m.pntr[i]; j<m.pntr[i+1]; j++ ){
	        	cnt[ m.indx[j] ] += ( m.indx[j] <= i ? 1 : 0 );
	        	total += ( m.indx[j] <= i ? 1 : 0 );
		};
	};

	int * pntr = (int*) malloc( (N+1) * sizeof(int) );// inline matrix
	int * indx = (int*) malloc( total * sizeof(int) );
	double * vals = (double*) malloc( total * sizeof(double) );

	pntr[0] = 0;
	for( i=1; i<N; i++ ){ // set the pointers
		pntr[i] = pntr[i-1] + cnt[i-1];
	};
	pntr[N] = total;

	for( i=0; i<N; i++ ){ cnt[i] = 0; }; // set counter to zero

	for( i=0; i<N; i++ ){ // for each row
		for( j=m.pntr[i]; j<m.pntr[i+1]; j++ ){ // go over the enties
			if ( m.indx[j] <= i ){ // if below diagonal
				indx[ pntr[ m.indx[j] ] + cnt[ m.indx[j] ] ] = i;
				vals[ pntr[ m.indx[j] ] + cnt[ m.indx[j] ] ] = m.vals[j];
				cnt[ m.indx[j] ]++;
			};
		};
	};

	cholmod_start( &(chol->c) );
        chol->c.final_ll = (1==1);
	chol->b = cholmod_allocate_dense( N, 1, N, CHOLMOD_REAL, &(chol->c) );
	chol->S = cholmod_allocate_sparse(N,N,pntr[N],1,1,-1,CHOLMOD_REAL,&(chol->c));

	int * tmp;
	tmp = (int*) chol->S ->p;
	for( i=0; i<= N; i++ ){
		tmp[i] = pntr[i];
	};
	tmp = (int*) chol->S ->i;
	for( i=0; i< total; i++ ){
		tmp[i] = indx[i];
	};
	tmp = NULL;

	double * dtemp = (double*) chol->S -> x;
	dcopy( total, vals, 1, dtemp, 1 );
	dtemp = NULL;

	chol->L = cholmod_analyze(chol->S, &(chol->c) );
	cholmod_factorize(chol->S, chol->L, &(chol->c) );

	chol->size = N;

	free( pntr );
	free( indx );
	free( vals );
	free( cnt ); 
};

void smpack_pmat_CHOLMOD_solve( struct SMPACKFactorizedCHOLMOD *chol, double *b, double *x ){
	double * tmp = (double*) chol->b->x;
	dcopy( chol->size, b, 1, tmp, 1 );
	tmp = NULL;
	chol->x = cholmod_solve(CHOLMOD_A, chol->L, chol->b, &(chol->c) ) ;
	tmp = (double*) chol->x->x;
	if ( x == NULL ){
		dcopy( chol->size, tmp, 1, b, 1 );
	}else{
		dcopy( chol->size, tmp, 1, x, 1 );
	};
	tmp = NULL;
	cholmod_free_dense( &(chol->x), &(chol->c) );
};

void smpack_pmat_CHOLMOD_solve_l( struct SMPACKFactorizedCHOLMOD *chol, double *b, double *x ){
        double * tmp = (double*) chol->b->x;
	dcopy( chol->size, b, 1, tmp, 1 );
	tmp = NULL;
        //cholmod_dense *Pb = cholmod_solve(CHOLMOD_Pt, chol->L, chol->b, &(chol->c) ) ;
        //chol->x = cholmod_solve(CHOLMOD_L, chol->L, Pb, &(chol->c) ) ;
	
	chol->x = cholmod_solve(CHOLMOD_L, chol->L, chol->b, &(chol->c) ) ;
	
	tmp = (double*) chol->x->x;
	if ( x == NULL ){
		dcopy( chol->size, tmp, 1, b, 1 );
	}else{
		dcopy( chol->size, tmp, 1, x, 1 );
	};
	tmp = NULL;
	//cholmod_free_dense( &Pb, &(chol->c) );	
        cholmod_free_dense( &(chol->x), &(chol->c) );
        
};

void smpack_pmat_CHOLMOD_free( struct SMPACKFactorizedCHOLMOD *chol ){
        cholmod_free_dense( &(chol->b), &(chol->c) );
        cholmod_free_sparse( &(chol->S), &(chol->c) );
        cholmod_free_factor( &(chol->L), &(chol->c) );
        cholmod_finish( &(chol->c) );
};

#endif



#endif
